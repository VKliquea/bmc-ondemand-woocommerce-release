(function($) {
    'use strict';

    // Helper para mostrar alertas con SweetAlert2 (con fallback seguro a alert si no carga)
    function notify(options) {
        if (typeof Swal !== 'undefined' && Swal.fire) {
            return Swal.fire(options);
        } else {
            var msg = options.text || options.title || '';
            if (options.html) {
                var tmp = document.createElement('div');
                tmp.innerHTML = options.html;
                msg = tmp.textContent || tmp.innerText || '';
            }
            alert(msg);
            return Promise.resolve();
        }
    }

    // ==========================================
    // Cambio entre Pestaña 1 (Despacho) y Pestaña 2 (Impresión de Etiquetas)
    // ==========================================
    $(document).on('click', '.bmc-tab-btn', function(e) {
        e.preventDefault();
        var btn = $(this);
        var targetTab = btn.data('tab');

        $('.bmc-tab-btn').css({
            'font-weight': '600',
            'border-bottom-color': 'transparent',
            'color': '#64748b',
            'background': 'transparent'
        }).removeClass('active');

        btn.css({
            'font-weight': '700',
            'border-bottom-color': '#008060',
            'color': '#008060',
            'background': '#fff'
        }).addClass('active');

        $('.bmc-tab-content').hide();
        $('#bmc-tab-content-' + targetTab).show();
    });

    // Seleccionar o deseleccionar todos los checkboxes
    $(document).on('change', '#bmc-select-all-items', function() {
        var isChecked = $(this).is(':checked');
        $('.bmc-item-checkbox:not(:disabled)').prop('checked', isChecked);
    });

    // Aplicar sucursal (pickup) en lote a todos los ítems no enviados
    $(document).on('change', '#bmc-bulk-location', function() {
        var selectedLoc = $(this).val();
        if (!selectedLoc) {
            return;
        }
        $('.bmc-item-location:not(:disabled)').val(selectedLoc).trigger('change');
    });

    // Aplicar peso en lote a todos los ítems no enviados
    function applyBulkWeight() {
        var rawWeight = $('#bmc-bulk-weight').val();
        var weight = parseFloat(rawWeight);
        if (isNaN(weight) || weight <= 0) {
            $('#bmc-bulk-weight').css({ 'border-color': '#ef4444', 'background': '#fff5f5' }).focus();
            return;
        }
        $('#bmc-bulk-weight').css({ 'border-color': '#cbd5e1', 'background': '#ffffff' });
        $('.bmc-item-weight:not(:disabled)').each(function() {
            $(this).val(weight).trigger('change');
        });
    }

    $(document).on('click', '#bmc-btn-apply-bulk-weight', function(e) {
        e.preventDefault();
        applyBulkWeight();
    });

    $(document).on('keypress', '#bmc-bulk-weight', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            applyBulkWeight();
        }
    });

    // Validar visualmente el input de peso cuando el usuario escribe
    $(document).on('input keyup change paste', '.bmc-item-weight', function() {
        var input = $(this);
        var val = parseFloat(input.val());
        if (!isNaN(val) && val > 0) {
            input.attr('style', 'width:95px; border-color:#cbd5e1 !important; background:#ffffff !important;');
        } else {
            input.attr('style', 'width:95px; border-color:#ef4444 !important; background:#fff5f5 !important;');
        }
    });

    $(document).on('click', '#bmc-btn-dispatch-all', function(e) {
        e.preventDefault();
        var btn = $(this);
        var orderId = btn.data('order-id');

        var locationsMap = {};
        var weightsMap = {};
        var deliveryNotes = $('#bmc_delivery_notes').val() || '';
        var hasSelectedItems = false;
        var missingWeightItems = [];

        $('tr[data-item-id]').each(function() {
            var row = $(this);
            var itemId = row.data('item-id');
            var chk = row.find('.bmc-item-checkbox');

            // Si está enviado previamente o el checkbox no está marcado, no procesar para este envío
            if (!chk.length || chk.is(':disabled') || !chk.is(':checked')) {
                return;
            }

            var loc = row.find('.bmc-item-location').val();
            // Si tiene marcado "Enviar después / No enviar ahora", omitir
            if (!loc || loc === '__NO_ENVIAR__') {
                return;
            }

            var itemName = row.find('td:nth-child(3) strong').text().trim() || ('Ítem #' + itemId);
            var weightInput = row.find('.bmc-item-weight');
            var weightVal = weightInput.val();
            var weight = parseFloat(weightVal);

            // Validar que tenga peso estrictamente > 0
            if (isNaN(weight) || weight <= 0) {
                missingWeightItems.push(itemName);
                weightInput.attr('style', 'width:95px; border-color:#ef4444 !important; background:#fff5f5 !important;');
                return;
            } else {
                weightInput.attr('style', 'width:95px; border-color:#cbd5e1 !important; background:#ffffff !important;');
            }

            hasSelectedItems = true;
            locationsMap[itemId] = loc;
            weightsMap[itemId] = weight;
        });

        // Si hay ítems seleccionados sin peso, bloquear el envío
        if (missingWeightItems.length > 0) {
            var itemsListHtml = '<ul style="text-align:left;margin-top:10px;padding-left:20px;color:#dc2626;">' +
                missingWeightItems.map(function(item) {
                    return '<li><strong>' + $('<div>').text(item).html() + '</strong></li>';
                }).join('') +
                '</ul><p style="margin-top:10px;color:#64748b;font-size:13px;">Por favor, asigna un peso en libras mayor a 0 para poder continuar.</p>';

            notify({
                icon: 'warning',
                title: 'Pesos obligatorios requeridos',
                html: itemsListHtml,
                confirmButtonColor: '#008060',
                confirmButtonText: 'Entendido, corregir peso'
            });
            return;
        }

        if (!hasSelectedItems) {
            notify({
                icon: 'info',
                title: 'Sin ítems para despachar',
                text: 'Por favor selecciona al menos un producto con su sucursal de origen para enviar ahora.',
                confirmButtonColor: '#008060',
                confirmButtonText: 'Aceptar'
            });
            return;
        }

        // Confirmación interactiva con SweetAlert2 antes de disparar el envío
        notify({
            icon: 'question',
            title: '¿Despachar pedido a BMC OnDemand?',
            text: 'Se enviarán los ítems seleccionados a sus respectivas sucursales de origen.',
            showCancelButton: true,
            confirmButtonColor: '#008060',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Sí, despachar ahora',
            cancelButtonText: 'Cancelar'
        }).then(function(result) {
            if (!result || !result.isConfirmed) {
                return;
            }

            btn.prop('disabled', true).text('Despachando ítems...');

            if (typeof Swal !== 'undefined' && Swal.showLoading) {
                Swal.fire({
                    title: 'Enviando a BMC OnDemand...',
                    text: 'Por favor espera un momento mientras procesamos la entrega.',
                    allowOutsideClick: false,
                    didOpen: function() {
                        Swal.showLoading();
                    }
                });
            }

            $.post(bmc_dispatch_params.ajax_url, {
                action: 'bmc_dispatch_selected_items',
                security: bmc_dispatch_params.nonce,
                order_id: orderId,
                locations: locationsMap,
                weights: weightsMap,
                delivery_notes: deliveryNotes
            }, function(res) {
                if (res && res.success) {
                    var data = res.data || {};
                    var tracking = data.tracking || '';
                    var printUrl = data.print_url || (bmc_dispatch_params.ajax_url + '?action=bmc_print_label&order_id=' + orderId + '&tracking=' + encodeURIComponent(tracking));

                    var successHtml = '<div style="font-size:14px;color:#334155;">' +
                        '<p>Los ítems seleccionados fueron despachados correctamente a BMC OnDemand.</p>';

                    if (tracking) {
                        successHtml += '<div style="margin:12px 0;padding:8px 12px;background:#f1f5f9;border-radius:6px;border:1px solid #cbd5e1;">' +
                            '<strong>Tracking:</strong> <code style="font-size:15px;color:#0369a1;font-weight:bold;">' + $('<div>').text(tracking).html() + '</code>' +
                            '</div>';
                    }

                    successHtml += '<div style="margin-top:16px;">' +
                        '<a href="' + printUrl + '" target="_blank" class="button button-primary" style="background:#008060;border-color:#008060;color:#fff;padding:8px 16px;text-decoration:none;font-weight:bold;border-radius:4px;display:inline-block;">' +
                        '🖨️ Imprimir Etiqueta 4x6' +
                        '</a>' +
                        '</div></div>';

                    notify({
                        icon: 'success',
                        title: '¡Despacho Exitoso!',
                        html: successHtml,
                        confirmButtonColor: '#008060',
                        confirmButtonText: 'Cerrar y Actualizar'
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    notify({
                        icon: 'error',
                        title: 'Error al despachar',
                        text: res.data || 'Respuesta inválida del servidor.',
                        confirmButtonColor: '#dc2626',
                        confirmButtonText: 'Cerrar'
                    });
                    btn.prop('disabled', false).text('Despachar Ítems Seleccionados');
                }
            }).fail(function() {
                notify({
                    icon: 'error',
                    title: 'Fallo de conexión',
                    text: 'Ocurrió un error al comunicarse con el servidor.',
                    confirmButtonColor: '#dc2626',
                    confirmButtonText: 'Cerrar'
                });
                btn.prop('disabled', false).text('Despachar Ítems Seleccionados');
            });
        });
    });

    // ==========================================
    // Manejo de Tags Rápidos y Personalizados para la Etiqueta
    // ==========================================
    var selectedTags = [];

    function renderTags() {
        var container = $('#bmc-selected-tags-display');
        container.empty();
        selectedTags.forEach(function(tag, idx) {
            var isFragil = tag.toUpperCase().indexOf('FRAGIL') !== -1 || tag.toUpperCase().indexOf('FRÁGIL') !== -1;
            var bg = isFragil ? '#000' : '#0284c7';
            var tagEl = $('<span style="background:' + bg + ';color:#fff;font-size:11px;font-weight:bold;padding:2px 8px;border-radius:12px;display:inline-flex;align-items:center;gap:4px;cursor:pointer;" title="Click para remover">' +
                $('<div>').text(tag).html() +
                ' <span style="font-size:10px;opacity:0.8;">&times;</span></span>');

            tagEl.on('click', function() {
                selectedTags.splice(idx, 1);
                renderTags();
                updateTagButtonsState();
            });
            container.append(tagEl);
        });
        $('#bmc-label-tags').val(selectedTags.join(','));
    }

    function updateTagButtonsState() {
        $('.bmc-btn-tag').each(function() {
            var btn = $(this);
            var tagVal = btn.data('tag');
            if (selectedTags.indexOf(tagVal) !== -1) {
                btn.css({ 'background': '#008060', 'color': '#fff', 'border-color': '#008060' });
            } else {
                btn.css({ 'background': '#fff', 'color': '#333', 'border-color': '#cbd5e1' });
            }
        });
    }

    $(document).on('click', '.bmc-btn-tag', function(e) {
        e.preventDefault();
        var tag = $(this).data('tag');
        var index = selectedTags.indexOf(tag);
        if (index === -1) {
            selectedTags.push(tag);
        } else {
            selectedTags.splice(index, 1);
        }
        renderTags();
        updateTagButtonsState();
    });

    function addCustomTag() {
        var input = $('#bmc-custom-tag-input');
        var val = input.val().trim().toUpperCase();
        if (val && selectedTags.indexOf(val) === -1) {
            selectedTags.push(val);
            input.val('');
            renderTags();
            updateTagButtonsState();
        }
    }

    $(document).on('click', '#bmc-btn-add-custom-tag', function(e) {
        e.preventDefault();
        addCustomTag();
    });

    $(document).on('keypress', '#bmc-custom-tag-input', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            addCustomTag();
        }
    });

    // Botón único "Imprimir Etiqueta" en formato 4x6
    $(document).on('click', '#bmc-btn-print-single-label', function(e) {
        e.preventDefault();
        var btn = $(this);
        var orderId = btn.data('order-id');
        var baseUrl = btn.data('base-url');

        var tracking = $('#bmc-shipment-select').val() || '';
        var note = $('#bmc_label_custom_note').val() || '';
        var tags = $('#bmc-label-tags').val() || '';

        var url = baseUrl + '&order_id=' + encodeURIComponent(orderId) +
            '&tracking=' + encodeURIComponent(tracking) +
            '&note=' + encodeURIComponent(note) +
            '&tags=' + encodeURIComponent(tags);

        window.open(url, '_blank');
    });

})(jQuery);
