<?php
/**
 * Plugin Name:       BMC OnDemand for WooCommerce
 * Plugin URI:        https://bmcargo.com
 * Description:       Integración oficial de entrega y delivery con BMC OnDemand / BM Drive para WooCommerce.
 * Version: 1.3.11
 * Author:            BMCargo
 * Author URI:        https://bmcargo.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * Text Domain:       bmc-ondemand
 * Domain Path:       /languages
 */

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Redirigir al archivo de inicialización principal (patrón idéntico a kanoa-sync)
require_once plugin_dir_path(__FILE__) . 'index.php';
