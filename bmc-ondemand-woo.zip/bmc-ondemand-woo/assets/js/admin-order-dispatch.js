(function($) {
    'use strict';

    // Helper para mostrar alertas con SweetAlert2 (con fallback seguro a alert si no carga)
    function notify(options) {
        if (typeof Swal !== 'undefined' && Swal.fire) {
            return Swal.fire(options);
        } else {
            var msg = options.text || options.title || '';
            if (options.html) {
                var tmp = document.createElement('div');
                tmp.innerHTML = options.html;
                msg = tmp.textContent || tmp.innerText || '';
            }
            alert(msg);
            return Promise.resolve();
        }
    }

    // Seleccionar o deseleccionar todos los checkboxes
    $(document).on('change', '#bmc-select-all-items', function() {
        var isChecked = $(this).is(':checked');
        $('.bmc-item-checkbox:not(:disabled)').prop('checked', isChecked);
    });

    // Aplicar sucursal (pickup) en lote a todos los ítems no enviados
    $(document).on('change', '#bmc-bulk-location', function() {
        var selectedLoc = $(this).val();
        if (!selectedLoc) {
            return;
        }
        $('.bmc-item-location:not(:disabled)').val(selectedLoc).trigger('change');
    });

    // Aplicar peso en lote a todos los ítems no enviados
    function applyBulkWeight() {
        var rawWeight = $('#bmc-bulk-weight').val();
        var weight = parseFloat(rawWeight);
        if (isNaN(weight) || weight <= 0) {
            $('#bmc-bulk-weight').css({ 'border-color': '#ef4444', 'background': '#fff5f5' }).focus();
            return;
        }
        $('#bmc-bulk-weight').css({ 'border-color': '#cbd5e1', 'background': '#ffffff' });
        $('.bmc-item-weight:not(:disabled)').each(function() {
            $(this).val(weight).trigger('change');
        });
    }

    $(document).on('click', '#bmc-btn-apply-bulk-weight', function(e) {
        e.preventDefault();
        applyBulkWeight();
    });

    $(document).on('keypress', '#bmc-bulk-weight', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            applyBulkWeight();
        }
    });

    // Validar visualmente el input de peso cuando el usuario escribe
    $(document).on('input change', '.bmc-item-weight', function() {
        var input = $(this);
        var val = parseFloat(input.val());
        if (isNaN(val) || val <= 0) {
            input.css({ 'border-color': '#ef4444', 'background': '#fff5f5' });
        } else {
            input.css({ 'border-color': '#cbd5e1', 'background': '#ffffff' });
        }
    });

    $(document).on('click', '#bmc-btn-dispatch-all', function(e) {
        e.preventDefault();
        var btn = $(this);
        var orderId = btn.data('order-id');

        var locationsMap = {};
        var weightsMap = {};
        var deliveryNotes = $('#bmc_delivery_notes').val() || '';
        var hasSelectedItems = false;
        var missingWeightItems = [];

        $('tr[data-item-id]').each(function() {
            var row = $(this);
            var itemId = row.data('item-id');
            var chk = row.find('.bmc-item-checkbox');

            // Si está enviado previamente o el checkbox no está marcado, no procesar para este envío
            if (!chk.length || chk.is(':disabled') || !chk.is(':checked')) {
                return;
            }

            var loc = row.find('.bmc-item-location').val();
            // Si tiene marcado "Enviar después / No enviar ahora", omitir
            if (!loc || loc === '__NO_ENVIAR__') {
                return;
            }

            var itemName = row.find('td:nth-child(3) strong').text().trim() || ('Ítem #' + itemId);
            var weightVal = row.find('.bmc-item-weight').val();
            var weight = parseFloat(weightVal);

            // Validar que tenga peso estrictamente > 0
            if (isNaN(weight) || weight <= 0) {
                missingWeightItems.push(itemName);
                row.find('.bmc-item-weight').css({ 'border-color': '#ef4444', 'background': '#fff5f5' });
                return;
            }

            hasSelectedItems = true;
            locationsMap[itemId] = loc;
            weightsMap[itemId] = weight;
        });

        // Si hay ítems seleccionados sin peso, bloquear el envío
        if (missingWeightItems.length > 0) {
            var itemsListHtml = '<ul style="text-align:left;margin-top:10px;padding-left:20px;color:#dc2626;">' +
                missingWeightItems.map(function(item) {
                    return '<li><strong>' + $('<div>').text(item).html() + '</strong></li>';
                }).join('') +
                '</ul><p style="margin-top:10px;color:#64748b;font-size:13px;">Por favor, asigna un peso en libras mayor a 0 para poder continuar.</p>';

            notify({
                icon: 'warning',
                title: 'Pesos obligatorios requeridos',
                html: itemsListHtml,
                confirmButtonColor: '#008060',
                confirmButtonText: 'Entendido, corregir peso'
            });
            return;
        }

        if (!hasSelectedItems) {
            notify({
                icon: 'info',
                title: 'Sin ítems para despachar',
                text: 'Por favor selecciona al menos un producto con su sucursal de origen para enviar ahora.',
                confirmButtonColor: '#008060',
                confirmButtonText: 'Aceptar'
            });
            return;
        }

        // Confirmación interactiva con SweetAlert2 antes de disparar el envío
        notify({
            icon: 'question',
            title: '¿Despachar pedido a BMC OnDemand?',
            text: 'Se enviarán los ítems seleccionados a sus respectivas sucursales de origen.',
            showCancelButton: true,
            confirmButtonColor: '#008060',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Sí, despachar ahora',
            cancelButtonText: 'Cancelar'
        }).then(function(result) {
            if (!result || !result.isConfirmed) {
                return;
            }

            btn.prop('disabled', true).text('Despachando ítems...');

            if (typeof Swal !== 'undefined' && Swal.showLoading) {
                Swal.fire({
                    title: 'Enviando a BMC OnDemand...',
                    text: 'Por favor espera un momento mientras procesamos la entrega.',
                    allowOutsideClick: false,
                    didOpen: function() {
                        Swal.showLoading();
                    }
                });
            }

            $.post(bmc_dispatch_params.ajax_url, {
                action: 'bmc_dispatch_selected_items',
                security: bmc_dispatch_params.nonce,
                order_id: orderId,
                locations: locationsMap,
                weights: weightsMap,
                delivery_notes: deliveryNotes
            }, function(res) {
                if (res && res.success) {
                    notify({
                        icon: 'success',
                        title: '¡Despacho Exitoso!',
                        text: 'Los ítems seleccionados fueron enviados correctamente a BMC OnDemand.',
                        confirmButtonColor: '#008060',
                        confirmButtonText: 'Aceptar'
                    }).then(function() {
                        location.reload();
                    });
                } else {
                    notify({
                        icon: 'error',
                        title: 'Error al despachar',
                        text: res.data || 'Respuesta inválida del servidor.',
                        confirmButtonColor: '#dc2626',
                        confirmButtonText: 'Cerrar'
                    });
                    btn.prop('disabled', false).text('Despachar Ítems Seleccionados');
                }
            }).fail(function() {
                notify({
                    icon: 'error',
                    title: 'Fallo de conexión',
                    text: 'Ocurrió un error al comunicarse con el servidor.',
                    confirmButtonColor: '#dc2626',
                    confirmButtonText: 'Cerrar'
                });
                btn.prop('disabled', false).text('Despachar Ítems Seleccionados');
            });
        });
    });

})(jQuery);
