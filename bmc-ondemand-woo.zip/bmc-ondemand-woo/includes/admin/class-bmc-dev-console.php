<?php
/**
 * Widget Flotante de Depuración / Dev Console para BMC OnDemand
 * Solo activo durante desarrollo para monitorear estados y tokens en tiempo real.
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Dev_Console {

    public static function init() {
        // Solo activo si WP_DEBUG está habilitado explícitamente en wp-config.php y el usuario es administrador
        if (!defined('WP_DEBUG') || !WP_DEBUG || !current_user_can('manage_woocommerce')) {
            return;
        }

        add_action('admin_footer', array(__CLASS__, 'render_floating_card'));
        add_action('wp_footer', array(__CLASS__, 'render_floating_card'));
        add_action('wp_ajax_bmc_dev_refresh_status', array(__CLASS__, 'ajax_refresh_status'));
    }

    public static function get_debug_data() {
        $api = BMC_API_Client::get_instance();
        $shop_id = $api->get_shop_identifier();
        $env = $api->get_environment();
        $store_status = get_option('bmc_ondemand_store_status', 'pending');
        $token = get_option('bmc_ondemand_access_token', '');
        $token_expires = get_option('bmc_ondemand_token_expires', 0);
        $client_id = get_option('bmc_ondemand_client_id', '');
        $default_loc = BMC_Locations::get_default_location_id();
        $auto_sync = get_option('bmc_ondemand_auto_sync_orders', 'no');
        $carrier_enabled = get_option('bmc_ondemand_carrier_enabled', 'no');

        // Coordenadas en sesión si estamos en frontend/checkout
        $session_lat = WC()->session ? WC()->session->get('bmc_destination_lat') : null;
        $session_lng = WC()->session ? WC()->session->get('bmc_destination_lng') : null;

        $has_valid_token = !empty($token) && ($token_expires - time() > 0);
        $remaining_secs = max(0, $token_expires - time());

        return array(
            'shop_id'          => $shop_id,
            'env'              => strtoupper($env),
            'store_status'     => strtoupper($store_status),
            'has_valid_token'  => $has_valid_token,
            'token_preview'    => !empty($token) ? substr($token, 0, 15) . '...' . substr($token, -8) : 'Ninguno',
            'token_expires_in' => $remaining_secs > 0 ? "{$remaining_secs}s" : 'Expirado / Sin token',
            'client_id'        => !empty($client_id) ? substr($client_id, 0, 10) . '...' : 'No asignado',
            'default_location' => !empty($default_loc) ? $default_loc : 'Sin configurar',
            'auto_sync'        => $auto_sync === 'yes' ? 'Activo' : 'Inactivo',
            'carrier_enabled'  => $carrier_enabled === 'yes' ? 'Activo' : 'Inactivo',
            'session_coords'   => ($session_lat && $session_lng) ? "{$session_lat}, {$session_lng}" : 'No capturadas',
        );
    }

    public static function ajax_refresh_status() {
        check_ajax_referer('bmc_dev_console_nonce', 'security');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('No autorizado');
        }
        wp_send_json_success(self::get_debug_data());
    }

    public static function render_floating_card() {
        $data = self::get_debug_data();
        $badge_color = $data['has_valid_token'] ? '#10b981' : '#f59e0b';
        ?>
        <!-- BMC OnDemand Floating Dev Console (Temporal para desarrollo) -->
        <div id="bmc-dev-floating-card" style="position:fixed;bottom:20px;right:20px;z-index:999999;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:12px;line-height:1.4;">
            <div id="bmc-dev-card-header" style="background:#1e293b;color:#f8fafc;padding:9px 14px;border-radius:8px 8px 0 0;cursor:pointer;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 6px -1px rgba(0,0,0,0.1);user-select:none;">
                <span style="display:flex;align-items:center;gap:7px;font-weight:600;">
                    <span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:<?php echo esc_attr($badge_color); ?>;" id="bmc-dev-status-dot"></span>
                    BMC OnDemand Dev Console
                </span>
                <span id="bmc-dev-toggle-icon" style="font-size:11px;color:#94a3b8;margin-left:12px;">[ Minimizar ]</span>
            </div>

            <div id="bmc-dev-card-body" style="background:#0f172a;color:#cbd5e1;padding:14px;border-radius:0 0 8px 8px;width:310px;box-shadow:0 10px 15px -3px rgba(0,0,0,0.3);border:1px solid #334155;border-top:none;">
                <div style="display:grid;grid-template-columns:110px 1fr;gap:6px 8px;margin-bottom:12px;">
                    <span style="color:#94a3b8;">Shop ID:</span>
                    <strong style="color:#f8fafc;word-break:break-all;" id="bmc-dev-shop"><?php echo esc_html($data['shop_id']); ?></strong>

                    <span style="color:#94a3b8;">Entorno:</span>
                    <span id="bmc-dev-env" style="color:#38bdf8;font-weight:600;"><?php echo esc_html($data['env']); ?></span>

                    <span style="color:#94a3b8;">Estado Tienda:</span>
                    <span id="bmc-dev-store-status" style="color:<?php echo esc_attr($badge_color); ?>;font-weight:600;"><?php echo esc_html($data['store_status']); ?></span>

                    <span style="color:#94a3b8;">Token OAuth:</span>
                    <span id="bmc-dev-token" style="font-family:monospace;font-size:11px;"><?php echo esc_html($data['token_preview']); ?></span>

                    <span style="color:#94a3b8;">Expira en:</span>
                    <span id="bmc-dev-expires" style="color:#fbbf24;"><?php echo esc_html($data['token_expires_in']); ?></span>

                    <span style="color:#94a3b8;">Sucursal:</span>
                    <span id="bmc-dev-loc" style="font-size:11px;color:#f8fafc;word-break:break-all;"><?php echo esc_html($data['default_location']); ?></span>

                    <span style="color:#94a3b8;">Auto-Sync:</span>
                    <span id="bmc-dev-sync"><?php echo esc_html($data['auto_sync']); ?></span>

                    <span style="color:#94a3b8;">Cotizador:</span>
                    <span id="bmc-dev-carrier"><?php echo esc_html($data['carrier_enabled']); ?></span>

                    <span style="color:#94a3b8;">GPS Checkout:</span>
                    <span id="bmc-dev-coords" style="color:#34d399;font-family:monospace;"><?php echo esc_html($data['session_coords']); ?></span>
                </div>

                <div style="display:flex;gap:8px;border-top:1px solid #334155;padding-top:10px;">
                    <button type="button" id="bmc-dev-btn-refresh" style="flex:1;background:#334155;color:#f8fafc;border:none;padding:5px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;">
                        &#x21bb; Refrescar
                    </button>
                    <button type="button" id="bmc-dev-btn-log" style="flex:1;background:#2563eb;color:#f8fafc;border:none;padding:5px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;">
                        &#x1f4cb; Log en Consola
                    </button>
                </div>
            </div>
        </div>

        <script>
        (function() {
            var card = document.getElementById('bmc-dev-floating-card');
            var body = document.getElementById('bmc-dev-card-body');
            var header = document.getElementById('bmc-dev-card-header');
            var toggleIcon = document.getElementById('bmc-dev-toggle-icon');
            var btnRefresh = document.getElementById('bmc-dev-btn-refresh');
            var btnLog = document.getElementById('bmc-dev-btn-log');

            var isCollapsed = localStorage.getItem('bmc_dev_card_collapsed') === 'true';
            if (isCollapsed) {
                body.style.display = 'none';
                toggleIcon.textContent = '[ Expandir ]';
            }

            header.addEventListener('click', function(e) {
                if (e.target === btnRefresh || e.target === btnLog) return;
                var willCollapse = body.style.display !== 'none';
                body.style.display = willCollapse ? 'none' : 'block';
                toggleIcon.textContent = willCollapse ? '[ Expandir ]' : '[ Minimizar ]';
                localStorage.setItem('bmc_dev_card_collapsed', willCollapse);
            });

            function updateUI(d) {
                document.getElementById('bmc-dev-shop').textContent = d.shop_id;
                document.getElementById('bmc-dev-env').textContent = d.env;
                document.getElementById('bmc-dev-store-status').textContent = d.store_status;
                document.getElementById('bmc-dev-token').textContent = d.token_preview;
                document.getElementById('bmc-dev-expires').textContent = d.token_expires_in;
                document.getElementById('bmc-dev-loc').textContent = d.default_location;
                document.getElementById('bmc-dev-sync').textContent = d.auto_sync;
                document.getElementById('bmc-dev-carrier').textContent = d.carrier_enabled;
                document.getElementById('bmc-dev-coords').textContent = d.session_coords;

                var color = d.has_valid_token ? '#10b981' : '#f59e0b';
                document.getElementById('bmc-dev-status-dot').style.background = color;
                document.getElementById('bmc-dev-store-status').style.color = color;
            }

            btnRefresh.addEventListener('click', function(e) {
                e.stopPropagation();
                btnRefresh.textContent = 'Cargando...';
                var formData = new FormData();
                formData.append('action', 'bmc_dev_refresh_status');
                formData.append('security', '<?php echo wp_create_nonce('bmc_dev_console_nonce'); ?>');

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    btnRefresh.innerHTML = '&#x21bb; Refrescar';
                    if (res.success && res.data) {
                        updateUI(res.data);
                        console.log('[BMC OnDemand Dev Console] Datos actualizados:', res.data);
                    }
                })
                .catch(function(err) {
                    btnRefresh.innerHTML = '&#x21bb; Refrescar';
                    console.error('[BMC OnDemand Dev Console Error]:', err);
                });
            });

            btnLog.addEventListener('click', function(e) {
                e.stopPropagation();
                var currentData = {
                    shopId: document.getElementById('bmc-dev-shop').textContent,
                    env: document.getElementById('bmc-dev-env').textContent,
                    storeStatus: document.getElementById('bmc-dev-store-status').textContent,
                    token: document.getElementById('bmc-dev-token').textContent,
                    expiresIn: document.getElementById('bmc-dev-expires').textContent,
                    defaultLocation: document.getElementById('bmc-dev-loc').textContent,
                    autoSync: document.getElementById('bmc-dev-sync').textContent,
                    carrierEnabled: document.getElementById('bmc-dev-carrier').textContent,
                    sessionCoords: document.getElementById('bmc-dev-coords').textContent,
                    timestamp: new Date().toISOString()
                };
                console.group('%c[BMC OnDemand Dev Console Estado]', 'color:#38bdf8;font-weight:bold;');
                console.table(currentData);
                console.groupEnd();
            });
        })();
        </script>
        <?php
    }
}

BMC_Dev_Console::init();
