<?php
/**
 * Metabox Avanzado en Edición de Pedido (Item-Level Dispatch UI)
 * Equivale a ActionExtension.jsx de Shopify
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Order_Meta_Box
{

    public static function init()
    {
        add_action('add_meta_boxes', array(__CLASS__, 'register_meta_box'), 30);
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
        add_action('wp_ajax_bmc_dispatch_selected_items', array(__CLASS__, 'ajax_dispatch_selected_items'));
    }

    public static function register_meta_box()
    {
        // Si la tienda no está aprobada (active), no mostrar el metabox de despacho
        $api = BMC_API_Client::get_instance();
        if ($api->get_store_status() !== 'active') {
            return;
        }

        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') &&
            \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
            ? wc_get_page_screen_id('shop-order')
            : 'shop_order';

        add_meta_box(
            'bmc_ondemand_dispatch_box',
            __('BMC OnDemand — Despacho por Ítems y Sucursal', 'bmc-ondemand'),
            array(__CLASS__, 'render_dispatch_box'),
            $screen,
            'normal',
            'high'
        );
    }

    public static function enqueue_assets($hook)
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $screen_id = $screen ? $screen->id : '';
        $is_order_page = in_array($hook, array('post.php', 'post-new.php', 'woocommerce_page_wc-orders', 'admin.php'), true) ||
            (isset($_GET['page']) && $_GET['page'] === 'wc-orders') ||
            strpos($screen_id, 'shop_order') !== false ||
            strpos($screen_id, 'wc-orders') !== false;

        if ($is_order_page) {
            wp_enqueue_script(
                'sweetalert2',
                'https://cdn.jsdelivr.net/npm/sweetalert2@11',
                array(),
                '11.0.0',
                true
            );

            wp_enqueue_script(
                'bmc-admin-order-dispatch',
                BMC_ONDEMAND_PLUGIN_URL . 'assets/js/admin-order-dispatch.js',
                array('jquery', 'sweetalert2'),
                BMC_ONDEMAND_VERSION . '.' . time(),
                true
            );

            wp_localize_script('bmc-admin-order-dispatch', 'bmc_dispatch_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('bmc_dispatch_nonce'),
            ));
        }
    }

    public static function render_dispatch_box($post_or_order)
    {
        $order = ($post_or_order instanceof \WC_Order) ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order)
            return;

        $order_id = $order->get_id();
        $locations = BMC_Locations::get_all();
        $default_loc = BMC_Locations::get_default_location_id();
        $sent_items_raw = (array) $order->get_meta('_bmc_sent_items', true) ?: array();
        $sent_items = array_map('strval', $sent_items_raw);
        $status = $order->get_meta('_bmc_status') ?: 'No enviado';
        $tracking = $order->get_meta('_bmc_tracking');
        $shipments = (array) $order->get_meta('_bmc_shipments', true) ?: array();
        $total_items = count($order->get_items());
        $order_item_ids = array_map('strval', array_keys($order->get_items()));
        $sent_count = count(array_intersect($order_item_ids, $sent_items));
        $pending_count = $total_items - $sent_count;
        $print_label_url = admin_url('admin-ajax.php?action=bmc_print_label&order_id=' . $order_id . '&tracking=' . rawurlencode($tracking ?: ''));
        ?>
        <div class="bmc-dispatch-panel">
            <!-- Barra Superior de Estado y Pestañas -->
            <div
                style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <div>
                        <strong>Estado Delivery:</strong>
                        <span class="badge"
                            style="background:#e0f2fe;color:#0369a1;padding:3px 10px;border-radius:4px;font-weight:600;">
                            <?php echo esc_html(strtoupper($status)); ?>
                        </span>
                    </div>
                    <?php if ($total_items > 0): ?>
                        <div>
                            <?php if ($pending_count === 0): ?>
                                <span
                                    style="background:#dcfce7;color:#166534;font-size:11px;font-weight:700;padding:3px 8px;border-radius:12px;border:1px solid #bbf7d0;">
                                    ✓ Completado (<?php echo esc_html($sent_count . '/' . $total_items); ?> enviados)
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($tracking): ?>
                        <span>Tracking: <code><?php echo esc_html($tracking); ?></code></span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Navegación de Pestañas (Solo muestra Pestaña 2 si tiene tracking) -->
            <?php if (!empty($tracking)): ?>
                <div class="bmc-tabs-nav" style="display:flex;border-bottom:2px solid #cbd5e1;margin-bottom:16px;gap:4px;">
                    <button type="button" class="bmc-tab-btn active" data-tab="dispatch"
                        style="padding:8px 16px;font-weight:700;font-size:13px;border:none;background:#fff;border-bottom:3px solid #008060;color:#008060;cursor:pointer;display:inline-flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-cart" style="font-size:17px;line-height:20px;"></span>
                        <?php _e('Despacho', 'bmc-ondemand'); ?>
                    </button>
                    <button type="button" class="bmc-tab-btn" data-tab="print"
                        style="padding:8px 16px;font-weight:600;font-size:13px;border:none;background:transparent;border-bottom:3px solid transparent;color:#64748b;cursor:pointer;display:inline-flex;align-items:center;gap:6px;">
                        <span class="dashicons dashicons-printer" style="font-size:17px;line-height:20px;"></span>
                        <?php _e('Impresión de Etiquetas', 'bmc-ondemand'); ?>
                        <span
                            style="background:#dcfce7;color:#15803d;font-size:10px;padding:2px 6px;border-radius:10px;font-weight:bold;">✓
                            Listo</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- CONTENIDO PESTAÑA 1: DESPACHO -->
            <div id="bmc-tab-content-dispatch" class="bmc-tab-content" style="display:block;">
                <?php
                // Separar ítems pendientes de los ítems ya enviados
                $items_pending = array();
                $items_sent_list = array();

                foreach ($order->get_items() as $item_id => $item) {
                    $str_id = (string) $item_id;
                    if (in_array($str_id, $sent_items, true)) {
                        $items_sent_list[$str_id] = $item;
                    } else {
                        $items_pending[$str_id] = $item;
                    }
                }
                ?>

                <?php if (!empty($items_pending)): ?>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                        <span style="font-size:13px;font-weight:600;color:#0f172a;">
                            📦 <?php _e('Ítems Pendientes por Despachar:', 'bmc-ondemand'); ?>
                            (<?php echo count($items_pending); ?>)
                        </span>
                        <button type="button" class="button button-primary" id="bmc-btn-dispatch-all"
                            data-order-id="<?php echo esc_attr($order_id); ?>" style="font-weight:bold;padding:4px 16px;">
                            <?php _e('Despachar Ítems Seleccionados', 'bmc-ondemand'); ?>
                        </button>
                    </div>

                    <table class="wp-list-table widefat fixed striped"
                        style="border:1px solid #cbd5e1;border-radius:6px;overflow:hidden;">
                        <thead>
                            <tr style="background:#f8fafc;">
                                <th style="width:40px;text-align:center;">
                                    <input type="checkbox" id="bmc-select-all-items"
                                        title="<?php esc_attr_e('Seleccionar / Deseleccionar todos los pendientes', 'bmc-ondemand'); ?>"
                                        checked>
                                </th>
                                <th style="width:85px;">Estado</th>
                                <th>Producto / Ítem</th>
                                <th style="width:120px;">Cant. y Precio</th>
                                <th style="width:140px;">
                                    <span>Peso (lb) *</span>
                                    <div style="margin-top:4px;">
                                        <input type="number" step="0.01" min="0.01" id="bmc-bulk-weight" placeholder="Lote (lb)"
                                            style="width:85px;font-size:11px;padding:2px 4px;height:24px;"
                                            title="Aplicar este peso a todos los ítems">
                                        <button type="button" class="button button-small" id="bmc-btn-apply-bulk-weight"
                                            style="font-size:11px;height:24px;line-height:22px;padding:0 5px;"
                                            title="Aplicar peso a todos">&#10003;</button>
                                    </div>
                                </th>
                                <th style="width:250px;">
                                    <span>Sucursal de Origen (Pickup)</span>
                                    <div style="margin-top:4px;display:flex;gap:4px;align-items:center;">
                                        <select id="bmc-bulk-location"
                                            style="width:100%;font-size:11px;height:24px;padding:1px 4px;"
                                            title="Seleccionar sucursal en lote">
                                            <option value="">-- Aplicar sucursal a todos --</option>
                                            <option value="<?php echo esc_attr(BMC_Order_Dispatcher::NO_ENVIAR_VALUE); ?>">-- Enviar
                                                después (No enviar ahora) --</option>
                                            <?php foreach ($locations as $loc): ?>
                                                <option value="<?php echo esc_attr($loc['locationId']); ?>">
                                                    <?php echo esc_html($loc['name'] ?? $loc['locationId']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items_pending as $str_id => $item):
                                $product = $item->get_product();
                                $weight_unit = get_option('woocommerce_weight_unit', 'kg');
                                $raw_weight = $product ? floatval($product->get_weight()) : 0.0;
                                $weight_lb = 0.0;
                                if ($raw_weight > 0) {
                                    $weight_lb = ($weight_unit === 'kg') ? $raw_weight * 2.20462 : (($weight_unit === 'g') ? ($raw_weight / 1000) * 2.20462 : $raw_weight);
                                }
                                ?>
                                <tr class="bmc-row-pending" data-item-id="<?php echo esc_attr($str_id); ?>">
                                    <td style="text-align:center;vertical-align:middle;">
                                        <input type="checkbox" class="bmc-item-checkbox" value="1" checked>
                                    </td>
                                    <td>
                                        <span style="color:#d97706;font-weight:600;">Pendiente</span>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html($item->get_name()); ?></strong>
                                    </td>
                                    <td>
                                        <?php echo esc_html($item->get_quantity()); ?> x
                                        <?php echo wc_price($order->get_item_total($item, false)); ?>
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" min="0.01" class="bmc-item-weight"
                                            value="<?php echo $weight_lb > 0 ? esc_attr(round($weight_lb, 2)) : ''; ?>"
                                            placeholder="Peso (lb)" style="width:95px;">
                                    </td>
                                    <td>
                                        <select class="bmc-item-location" style="width:100%;">
                                            <option value="<?php echo esc_attr(BMC_Order_Dispatcher::NO_ENVIAR_VALUE); ?>">-- Enviar
                                                después (No enviar ahora) --</option>
                                            <?php foreach ($locations as $loc): ?>
                                                <option value="<?php echo esc_attr($loc['locationId']); ?>" <?php selected($default_loc, $loc['locationId']); ?>>
                                                    <?php echo esc_html($loc['name'] ?? $loc['locationId']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div
                        style="background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;padding:12px 16px;border-radius:6px;margin-bottom:14px;display:flex;align-items:center;gap:8px;">
                        <span class="dashicons dashicons-yes-alt" style="font-size:20px;color:#16a34a;"></span>
                        <strong><?php _e('¡Todos los ítems de esta orden ya fueron despachados exitosamente!', 'bmc-ondemand'); ?></strong>
                    </div>
                <?php endif; ?>

                <?php if (!empty($items_sent_list)): ?>
                    <!-- Listado separado de ítems ya enviados previamente -->
                    <div style="margin-top:20px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:12px 16px;">
                        <h4 style="margin:0 0 10px 0;font-size:13px;color:#475569;display:flex;align-items:center;gap:6px;">
                            <span class="dashicons dashicons-saved" style="color:#16a34a;"></span>
                            <?php _e('Ítems ya enviados en despachos anteriores:', 'bmc-ondemand'); ?>
                            (<?php echo count($items_sent_list); ?>)
                        </h4>
                        <table class="widefat fixed striped" style="background:#fff;border:1px solid #cbd5e1;border-radius:4px;">
                            <thead>
                                <tr style="background:#f1f5f9;">
                                    <th style="width:90px;">Estado</th>
                                    <th>Producto / Ítem</th>
                                    <th style="width:120px;">Cant. y Precio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items_sent_list as $sent_id => $s_item): ?>
                                    <tr style="opacity:0.85;background:#fcfcfc;">
                                        <td>
                                            <span style="color:#16a34a;font-weight:bold;">&#10003; Enviado</span>
                                        </td>
                                        <td>
                                            <strong><?php echo esc_html($s_item->get_name()); ?></strong>
                                        </td>
                                        <td>
                                            <?php echo esc_html($s_item->get_quantity()); ?> x
                                            <?php echo wc_price($order->get_item_total($s_item, false)); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <!-- Notas de Entrega para BMC OnDemand -->
                <?php
                // Calcular nota por defecto según método de pago:
                // Si es manual/COD -> "[Método] - [Total]"
                // Si es electrónico -> vacío
                $default_delivery_note = BMC_Order_Dispatcher::get_default_delivery_note($order);
                $initial_note = !empty($default_delivery_note) ? $default_delivery_note : '';
                ?>
                <div style="margin-top:16px;padding-top:14px;border-top:1px solid #e2e8f0;">
                    <label for="bmc_delivery_notes" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Notas de Entrega / Instrucciones:', 'bmc-ondemand'); ?>
                    </label>
                    <textarea id="bmc_delivery_notes" class="large-text" rows="2"
                        placeholder="<?php esc_attr_e('Agregar notas o indicaciones especiales para la entrega...', 'bmc-ondemand'); ?>"
                        style="border-radius:6px;border-color:#cbd5e1;"><?php echo esc_textarea($initial_note); ?></textarea>
                    <p class="description" style="margin-top:4px;color:#64748b;">
                        <?php _e('Estas notas se enviarán junto con el pedido a BMC OnDemand.', 'bmc-ondemand'); ?>
                    </p>
                </div>
            </div>

            <!-- CONTENIDO PESTAÑA 2: IMPRESIÓN DE ETIQUETAS (Solo se renderiza si tiene tracking) -->
            <?php if (!empty($tracking)): ?>
                <div id="bmc-tab-content-print" class="bmc-tab-content" style="display:none;">
                    <div style="padding:16px;background:#fff;border:1px solid #cbd5e1;border-radius:8px;">
                        <h4 style="margin:0 0 14px 0;font-size:15px;color:#0f172a;display:flex;align-items:center;gap:6px;">
                            <span class="dashicons dashicons-printer" style="color:#008060;font-size:20px;"></span>
                            <?php _e('Impresión de Etiquetas (Formato Estándar 4x6 Térmico)', 'bmc-ondemand'); ?>
                        </h4>

                        <!-- 1. Tags Rápidos y Personalizados -->
                        <div style="margin-bottom:16px;background:#f8fafc;padding:12px;border-radius:6px;border:1px solid #e2e8f0;">
                            <label style="display:block;font-size:12px;font-weight:600;color:#334155;margin-bottom:8px;">
                                <?php _e('Etiquetas especiales / Tags rápidos:', 'bmc-ondemand'); ?>
                            </label>
                            <div id="bmc-quick-tags-wrap" style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
                                <?php
                                $quick_tags = array('FRÁGIL', 'REFRIGERADO', 'PESADO', 'LOCAL', 'INTERIOR');
                                foreach ($quick_tags as $qtag):
                                    ?>
                                    <button type="button" class="button button-small bmc-btn-tag"
                                        data-tag="<?php echo esc_attr($qtag); ?>" style="font-weight:600;border-radius:4px;">
                                        + <?php echo esc_html($qtag); ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                            <div style="margin-top:10px;display:flex;gap:6px;max-width:480px;">
                                <input type="text" id="bmc-custom-tag-input"
                                    placeholder="<?php esc_attr_e('Agregar tag personalizado (ej: URGENTE, PISO 3)', 'bmc-ondemand'); ?>"
                                    style="flex:1;height:28px;font-size:12px;" />
                                <button type="button" class="button button-small" id="bmc-btn-add-custom-tag"
                                    style="height:28px;line-height:26px;">
                                    <?php _e('+ Agregar Tag', 'bmc-ondemand'); ?>
                                </button>
                            </div>
                            <div id="bmc-selected-tags-display" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:4px;"></div>
                            <input type="hidden" id="bmc-label-tags" value="" />
                        </div>

                        <!-- 2. Selector de Sucursal / Despacho si hubo múltiples envíos -->
                        <?php if (count($shipments) > 1): ?>
                            <div style="margin-bottom:16px;background:#f8fafc;padding:12px;border-radius:6px;border:1px solid #e2e8f0;">
                                <label for="bmc-shipment-select"
                                    style="display:block;font-size:12px;font-weight:600;color:#334155;margin-bottom:6px;">
                                    <?php _e('Seleccionar Despacho / Sucursal:', 'bmc-ondemand'); ?>
                                </label>
                                <select id="bmc-shipment-select" style="max-width:420px;font-size:12px;height:32px;">
                                    <option value="<?php echo esc_attr($tracking); ?>"
                                        data-loc-name="<?php esc_attr_e('Todos / General', 'bmc-ondemand'); ?>">
                                        <?php printf(__('General / Tracking principal (%s)', 'bmc-ondemand'), esc_html($tracking)); ?>
                                    </option>
                                    <?php foreach ($shipments as $idx => $sh): ?>
                                        <option value="<?php echo esc_attr($sh['tracking'] ?: $tracking); ?>"
                                            data-loc-name="<?php echo esc_attr($sh['locationName'] ?? ('Envío #' . ($idx + 1))); ?>">
                                            <?php echo esc_html(($sh['locationName'] ?? ('Envío #' . ($idx + 1))) . ($sh['tracking'] ? ' - Tracking: ' . $sh['tracking'] : '')); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php else: ?>
                            <input type="hidden" id="bmc-shipment-select" value="<?php echo esc_attr($tracking); ?>" data-loc-name="" />
                        <?php endif; ?>

                        <!-- 3. Campo propio de nota solo para la etiqueta -->
                        <div style="margin-bottom:18px;">
                            <label for="bmc_label_custom_note"
                                style="display:block;font-size:12px;font-weight:600;color:#334155;margin-bottom:6px;">
                                <?php _e('Nota para la etiqueta (INSTRUCCIONES / ENTREGA):', 'bmc-ondemand'); ?>
                            </label>
                            <input type="text" id="bmc_label_custom_note" class="large-text"
                                placeholder="<?php esc_attr_e('Ej: Entregar en recepción / Cobrar contra entrega RD$2,000 / Llamar antes de llegar', 'bmc-ondemand'); ?>"
                                value="<?php echo esc_attr($initial_note); ?>"
                                style="border-radius:4px;font-size:12px;height:34px;" />
                            <p class="description" style="margin-top:4px;font-size:11px;color:#64748b;">
                                <?php _e('Este texto se imprimirá exclusivamente en la etiqueta en la sección de instrucciones.', 'bmc-ondemand'); ?>
                            </p>
                        </div>

                        <!-- 4. Botón Único de Impresión -->
                        <div style="padding-top:12px;border-top:1px solid #e2e8f0;display:flex;align-items:center;gap:12px;">
                            <button type="button" class="button button-primary button-hero" id="bmc-btn-print-single-label"
                                data-order-id="<?php echo esc_attr($order_id); ?>"
                                data-base-url="<?php echo esc_attr(admin_url('admin-ajax.php?action=bmc_print_label')); ?>"
                                style="background:#008060;border-color:#008060;color:#fff;display:inline-flex;align-items:center;gap:8px;font-weight:bold;font-size:14px;padding:0 24px;">
                                <span class="dashicons dashicons-printer" style="font-size:20px;line-height:36px;"></span>
                                <?php _e('Imprimir Etiqueta', 'bmc-ondemand'); ?>
                            </button>
                            <span style="font-size:13px;color:#334155;">
                                Tracking asignado: <strong><?php echo esc_html($tracking); ?></strong>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- Footer con versión del plugin y estado -->
            <div
                style="margin-top:20px;padding-top:12px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#94a3b8;">
                <div style="display:flex;align-items:center;gap:6px;">
                    <img src="<?php echo esc_url(BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-60px.png'); ?>" alt="BMC"
                        style="height:14px;width:auto;opacity:0.7;">
                    <span>BMC OnDemand for WooCommerce</span>
                </div>
                <div>
                    <span>Versión <strong>v<?php echo esc_html(BMC_ONDEMAND_VERSION); ?></strong></span>
                </div>
            </div>
        </div>

        <script>
            if (typeof window.bmc_dispatch_params === 'undefined') {
                window.bmc_dispatch_params = {
                    ajax_url: <?php echo json_encode(admin_url('admin-ajax.php')); ?>,
                    nonce: <?php echo json_encode(wp_create_nonce('bmc_dispatch_nonce')); ?>
                };
            }
        </script>
        <?php
    }

    public static function ajax_dispatch_selected_items()
    {
        check_ajax_referer('bmc_dispatch_nonce', 'security');
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error('No autorizado');
        }

        $order_id = intval($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error('Pedido no encontrado');
        }

        $locations_map = is_array($_POST['locations'] ?? null) ? $_POST['locations'] : array();
        $weights_map = is_array($_POST['weights'] ?? null) ? $_POST['weights'] : array();
        $delivery_notes = sanitize_textarea_field($_POST['delivery_notes'] ?? '');

        $result = BMC_Order_Dispatcher::dispatch_items($order, $locations_map, $weights_map, $delivery_notes);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            $error_msg = $result['message'] ?? '';
            if (empty($error_msg) && !empty($result['results'])) {
                $errors_list = array();
                foreach ($result['results'] as $loc => $res) {
                    if (!empty($res['error'])) {
                        $errors_list[] = "[Sucursal {$loc}]: " . $res['error'];
                    }
                }
                if (!empty($errors_list)) {
                    $error_msg = implode(' | ', $errors_list);
                }
            }
            wp_send_json_error($error_msg ?: 'Error al despachar ítems');
        }
    }
}

BMC_Order_Meta_Box::init();
