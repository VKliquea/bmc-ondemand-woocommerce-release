<?php
/**
 * Metabox Avanzado en Edición de Pedido (Item-Level Dispatch UI)
 * Equivale a ActionExtension.jsx de Shopify
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Order_Meta_Box {

    public static function init() {
        add_action('add_meta_boxes', array(__CLASS__, 'register_meta_box'), 30);
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
        add_action('wp_ajax_bmc_dispatch_selected_items', array(__CLASS__, 'ajax_dispatch_selected_items'));
    }

    public static function register_meta_box() {
        // Si la tienda no está aprobada (active), no mostrar el metabox de despacho
        $api = BMC_API_Client::get_instance();
        if ($api->get_store_status() !== 'active') {
            return;
        }

        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') &&
                  \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
                  ? wc_get_page_screen_id('shop-order')
                  : 'shop_order';

        add_meta_box(
            'bmc_ondemand_dispatch_box',
            __('BMC OnDemand — Despacho por Ítems y Sucursal', 'bmc-ondemand'),
            array(__CLASS__, 'render_dispatch_box'),
            $screen,
            'normal',
            'high'
        );
    }

    public static function enqueue_assets($hook) {
        if (in_array($hook, array('post.php', 'post-new.php', 'woocommerce_page_wc-orders'))) {
            wp_enqueue_script(
                'sweetalert2',
                'https://cdn.jsdelivr.net/npm/sweetalert2@11',
                array(),
                '11.0.0',
                true
            );

            wp_enqueue_script(
                'bmc-admin-order-dispatch',
                BMC_ONDEMAND_PLUGIN_URL . 'assets/js/admin-order-dispatch.js',
                array('jquery', 'sweetalert2'),
                BMC_ONDEMAND_VERSION,
                true
            );

            wp_localize_script('bmc-admin-order-dispatch', 'bmc_dispatch_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('bmc_dispatch_nonce'),
            ));
        }
    }

    public static function render_dispatch_box($post_or_order) {
        $order = ($post_or_order instanceof \WC_Order) ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order) return;

        $order_id = $order->get_id();
        $locations = BMC_Locations::get_all();
        $default_loc = BMC_Locations::get_default_location_id();
        $sent_items = (array) $order->get_meta('_bmc_sent_items', true) ?: array();
        $status = $order->get_meta('_bmc_status') ?: 'No enviado';
        $tracking = $order->get_meta('_bmc_tracking');
        ?>
        <div class="bmc-dispatch-panel">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                <div>
                    <strong>Estado Delivery:</strong>
                    <span class="badge" style="background:#e0f2fe;color:#0369a1;padding:3px 10px;border-radius:4px;font-weight:600;">
                        <?php echo esc_html(strtoupper($status)); ?>
                    </span>
                    <?php if ($tracking): ?>
                        <span style="margin-left:12px;">Tracking: <code><?php echo esc_html($tracking); ?></code></span>
                    <?php endif; ?>
                </div>
                <div>
                    <button type="button" class="button button-primary" id="bmc-btn-dispatch-all" data-order-id="<?php echo esc_attr($order_id); ?>">
                        <?php _e('Despachar Ítems Seleccionados', 'bmc-ondemand'); ?>
                    </button>
                </div>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:40px;text-align:center;">
                            <input type="checkbox" id="bmc-select-all-items" title="<?php esc_attr_e('Seleccionar todos', 'bmc-ondemand'); ?>" checked>
                        </th>
                        <th style="width:85px;">Estado</th>
                        <th>Producto / Ítem</th>
                        <th style="width:120px;">Cant. y Precio</th>
                        <th style="width:140px;">
                            <span>Peso (lb) *</span>
                            <div style="margin-top:4px;">
                                <input type="number" step="0.01" min="0.01" id="bmc-bulk-weight" placeholder="Lote (lb)" style="width:85px;font-size:11px;padding:2px 4px;height:24px;" title="Aplicar este peso a todos los ítems">
                                <button type="button" class="button button-small" id="bmc-btn-apply-bulk-weight" style="font-size:11px;height:24px;line-height:22px;padding:0 5px;" title="Aplicar peso a todos">&#10003;</button>
                            </div>
                        </th>
                        <th style="width:250px;">
                            <span>Sucursal de Origen (Pickup)</span>
                            <div style="margin-top:4px;display:flex;gap:4px;align-items:center;">
                                <select id="bmc-bulk-location" style="width:100%;font-size:11px;height:24px;padding:1px 4px;" title="Seleccionar sucursal en lote">
                                    <option value="">-- Aplicar sucursal a todos --</option>
                                    <option value="<?php echo esc_attr(BMC_Order_Dispatcher::NO_ENVIAR_VALUE); ?>">-- Enviar después (No enviar ahora) --</option>
                                    <?php foreach ($locations as $loc): ?>
                                        <option value="<?php echo esc_attr($loc['locationId']); ?>">
                                            <?php echo esc_html($loc['name'] ?? $loc['locationId']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order->get_items() as $item_id => $item): 
                        $str_id = (string) $item_id;
                        $is_sent = in_array($str_id, $sent_items, true);
                        $product = $item->get_product();
                        $weight_unit = get_option('woocommerce_weight_unit', 'kg');
                        $raw_weight = $product ? floatval($product->get_weight()) : 0.0;
                        $weight_lb = 0.0;
                        if ($raw_weight > 0) {
                            $weight_lb = ($weight_unit === 'kg') ? $raw_weight * 2.20462 : (($weight_unit === 'g') ? ($raw_weight / 1000) * 2.20462 : $raw_weight);
                        }
                    ?>
                        <tr class="<?php echo $is_sent ? 'bmc-row-sent' : ''; ?>" data-item-id="<?php echo esc_attr($str_id); ?>">
                            <td style="text-align:center;vertical-align:middle;">
                                <?php if ($is_sent): ?>
                                    <input type="checkbox" disabled>
                                <?php else: ?>
                                    <input type="checkbox" class="bmc-item-checkbox" value="1" checked>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($is_sent): ?>
                                    <span style="color:#16a34a;font-weight:bold;">&#10003; Enviado</span>
                                <?php else: ?>
                                    <span style="color:#d97706;font-weight:600;">Pendiente</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo esc_html($item->get_name()); ?></strong>
                            </td>
                            <td>
                                <?php echo esc_html($item->get_quantity()); ?> x <?php echo wc_price($order->get_item_total($item, false)); ?>
                            </td>
                            <td>
                                <input type="number" step="0.01" min="0.01" class="bmc-item-weight" value="<?php echo $weight_lb > 0 ? esc_attr(round($weight_lb, 2)) : ''; ?>" placeholder="Obligatorio" <?php disabled($is_sent); ?> style="width:95px; <?php echo ($weight_lb <= 0 && !$is_sent) ? 'border-color:#ef4444;background:#fff5f5;' : ''; ?>">
                            </td>
                            <td>
                                <select class="bmc-item-location" <?php disabled($is_sent); ?> style="width:100%;">
                                    <option value="<?php echo esc_attr(BMC_Order_Dispatcher::NO_ENVIAR_VALUE); ?>">-- Enviar después (No enviar ahora) --</option>
                                    <?php foreach ($locations as $loc): ?>
                                        <option value="<?php echo esc_attr($loc['locationId']); ?>" <?php selected($default_loc, $loc['locationId']); ?>>
                                            <?php echo esc_html($loc['name'] ?? $loc['locationId']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Notas de Entrega para BMC OnDemand -->
            <?php
            // Calcular nota por defecto según método de pago:
            // Si es manual/COD -> "[Método] - [Total]"
            // Si es electrónico -> vacío
            $default_delivery_note = BMC_Order_Dispatcher::get_default_delivery_note($order);
            $initial_note = !empty($default_delivery_note) ? $default_delivery_note : '';
            ?>
            <div style="margin-top:16px;padding-top:14px;border-top:1px solid #e2e8f0;">
                <label for="bmc_delivery_notes" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                    <?php _e('Notas de Entrega / Instrucciones:', 'bmc-ondemand'); ?>
                </label>
                <textarea id="bmc_delivery_notes" class="large-text" rows="2" placeholder="<?php esc_attr_e('Agregar notas o indicaciones especiales para la entrega...', 'bmc-ondemand'); ?>" style="border-radius:6px;border-color:#cbd5e1;"><?php echo esc_textarea($initial_note); ?></textarea>
                <p class="description" style="margin-top:4px;color:#64748b;">
                    <?php _e('Estas notas se enviarán junto con el pedido a BMC OnDemand.', 'bmc-ondemand'); ?>
                </p>
            </div>
        </div>
        <?php
    }

    public static function ajax_dispatch_selected_items() {
        check_ajax_referer('bmc_dispatch_nonce', 'security');
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error('No autorizado');
        }

        $order_id = intval($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error('Pedido no encontrado');
        }

        $locations_map  = is_array($_POST['locations'] ?? null) ? $_POST['locations'] : array();
        $weights_map    = is_array($_POST['weights'] ?? null) ? $_POST['weights'] : array();
        $delivery_notes = sanitize_textarea_field($_POST['delivery_notes'] ?? '');

        $result = BMC_Order_Dispatcher::dispatch_items($order, $locations_map, $weights_map, $delivery_notes);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            $error_msg = $result['message'] ?? '';
            if (empty($error_msg) && !empty($result['results'])) {
                $errors_list = array();
                foreach ($result['results'] as $loc => $res) {
                    if (!empty($res['error'])) {
                        $errors_list[] = "[Sucursal {$loc}]: " . $res['error'];
                    }
                }
                if (!empty($errors_list)) {
                    $error_msg = implode(' | ', $errors_list);
                }
            }
            wp_send_json_error($error_msg ?: 'Error al despachar ítems');
        }
    }
}

BMC_Order_Meta_Box::init();
