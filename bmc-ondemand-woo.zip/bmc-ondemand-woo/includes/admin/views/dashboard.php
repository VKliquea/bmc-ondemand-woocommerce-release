<?php
/**
 * Vista de Dashboard para BMC OnDemand WooCommerce
 * Idéntico y fiel al diseño de Shopify
 */

if (!defined('ABSPATH')) {
    exit;
}

$logo_bm_url = BMC_ONDEMAND_PLUGIN_URL . 'assets/images/logobm.gif';
$logo_bmc_url = BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png';

// Parámetros de filtrado
$filters = array(
    'status' => sanitize_text_field($_GET['status'] ?? 'all'),
    'from_date' => sanitize_text_field($_GET['from_date'] ?? ''),
    'to_date' => sanitize_text_field($_GET['to_date'] ?? ''),
    'limit' => max(1, intval($_GET['limit'] ?? 10)),
    'page' => max(1, intval($_GET['paged'] ?? 1)),
);

$dashboard_data = BMC_Dashboard_Service::get_dashboard_data($filters);
$metrics = $dashboard_data['metrics'];
$orders = $dashboard_data['orders'];
$total_pages = $dashboard_data['total_pages'];
$current_page = $dashboard_data['current_page'];
?>

<div class="wrap bmc-dashboard-wrap">

    <div class="bmc-dashboard-title-header">
        <div class="bmc-dashboard-title-left">
            <h1><?php esc_html_e('Dashboard', 'bmc-ondemand'); ?></h1>
            <span class="bmc-dashboard-version-badge">v<?php echo esc_html(BMC_ONDEMAND_VERSION); ?></span>
        </div>
    </div>

    <!-- 1. Hero Banner Azul Degradado -->
    <div class="bmc-hero-banner">
        <div class="bmc-hero-left">

            <img src="<?php echo esc_url($logo_bm_url); ?>" alt="logobm" class="bmc-hero-logo">
        </div>

        <div class="bmc-hero-center">
            <h2 class="bmc-hero-title"><?php esc_html_e('Bienvenido al Dashboard de BMC On Demand', 'bmc-ondemand'); ?>
            </h2>
            <p class="bmc-hero-desc">
                <?php esc_html_e('Monitorea tus entregas, revisa el estado de órdenes recientes y gestiona tu servicio de entrega.', 'bmc-ondemand'); ?>
            </p>
        </div>

        <div class="bmc-hero-right">
            <img src="<?php echo esc_url($logo_bmc_url); ?>" alt="BMC Logo" class="bmc-hero-logo"
                onerror="this.src='<?php echo esc_url($logo_bmc_url); ?>';">
            <span class="bmc-hero-version-pill">v<?php echo esc_html(BMC_ONDEMAND_VERSION); ?></span>
        </div>
    </div>

    <!-- 2. Tarjetas Métricas (KPIs) -->
    <div class="bmc-metrics-grid">

        <!-- Total de Entregas -->
        <div class="bmc-metric-card">
            <div class="bmc-metric-header">
                <span class="bmc-metric-label"><?php esc_html_e('Total de Entregas', 'bmc-ondemand'); ?></span>
            </div>
            <div class="bmc-metric-body">
                <span class="bmc-metric-value"><?php echo esc_html($metrics['total_deliveries']); ?></span>
                <span class="bmc-badge-growth">
                    &uarr; <?php echo esc_html($metrics['growth_rate']); ?>
                </span>
            </div>
        </div>

        <!-- Paquetes Entregados -->
        <div class="bmc-metric-card">
            <div class="bmc-metric-header">
                <span class="bmc-metric-label"><?php esc_html_e('Paquetes Entregados', 'bmc-ondemand'); ?></span>
            </div>
            <div class="bmc-metric-body">
                <span class="bmc-metric-value"><?php echo esc_html($metrics['packages_delivered']); ?></span>
                <span class="bmc-badge-efficiency">
                    <?php echo esc_html($metrics['efficiency']); ?> <?php esc_html_e('efic.', 'bmc-ondemand'); ?>
                </span>
            </div>
        </div>

        <!-- Tasa de Retorno -->
        <div class="bmc-metric-card">
            <div class="bmc-metric-header">
                <span class="bmc-metric-label"><?php esc_html_e('Tasa de Retorno', 'bmc-ondemand'); ?></span>
            </div>
            <div class="bmc-metric-body">
                <span class="bmc-metric-value"><?php echo esc_html($metrics['return_rate']); ?></span>
                <span class="bmc-badge-pill-green">
                    <?php esc_html_e('Excelente', 'bmc-ondemand'); ?>
                </span>
            </div>
        </div>

        <!-- Órdenes en curso -->
        <div class="bmc-metric-card">
            <div class="bmc-metric-header">
                <span class="bmc-metric-label"><?php esc_html_e('Órdenes en curso', 'bmc-ondemand'); ?></span>
            </div>
            <div class="bmc-metric-body">
                <span class="bmc-metric-value"><?php echo esc_html($metrics['ongoing_orders']); ?></span>
                <span class="bmc-badge-pill-blue">
                    <?php esc_html_e('Normal', 'bmc-ondemand'); ?>
                </span>
            </div>
        </div>

    </div>

    <!-- 3. Contenedor de Filtros y Tabla -->
    <div class="bmc-card bmc-table-container-card">

        <h3 class="bmc-filters-heading"><?php esc_html_e('Filtros de Órdenes', 'bmc-ondemand'); ?></h3>

        <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="bmc-filters-bar">
            <input type="hidden" name="page" value="bmc-ondemand">

            <!-- Selector de Estado -->
            <div class="bmc-filter-control">
                <select name="status" id="status" class="bmc-filter-select">
                    <option value="all" <?php selected($filters['status'], 'all'); ?>><?php esc_html_e('Todos los estados', 'bmc-ondemand'); ?></option>
                    <option value="created" <?php selected($filters['status'], 'created'); ?>><?php esc_html_e('Creado', 'bmc-ondemand'); ?></option>
                    <option value="pending" <?php selected($filters['status'], 'pending'); ?>><?php esc_html_e('Pendiente', 'bmc-ondemand'); ?></option>
                    <option value="ongoing" <?php selected($filters['status'], 'ongoing'); ?>><?php esc_html_e('En Curso / Tránsito', 'bmc-ondemand'); ?></option>
                    <option value="delivered" <?php selected($filters['status'], 'delivered'); ?>><?php esc_html_e('Entregado', 'bmc-ondemand'); ?></option>
                    <option value="failed" <?php selected($filters['status'], 'failed'); ?>><?php esc_html_e('Fallido', 'bmc-ondemand'); ?></option>
                </select>
            </div>

            <!-- Rango de Fechas: Desde -->
            <div class="bmc-filter-control bmc-date-group">
                <span class="bmc-date-inline-label"><?php esc_html_e('Desde', 'bmc-ondemand'); ?></span>
                <input type="date" name="from_date" id="from_date" value="<?php echo esc_attr($filters['from_date']); ?>" class="bmc-filter-date">
            </div>

            <!-- Rango de Fechas: Hasta -->
            <div class="bmc-filter-control bmc-date-group">
                <span class="bmc-date-inline-label"><?php esc_html_e('Hasta', 'bmc-ondemand'); ?></span>
                <input type="date" name="to_date" id="to_date" value="<?php echo esc_attr($filters['to_date']); ?>" class="bmc-filter-date">
            </div>

            <!-- Paginación / Límite -->
            <div class="bmc-filter-control">
                <select name="limit" id="limit" class="bmc-filter-select">
                    <option value="10" <?php selected($filters['limit'], 10); ?>><?php esc_html_e('10 por pág.', 'bmc-ondemand'); ?></option>
                    <option value="25" <?php selected($filters['limit'], 25); ?>><?php esc_html_e('25 por pág.', 'bmc-ondemand'); ?></option>
                    <option value="50" <?php selected($filters['limit'], 50); ?>><?php esc_html_e('50 por pág.', 'bmc-ondemand'); ?></option>
                </select>
            </div>

            <!-- Botones de Acción -->
            <div class="bmc-filter-actions">
                <button type="submit" class="button button-secondary bmc-btn-filter">
                    <span class="dashicons dashicons-search"></span> <?php esc_html_e('Filtrar', 'bmc-ondemand'); ?>
                </button>
                <a href="<?php echo esc_url(admin_url('admin.php?page=bmc-ondemand')); ?>" class="button button-secondary bmc-btn-clear">
                    <span class="dashicons dashicons-update"></span> <?php esc_html_e('Limpiar', 'bmc-ondemand'); ?>
                </a>
            </div>
        </form>

            <!-- Resumen de Filtros Activos si hay alguno aplicado -->
            <?php if ($filters['status'] !== 'all' || !empty($filters['from_date']) || !empty($filters['to_date'])): ?>
                <div class="bmc-active-filters-summary">
                    <span class="dashicons dashicons-filter"></span>
                    <span><?php printf(esc_html__('Filtro activo: Mostrando %d de %d órdenes', 'bmc-ondemand'), count($orders), $dashboard_data['total_orders']); ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=bmc-ondemand')); ?>" class="bmc-clear-filter-link"><?php esc_html_e('Quitar filtros', 'bmc-ondemand'); ?></a>
                </div>
            <?php endif; ?>

        <!-- Tabla de Órdenes -->
        <table class="wp-list-table widefat fixed striped bmc-orders-table">
            <thead>
                <tr>
                    <th style="width: 80px;"><?php esc_html_e('ID', 'bmc-ondemand'); ?></th>
                    <th style="width: 170px;"><?php esc_html_e('Cliente', 'bmc-ondemand'); ?></th>
                    <th><?php esc_html_e('Dirección', 'bmc-ondemand'); ?></th>
                    <th style="width: 130px;"><?php esc_html_e('Estado', 'bmc-ondemand'); ?></th>
                    <th style="width: 120px;"><?php esc_html_e('Fecha', 'bmc-ondemand'); ?></th>
                    <th style="width: 120px; text-align: right;"><?php esc_html_e('Acciones', 'bmc-ondemand'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 30px; color: #64748b;">
                            <span class="dashicons dashicons-car"
                                style="font-size: 32px; width: 32px; height: 32px; opacity: 0.5;"></span>
                            <p style="margin-top: 8px;">
                                <?php esc_html_e('No hay órdenes para mostrar con los filtros seleccionados.', 'bmc-ondemand'); ?>
                            </p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td class="bmc-order-id-cell">
                                <strong><?php echo esc_html($order['id']); ?></strong>
                            </td>
                            <td class="bmc-customer-cell">
                                <strong><?php echo esc_html($order['customer_name']); ?></strong>
                            </td>
                            <td class="bmc-address-cell" title="<?php echo esc_attr($order['address']); ?>">
                                <?php echo esc_html($order['address']); ?>
                            </td>
                            <td>
                                <span class="bmc-status-badge <?php echo esc_attr($order['status_class']); ?>">
                                    <span class="dashicons <?php echo esc_attr($order['status_icon']); ?>"></span>
                                    <?php echo esc_html($order['status_label']); ?>
                                </span>
                            </td>
                            <td class="bmc-date-cell">
                                <?php echo esc_html($order['date']); ?>
                            </td>
                            <td style="text-align: right;">
                                <?php if (!empty($order['wc_order_id'])): ?>
                                    <a href="<?php echo esc_url(admin_url('post.php?post=' . $order['wc_order_id'] . '&action=edit')); ?>"
                                        class="bmc-action-link" target="_blank">
                                        <span class="dashicons dashicons-visibility"></span>
                                        <?php esc_html_e('Ver orden', 'bmc-ondemand'); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="bmc-action-disabled">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Paginación -->
        <?php if ($total_pages > 1): ?>
            <div class="bmc-pagination-wrap">
                <span class="bmc-page-indicator">
                    <?php printf(esc_html__('Página %d de %d', 'bmc-ondemand'), $current_page, $total_pages); ?>
                </span>

                <div class="bmc-pagination-buttons">
                    <?php if ($current_page > 1): ?>
                        <a href="<?php echo esc_url(add_query_arg('paged', $current_page - 1)); ?>"
                            class="button button-secondary bmc-page-btn">&lsaquo;</a>
                    <?php else: ?>
                        <button class="button button-secondary bmc-page-btn" disabled>&lsaquo;</button>
                    <?php endif; ?>

                    <?php if ($current_page < $total_pages): ?>
                        <a href="<?php echo esc_url(add_query_arg('paged', $current_page + 1)); ?>"
                            class="button button-secondary bmc-page-btn">&rsaquo;</a>
                    <?php else: ?>
                        <button class="button button-secondary bmc-page-btn" disabled>&rsaquo;</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    </div>

</div>