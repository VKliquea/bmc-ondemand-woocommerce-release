<?php
/**
 * Vista de Administración: Configuración de Branding de Etiquetas
 * Adaptada fielmente al diseño oficial de BMC OnDemand (bmc-admin-container)
 */

if (!defined('ABSPATH')) {
    exit;
}

$branding = BMC_Label_Printer::get_branding_config();
$saved = isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true';
?>

<div class="wrap bmc-admin-container">
    <form method="post" action="options.php" id="bmc-branding-form">
        <?php
        settings_fields('bmc_ondemand_branding_group');
        do_settings_sections('bmc_ondemand_branding_group');
        ?>

        <!-- Encabezado con Botón Guardar idéntico al resto de pantallas -->
        <div class="bmc-admin-header">
            <div>
                <h1 class="bmc-admin-title">Branding de Etiquetas (4x6)</h1>
                <p style="color:#64748b;font-size:13px;margin:4px 0 0 0;">
                    <?php _e('Personaliza el diseño térmico de 4x6 con tu logo, razón social y datos que acompañan cada envío.', 'bmc-ondemand'); ?>
                </p>
            </div>
            <button type="submit" class="bmc-btn-save">
                <?php _e('Guardar Cambios de Branding', 'bmc-ondemand'); ?>
            </button>
        </div>

        <?php if ($saved): ?>
            <div class="notice notice-success is-dismissible" style="margin-bottom:20px;border-left-color:#008060;">
                <p><strong><?php _e('¡Configuración de branding guardada exitosamente!', 'bmc-ondemand'); ?></strong></p>
            </div>
        <?php endif; ?>

        <!-- Grid Principal de 2 Columnas idéntico a Configuración -->
        <div class="bmc-layout-grid">

            <!-- Columna Izquierda: Formulario de Branding -->
            <div class="bmc-card">
                <h2 class="bmc-card-title"><?php _e('Información de la Marca y Remitente', 'bmc-ondemand'); ?></h2>

                <!-- 1. Logo de la Empresa -->
                <div class="bmc-form-group">
                    <label for="bmc_branding_logo"><?php _e('Logo de la Empresa (URL o Imagen)', 'bmc-ondemand'); ?></label>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="bmc_branding_logo" name="bmc_ondemand_branding_logo"
                            value="<?php echo esc_attr($branding['logo_url']); ?>"
                            class="bmc-input" style="flex:1;" placeholder="https://tudominio.com/logo.png" />
                        <button type="button" class="button" id="bmc_btn_upload_logo" style="height:38px;padding:0 14px;border-radius:8px;font-weight:600;border-color:#cbd5e1;">
                            <?php _e('Subir Logo', 'bmc-ondemand'); ?>
                        </button>
                    </div>
                    <p class="bmc-field-help"><?php _e('Recomendado: formato PNG o JPG con fondo transparente o blanco.', 'bmc-ondemand'); ?></p>
                </div>

                <!-- 2. Nombre Comercial -->
                <div class="bmc-form-group">
                    <label for="bmc_branding_business_name"><?php _e('Nombre Comercial de la Empresa', 'bmc-ondemand'); ?></label>
                    <input type="text" id="bmc_branding_business_name" name="bmc_ondemand_branding_business_name"
                        value="<?php echo esc_attr($branding['business_name']); ?>"
                        class="bmc-input" placeholder="Mi Empresa S.R.L." required />
                    <p class="bmc-field-help"><?php _e('Aparecerá en el encabezado y en el remitente de la etiqueta.', 'bmc-ondemand'); ?></p>
                </div>

                <!-- 3. Dirección de Despacho -->
                <div class="bmc-form-group">
                    <label for="bmc_branding_address"><?php _e('Dirección de Despacho (Origen / Remitente)', 'bmc-ondemand'); ?></label>
                    <textarea id="bmc_branding_address" name="bmc_ondemand_branding_address"
                        rows="3" class="bmc-input" style="height:auto;resize:vertical;"
                        placeholder="Av. Principal #123, Almacén 4, Santo Domingo, D.N."><?php echo esc_textarea($branding['dispatch_address']); ?></textarea>
                    <p class="bmc-field-help"><?php _e('Dirección física desde donde se originan o retornan los paquetes.', 'bmc-ondemand'); ?></p>
                </div>

                <!-- 4. Teléfono -->
                <div class="bmc-form-group">
                    <label for="bmc_branding_phone"><?php _e('Teléfono de Contacto de la Empresa', 'bmc-ondemand'); ?></label>
                    <input type="text" id="bmc_branding_phone" name="bmc_ondemand_branding_phone"
                        value="<?php echo esc_attr($branding['phone']); ?>"
                        class="bmc-input" placeholder="+1 (809) 000-0000" />
                </div>

                <!-- 5. Subtítulo o Lema -->
                <div class="bmc-form-group">
                    <label for="bmc_branding_subtitle"><?php _e('Subtítulo o Lema en la Etiqueta', 'bmc-ondemand'); ?></label>
                    <input type="text" id="bmc_branding_subtitle" name="bmc_ondemand_branding_subtitle"
                        value="<?php echo esc_attr($branding['subtitle']); ?>"
                        class="bmc-input" placeholder="Logística · Despacho a Domicilio" />
                </div>

                <!-- 6. Texto al pie -->
                <div class="bmc-form-group" style="margin-bottom:8px;">
                    <label for="bmc_branding_footer"><?php _e('Texto de Marca al Pie de Página', 'bmc-ondemand'); ?></label>
                    <input type="text" id="bmc_branding_footer" name="bmc_ondemand_branding_footer"
                        value="<?php echo esc_attr($branding['footer_brand']); ?>"
                        class="bmc-input" placeholder="Kliquea · BMC OnDemand" />
                </div>

            </div>

            <!-- Columna Derecha: Previsualización en Vivo de la Etiqueta 4x6 -->
            <div>
                <div class="bmc-card" style="padding:20px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;border-bottom:1px solid #f1f5f9;padding-bottom:12px;">
                        <h2 class="bmc-card-title" style="margin:0;display:flex;align-items:center;gap:8px;font-size:15px;">
                            <span class="dashicons dashicons-visibility" style="color:#008060;font-size:20px;width:20px;height:20px;"></span>
                            <?php _e('Vista Previa en Vivo (4x6)', 'bmc-ondemand'); ?>
                        </h2>
                        <span style="font-size:10px;font-weight:700;color:#64748b;background:#f1f5f9;padding:2px 8px;border-radius:10px;">
                            ESCALA 100%
                        </span>
                    </div>

                    <!-- Contenedor de la Etiqueta 4x6 -->
                    <div id="bmc-preview-container" style="background:#fff;border:2px dashed #cbd5e1;border-radius:8px;padding:16px;box-shadow:0 4px 14px rgba(0,0,0,0.06);font-family:Arial,sans-serif;">
                        <!-- Header de Etiqueta -->
                        <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #000;padding-bottom:8px;margin-bottom:10px;">
                            <div>
                                <img id="preview-logo" src="<?php echo esc_url($branding['logo_url'] ?: BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png'); ?>"
                                    style="height:36px;max-width:180px;object-fit:contain;display:block;" />
                                <div id="preview-subtitle" style="font-size:10px;font-weight:bold;color:#003366;margin-top:2px;">
                                    <?php echo esc_html($branding['subtitle'] ?: 'LOGÍSTICA · DESPACHO A DOMICILIO'); ?>
                                </div>
                            </div>
                            <div style="font-size:11px;font-weight:bold;color:#1e293b;"><?php echo date('d/m/Y'); ?></div>
                        </div>

                        <!-- Número de Pedido -->
                        <div style="margin-bottom:12px;">
                            <div style="font-size:10px;font-weight:bold;color:#003366;display:flex;justify-content:space-between;">
                                <span>NO. DE PEDIDO EN <span id="preview-store-name-sub"><?php echo esc_html($branding['business_name']); ?></span></span>
                                <span>1 ÍTEM</span>
                            </div>
                            <div style="font-size:22px;font-weight:900;letter-spacing:-0.5px;color:#0f172a;">#1142</div>
                        </div>

                        <!-- Remitente -->
                        <div style="margin-bottom:12px;font-size:11px;line-height:1.35;border-top:1px dashed #e2e8f0;padding-top:8px;">
                            <div style="font-size:10px;font-weight:bold;color:#003366;margin-bottom:2px;">REMITENTE (ORIGEN)</div>
                            <strong id="preview-business-name" style="color:#0f172a;"><?php echo esc_html($branding['business_name'] ?: 'Mi Tienda'); ?></strong><br>
                            <span id="preview-address" style="color:#475569;"><?php echo esc_html($branding['dispatch_address'] ?: 'Dirección de la empresa...'); ?></span>
                        </div>

                        <!-- Destinatario -->
                        <div style="margin-bottom:12px;font-size:11px;line-height:1.35;border-top:1px dashed #e2e8f0;padding-top:8px;">
                            <div style="font-size:10px;font-weight:bold;color:#003366;margin-bottom:2px;">DESTINATARIO (CLIENTE)</div>
                            <strong style="color:#0f172a;">JAYZA ROSSO</strong><br>
                            <span style="color:#475569;">Residencial Luis Emilio, Av. Gustavo Mejía Ricart 154, Distrito Nacional, DO · Tel: 8296429849</span>
                        </div>

                        <!-- Pie de la Etiqueta con QR -->
                        <div style="border-top:2px solid #000;padding-top:10px;margin-top:16px;display:flex;justify-content:space-between;align-items:flex-end;">
                            <div>
                                <div style="font-size:10px;color:#334155;">
                                    <strong id="preview-footer"><?php echo esc_html($branding['footer_brand'] ?: 'Kliquea · BMC OnDemand'); ?></strong> &bull; Pedido #1142
                                </div>
                            </div>
                            <div style="display:flex;flex-direction:column;align-items:center;">
                                <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=2&data=ad1f59f1" style="width:65px;height:65px;display:block;" alt="QR" />
                                <span style="font-size:9px;font-weight:700;color:#000;margin-top:2px;font-family:monospace;">ad1f59f1</span>
                            </div>
                        </div>
                    </div>

                    <p style="font-size:11px;color:#94a3b8;margin:12px 0 0 0;text-align:center;">
                        <?php _e('Los cambios se actualizan automáticamente en tiempo real.', 'bmc-ondemand'); ?>
                    </p>
                </div>
            </div>

        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // Media Uploader de WordPress para el Logo
    $('#bmc_btn_upload_logo').on('click', function(e) {
        e.preventDefault();
        var customUploader = wp.media({
            title: '<?php _e('Seleccionar Logo para Etiquetas', 'bmc-ondemand'); ?>',
            button: {
                text: '<?php _e('Usar este Logo', 'bmc-ondemand'); ?>'
            },
            multiple: false
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').first().toJSON();
            $('#bmc_branding_logo').val(attachment.url).trigger('input');
        });

        customUploader.open();
    });

    // Actualización reactiva del Live Preview
    $('#bmc_branding_logo').on('input change', function() {
        var url = $(this).val().trim();
        $('#preview-logo').attr('src', url || '<?php echo esc_js(BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png'); ?>');
    });

    $('#bmc_branding_business_name').on('input change', function() {
        var name = $(this).val().trim() || 'Mi Tienda';
        $('#preview-business-name').text(name);
        $('#preview-store-name-sub').text(name);
    });

    $('#bmc_branding_address, #bmc_branding_phone').on('input change', function() {
        var addr = $('#bmc_branding_address').val().trim();
        var phone = $('#bmc_branding_phone').val().trim();
        var full = addr;
        if (phone) {
            full += (full ? ' · Tel: ' : 'Tel: ') + phone;
        }
        $('#preview-address').text(full || 'Dirección de la empresa...');
    });

    $('#bmc_branding_subtitle').on('input change', function() {
        var sub = $(this).val().trim() || 'LOGÍSTICA · DESPACHO A DOMICILIO';
        $('#preview-subtitle').text(sub.toUpperCase());
    });

    $('#bmc_branding_footer').on('input change', function() {
        var ftr = $(this).val().trim() || 'Kliquea · BMC OnDemand';
        $('#preview-footer').text(ftr);
    });
});
</script>
