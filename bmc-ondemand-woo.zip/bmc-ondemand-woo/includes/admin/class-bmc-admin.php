<?php
/**
 * Panel de Administración de BMC OnDemand en WordPress
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Admin {
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_admin_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_assets'));
    }

    public static function register_admin_menu() {
        // Si no se han aceptado los términos, registrar solo la página de bienvenida legal
        $legal_accepted = get_option('bmc_ondemand_legal_accepted', 'no') === 'yes';

        add_menu_page(
            __('BMC OnDemand', 'bmc-ondemand'),
            __('BMC OnDemand', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand',
            array(__CLASS__, $legal_accepted ? 'render_dashboard_page' : 'render_onboarding_page'),
            BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png',
            56
        );

        if (!$legal_accepted) {
            // No registrar submenús hasta que se acepten los términos
            return;
        }

        // 1. Dashboard (Página de Inicio por defecto)
        add_submenu_page(
            'bmc-ondemand',
            __('Dashboard', 'bmc-ondemand'),
            __('Dashboard', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand',
            array(__CLASS__, 'render_dashboard_page')
        );

        // 2. Configuración
        add_submenu_page(
            'bmc-ondemand',
            __('Configuración', 'bmc-ondemand'),
            __('Configuración', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand-settings',
            array(__CLASS__, 'render_settings_page')
        );

        // 3. Sucursales
        add_submenu_page(
            'bmc-ondemand',
            __('Sucursales / Pickup', 'bmc-ondemand'),
            __('Sucursales', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand-locations',
            array(__CLASS__, 'render_locations_page')
        );

        // 4. Términos y Condiciones
        add_submenu_page(
            'bmc-ondemand',
            __('Términos y Condiciones', 'bmc-ondemand'),
            __('Términos', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand-terms',
            array(__CLASS__, 'render_terms_page')
        );

        // 6. Privacidad
        add_submenu_page(
            'bmc-ondemand',
            __('Política de Privacidad', 'bmc-ondemand'),
            __('Privacidad', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand-privacy',
            array(__CLASS__, 'render_privacy_page')
        );

        // 7. Seguridad
        add_submenu_page(
            'bmc-ondemand',
            __('Seguridad', 'bmc-ondemand'),
            __('Seguridad', 'bmc-ondemand'),
            'manage_woocommerce',
            'bmc-ondemand-security',
            array(__CLASS__, 'render_security_page')
        );
    }

    public static function register_settings() {
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_store_name');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_store_email');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_store_phone');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_store_country');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_store_currency');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_carrier_enabled');
        register_setting('bmc_ondemand_settings_group', 'bmc_ondemand_default_location');
    }

    public static function enqueue_admin_assets($hook) {
        // Encolar CSS del icono de menú en todo el panel de administración
        $icon_url = esc_url(BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png');
        $custom_menu_css = '#adminmenu .toplevel_page_bmc-ondemand .wp-menu-image img { display: none !important; } '
            . '#adminmenu .toplevel_page_bmc-ondemand .wp-menu-image { '
            . 'background-image: url("' . $icon_url . '") !important; '
            . 'background-repeat: no-repeat !important; '
            . 'background-position: center center !important; '
            . 'background-size: 20px 20px !important; '
            . 'opacity: 0.85; '
            . '} '
            . '#adminmenu .toplevel_page_bmc-ondemand:hover .wp-menu-image, '
            . '#adminmenu .toplevel_page_bmc-ondemand.wp-has-current-submenu .wp-menu-image { opacity: 1; }';
        wp_add_inline_style('wp-admin', $custom_menu_css);

        if (strpos($hook, 'bmc-ondemand') !== false || in_array($hook, array('post.php', 'post-new.php', 'woocommerce_page_wc-orders'))) {
            wp_enqueue_style(
                'bmc-ondemand-admin-css',
                BMC_ONDEMAND_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                BMC_ONDEMAND_VERSION
            );
        }
    }

    public static function render_onboarding_page() {
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/legal-onboarding.php';
    }

    public static function render_pending_approval_page() {
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/pending-approval.php';
    }

    public static function is_store_approved() {
        $api = BMC_API_Client::get_instance();
        $status = $api->get_store_status();
        return $status === 'active';
    }

    public static function render_dashboard_page() {
        if (get_option('bmc_ondemand_legal_accepted', 'no') !== 'yes') {
            self::render_onboarding_page();
            return;
        }

        if (!self::is_store_approved()) {
            self::render_pending_approval_page();
            return;
        }

        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/dashboard.php';
    }

    public static function render_settings_page() {
        if (get_option('bmc_ondemand_legal_accepted', 'no') !== 'yes') {
            self::render_onboarding_page();
            return;
        }

        // Si ya fue configurada una vez y la tienda está pendiente de aprobación, mostrar pantalla de revisión
        if (get_option('bmc_ondemand_configured_once', 'no') === 'yes' && !self::is_store_approved()) {
            self::render_pending_approval_page();
            return;
        }

        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/settings.php';
    }

    public static function render_locations_page() {
        if (!self::is_store_approved()) {
            self::render_pending_approval_page();
            return;
        }
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/locations.php';
    }

    public static function render_terms_page() {
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/terms.php';
    }

    public static function render_privacy_page() {
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/privacy.php';
    }

    public static function render_security_page() {
        require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/views/security.php';
    }
}

BMC_Admin::init();
