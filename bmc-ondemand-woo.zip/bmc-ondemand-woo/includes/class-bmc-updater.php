<?php
/**
 * Gestor de Auto-Actualizaciones Directas para BMC OnDemand WooCommerce
 *
 * Se conecta nativamente a la API de actualizaciones de WordPress para permitir
 * actualizaciones con 1 solo clic desde el panel de Plugins de wp-admin.
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Updater {
    const GITHUB_REPO    = 'VKliquea/bmc-ondemand-woocommerce-release';
    const UPDATE_API_URL = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/plugin/woocommerce/update';
    const CACHE_KEY      = 'bmc_ondemand_update_info';
    const CACHE_TTL      = 300; // 5 minutos en segundos para actualizaciones ágiles

    private $plugin_file;
    private $plugin_slug;
    private $version;

    public function __construct($plugin_file, $version) {
        $this->plugin_file = $plugin_file;
        $this->plugin_slug = plugin_basename($plugin_file);
        $this->version     = $version;

        // Inyectar en el chequeo de actualizaciones de plugins de WordPress
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_plugin_update'));

        // Desplegar información técnica y changelog en el modal nativo de WordPress
        add_filter('plugins_api', array($this, 'plugin_popup_information'), 20, 3);

        // Asegurar que la carpeta resultante conserve el nombre original 'bmc-ondemand-woo'
        add_filter('upgrader_source_selection', array($this, 'ensure_correct_folder_name'), 10, 4);

        // Limpiar caché al completar la actualización
        add_action('upgrader_process_complete', array($this, 'clear_cache'), 10, 2);
    }

    /**
     * Consulta el último release directamente desde GitHub (Releases o Tags con fallback a ZIP directo)
     *
     * @return array|null Información del release en formato compatible con WordPress
     */
    public function get_github_release_info() {
        // Intentar primero GitHub Releases API
        $url = 'https://api.github.com/repos/' . self::GITHUB_REPO . '/releases/latest';

        $args = array(
            'timeout' => 12,
            'headers' => array(
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'WordPress/BMC-Updater-' . $this->version,
            ),
        );

        $response = wp_remote_get($url, $args);
        $code = !is_wp_error($response) ? wp_remote_retrieve_response_code($response) : 0;

        if ($code === 200) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($data) && is_array($data)) {
                $tag_name = $data['tag_name'] ?? '';
                $version = ltrim($tag_name, 'vV');
                if (!empty($version)) {
                    $download_url = '';
                    if (!empty($data['assets']) && is_array($data['assets'])) {
                        foreach ($data['assets'] as $asset) {
                            if (isset($asset['name']) && $asset['name'] === 'bmc-ondemand-woo.zip') {
                                $download_url = $asset['browser_download_url'];
                                break;
                            }
                        }
                    }
                    if (empty($download_url)) {
                        $download_url = 'https://github.com/' . self::GITHUB_REPO . '/releases/download/' . $tag_name . '/bmc-ondemand-woo.zip';
                    }

                    return $this->build_plugin_info_array($version, $download_url, $data['body'] ?? '');
                }
            }
        }

        // Si no hay Releases oficiales creados, consultar los Tags directamente
        $tags_url = 'https://api.github.com/repos/' . self::GITHUB_REPO . '/tags';
        $tags_response = wp_remote_get($tags_url, $args);
        if (!is_wp_error($tags_response) && wp_remote_retrieve_response_code($tags_response) === 200) {
            $tags = json_decode(wp_remote_retrieve_body($tags_response), true);
            if (!empty($tags) && is_array($tags)) {
                $latest_tag = $tags[0]['name'] ?? '';
                $version = ltrim($latest_tag, 'vV');
                if (!empty($version)) {
                    $download_url = 'https://github.com/' . self::GITHUB_REPO . '/releases/download/' . $latest_tag . '/bmc-ondemand-woo.zip';
                    return $this->build_plugin_info_array($version, $download_url, 'Actualización ' . $latest_tag);
                }
            }
        }

        return null;
    }

    /**
     * Helper para armar la estructura que WordPress requiere para actualizar
     */
    private function build_plugin_info_array($version, $download_url, $body_notes = '') {
        return array(
            'slug'          => 'bmc-ondemand-woo',
            'name'          => 'BMC OnDemand for WooCommerce',
            'version'       => $version,
            'author'        => 'BMCargo',
            'author_profile'=> 'https://bmcargo.com',
            'homepage'      => 'https://github.com/' . self::GITHUB_REPO,
            'download_url'  => $download_url,
            'requires'      => '5.8',
            'tested'        => '6.7',
            'requires_php'  => '7.4',
            'requires_plugins' => array('woocommerce'),
            'last_updated'  => date('Y-m-d'),
            'sections'      => array(
                'description' => 'Integración oficial de entrega y delivery con BMC OnDemand / BM Drive para WooCommerce.',
                'changelog'   => nl2br(esc_html($body_notes)),
            ),
            'banners'       => array(
                'low'  => 'https://bmc-ondemand-assets.s3.amazonaws.com/plugins/woocommerce/assets/banner-772x250.png',
                'high' => 'https://bmc-ondemand-assets.s3.amazonaws.com/plugins/woocommerce/assets/banner-1544x500.png',
            ),
        );
    }

    /**
     * Consulta el endpoint de actualizaciones de GitHub (con fallback al API propio si es necesario)
     */
    public function get_remote_version_info($force = false) {
        if (!$force) {
            $cached = get_transient(self::CACHE_KEY);
            if (!empty($cached) && is_array($cached)) {
                return $cached;
            }
        }

        // 1. Prioridad: Consultar GitHub Releases directamente
        $github_release = $this->get_github_release_info();
        if (!empty($github_release) && !empty($github_release['version'])) {
            set_transient(self::CACHE_KEY, $github_release, self::CACHE_TTL);
            return $github_release;
        }

        // 2. Fallback: Consultar API de microservicio
        $url = add_query_arg(array(
            'version' => $this->version,
            'site'    => home_url(),
        ), self::UPDATE_API_URL);

        $response = wp_remote_get($url, array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json',
            ),
        ));

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($data['data']) && is_array($data['data'])) {
                $release = $data['data'];
                set_transient(self::CACHE_KEY, $release, self::CACHE_TTL);
                return $release;
            }
        }

        return null;
    }

    /**
     * Comprueba si hay una nueva versión disponible y la inyecta en el transient de WordPress
     */
    public function check_for_plugin_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $remote_info = $this->get_remote_version_info();
        if (empty($remote_info) || empty($remote_info['version'])) {
            return $transient;
        }

        // Si la versión remota es mayor a la instalada
        if (version_compare($this->version, $remote_info['version'], '<')) {
            $update_item = (object) array(
                'id'            => $this->plugin_slug,
                'slug'          => 'bmc-ondemand-woo',
                'plugin'        => $this->plugin_slug,
                'new_version'   => $remote_info['version'],
                'url'           => $remote_info['homepage'] ?? 'https://bmcargo.com',
                'package'       => $remote_info['download_url'] ?? '',
                'icons'         => $remote_info['icons'] ?? array(),
                'banners'       => $remote_info['banners'] ?? array(),
                'tested'        => $remote_info['tested'] ?? '',
                'requires_php'  => $remote_info['requires_php'] ?? '',
                'compatibility' => new stdClass(),
            );

            $transient->response[$this->plugin_slug] = $update_item;
        } else {
            $item = (object) array(
                'id'          => $this->plugin_slug,
                'slug'        => 'bmc-ondemand-woo',
                'plugin'      => $this->plugin_slug,
                'new_version' => $this->version,
                'url'         => $remote_info['homepage'] ?? 'https://bmcargo.com',
                'package'     => '',
            );
            $transient->no_update[$this->plugin_slug] = $item;
        }

        return $transient;
    }

    /**
     * Provee información del plugin para la ventana modal nativa de WordPress (Ver Detalles)
     */
    public function plugin_popup_information($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }

        if (empty($args->slug) || $args->slug !== 'bmc-ondemand-woo') {
            return $result;
        }

        $remote_info = $this->get_remote_version_info(true);
        if (empty($remote_info)) {
            return $result;
        }

        $info = new stdClass();
        $info->name           = $remote_info['name'] ?? 'BMC OnDemand for WooCommerce';
        $info->slug           = 'bmc-ondemand-woo';
        $info->version        = $remote_info['version'] ?? $this->version;
        $info->author         = $remote_info['author'] ?? 'BMCargo';
        $info->author_profile = $remote_info['author_profile'] ?? 'https://sellerhub.kliquea.com';
        $info->homepage       = $remote_info['homepage'] ?? 'https://bmcargo.com';
        $info->requires       = $remote_info['requires'] ?? '5.8';
        $info->tested         = $remote_info['tested'] ?? '6.7';
        $info->requires_php   = $remote_info['requires_php'] ?? '7.4';
        $info->download_link  = $remote_info['download_url'] ?? '';
        $info->last_updated   = $remote_info['last_updated'] ?? date('Y-m-d');
        $info->sections       = $remote_info['sections'] ?? array();
        $info->banners        = $remote_info['banners'] ?? array();

        return $info;
    }

    /**
     * Asegura que el directorio resultante de la descompresión sea 'bmc-ondemand-woo'
     */
    public function ensure_correct_folder_name($source, $remote_source, $upgrader, $hook_extra = null) {
        if (!is_string($source) || !is_dir($source)) {
            return $source;
        }

        $base = basename($source);
        if ($base === 'bmc-ondemand-woo') {
            return $source;
        }

        // Verificar si es la actualización de este plugin
        $is_our_plugin = false;
        if (!empty($hook_extra['plugin']) && $hook_extra['plugin'] === $this->plugin_slug) {
            $is_our_plugin = true;
        } elseif (isset($upgrader->skin->plugin) && strpos($upgrader->skin->plugin, 'bmc-ondemand.php') !== false) {
            $is_our_plugin = true;
        } elseif (file_exists(trailingslashit($source) . 'bmc-ondemand.php')) {
            $is_our_plugin = true;
        }

        if (!$is_our_plugin) {
            return $source;
        }

        $dest = trailingslashit(dirname($source)) . 'bmc-ondemand-woo';
        if (is_dir($dest)) {
            $this->rrmdir($dest);
        }

        if (@rename($source, $dest)) {
            return trailingslashit($dest);
        }

        return $source;
    }

    /**
     * Elimina recursivamente un directorio de forma segura
     */
    private function rrmdir($dir) {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        if (!is_array($items)) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                $this->rrmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    /**
     * Limpia la caché al terminar el proceso de actualización
     */
    public function clear_cache($upgrader_object, $options) {
        if (!empty($options['action']) && $options['action'] === 'update' && !empty($options['type']) && $options['type'] === 'plugin') {
            delete_transient(self::CACHE_KEY);
        }
    }
}
