<?php
/**
 * Inicializador principal de BMC OnDemand para WooCommerce
 *
 * @package BMC_OnDemand
 * @version 1.3.17
 * @author  BMCargo
 * @license GPLv2 or later
 */

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Obtener la versión del plugin desde la cabecera
 */
function bmc_ondemand_get_version($file)
{
    if (!file_exists($file)) {
        return '1.0.1';
    }
    $fp = fopen($file, 'r');
    $version = '1.0.1';
    while (!feof($fp)) {
        $line = fgets($fp);
        if (preg_match('/^\s*\*\s*Version:\s*(.+)$/i', $line, $matches)) {
            $version = trim($matches[1]);
            break;
        }
        if (strpos($line, '*/') === 0) {
            break;
        }
    }
    fclose($fp);
    return $version;
}

// Definición de constantes del plugin
if (!defined('BMC_ONDEMAND_VERSION')) {
    define('BMC_ONDEMAND_VERSION', bmc_ondemand_get_version(dirname(__FILE__) . '/bmc-ondemand.php'));
}
if (!defined('BMC_ONDEMAND_PLUGIN_FILE')) {
    define('BMC_ONDEMAND_PLUGIN_FILE', dirname(__FILE__) . '/bmc-ondemand.php');
}
if (!defined('BMC_ONDEMAND_PLUGIN_DIR')) {
    define('BMC_ONDEMAND_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('BMC_ONDEMAND_PLUGIN_URL')) {
    define('BMC_ONDEMAND_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('BMC_ONDEMAND_PLUGIN_BASENAME')) {
    define('BMC_ONDEMAND_PLUGIN_BASENAME', plugin_basename(dirname(__FILE__) . '/bmc-ondemand.php'));
}

/**
 * Comprobar si WooCommerce está instalado y activo
 */
function bmc_ondemand_check_dependencies()
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>BMC OnDemand:</strong> Requiere que <strong>WooCommerce</strong> esté instalado y activado para funcionar.</p></div>';
        });
        return false;
    }
    return true;
}

/**
 * Inicialización de todos los módulos del plugin
 */
function bmc_ondemand_bootstrap()
{
    if (!bmc_ondemand_check_dependencies()) {
        return;
    }

    // Cargar clases del núcleo
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-logger.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-api-client.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-locations.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-carrier-calculator.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-shipping-method.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-order-dispatcher.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-order-manager.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-dashboard-service.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-label-printer.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/class-bmc-admin.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/admin/class-bmc-order-meta-box.php';
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-updater.php'; // Auto-Update nativo
    require_once BMC_ONDEMAND_PLUGIN_DIR . 'includes/class-bmc-core.php';

    // Iniciar instancia singleton principal y servicios
    BMC_Core::get_instance();
    BMC_Label_Printer::init();
    new BMC_Updater(BMC_ONDEMAND_PLUGIN_FILE, BMC_ONDEMAND_VERSION);
}

add_action('plugins_loaded', 'bmc_ondemand_bootstrap');
