<?php
/**
 * Logger persistente y visor para BMC OnDemand
 * Guarda logs en tabla personalizada o wp_options para consulta directa desde la UI
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Logger {
    const OPTION_DEBUG = 'bmc_ondemand_debug_enabled';
    const TABLE_NAME = 'bmc_ondemand_logs';
    const MAX_LOGS = 500;

    /**
     * Crear tabla de logs al inicializar si no existe
     */
    public static function maybe_create_table() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                level varchar(20) NOT NULL DEFAULT 'info',
                message text NOT NULL,
                context longtext NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY level (level),
                KEY created_at (created_at)
            ) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public static function log($message, $level = 'info', $context = array()) {
        $debug_enabled = get_option(self::OPTION_DEBUG, 'no') === 'yes';
        if (!$debug_enabled && $level === 'debug') {
            return;
        }

        // 1. Log estándar en WooCommerce
        if (function_exists('wc_get_logger')) {
            $logger = wc_get_logger();
            $log_entry = is_array($message) || is_object($message) ? wp_json_encode($message) : $message;
            if (!empty($context)) {
                $log_entry .= ' | Context: ' . wp_json_encode($context);
            }
            $logger->log($level, $log_entry, array('source' => 'bmc-ondemand'));
        }

        // 2. Log en base de datos local para el visor de la página
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        self::maybe_create_table();

        $msg_str = is_array($message) || is_object($message) ? wp_json_encode($message) : (string) $message;
        $ctx_str = !empty($context) ? wp_json_encode($context) : null;

        $wpdb->insert(
            $table,
            array(
                'level'      => sanitize_text_field($level),
                'message'    => $msg_str,
                'context'    => $ctx_str,
                'created_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%s')
        );

        // Poda periódica para mantener como máximo MAX_LOGS
        if (wp_rand(1, 30) === 1) {
            $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
            if ($count > self::MAX_LOGS) {
                $limit = $count - self::MAX_LOGS;
                $wpdb->query("DELETE FROM $table ORDER BY id ASC LIMIT $limit");
            }
        }
    }

    public static function info($message, $context = array()) {
        self::log($message, 'info', $context);
    }

    public static function error($message, $context = array()) {
        self::log($message, 'error', $context);
    }

    public static function debug($message, $context = array()) {
        self::log($message, 'debug', $context);
    }

    public static function warning($message, $context = array()) {
        self::log($message, 'warning', $context);
    }

    /**
     * Obtener logs paginados con filtros
     */
    public static function get_logs($limit = 30, $offset = 0, $level = '') {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        self::maybe_create_table();

        $where = "WHERE 1=1";
        $params = array();

        if (!empty($level)) {
            $where .= " AND level = %s";
            $params[] = $level;
        }

        $query = "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;

        return $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
    }

    /**
     * Contar total de logs
     */
    public static function count_logs($level = '') {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        self::maybe_create_table();

        if (!empty($level)) {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE level = %s", $level));
        }

        return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }

    /**
     * Limpiar todos los logs
     */
    public static function clear_logs() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        return $wpdb->query("TRUNCATE TABLE $table");
    }
}
