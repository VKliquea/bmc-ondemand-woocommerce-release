<?php
/**
 * Gestor de Despacho Multi-sucursal e Ítem por Ítem (Split Order Dispatch)
 * Portado desde ActionExtension.jsx y orderSubmission.server.js
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Order_Dispatcher {

    const NO_ENVIAR_VALUE = '__NO_ENVIAR__';

    /**
     * Determina si el método de pago del pedido es estrictamente Pago contra entrega / COD
     *
     * @param WC_Order $order
     * @return bool
     */
    public static function is_manual_or_cod_payment($order) {
        if (!$order) {
            return false;
        }

        $payment_method = strtolower((string) $order->get_payment_method());
        $payment_title  = strtolower((string) $order->get_payment_method_title());

        $combined = trim($payment_method . ' ' . $payment_title);

        // Identificador oficial de Cash on Delivery en WooCommerce
        if ($payment_method === 'cod' || $payment_method === 'cash_on_delivery') {
            return true;
        }

        // Búsqueda exclusiva de variantes de Contra Entrega / COD
        $keywords = array(
            'contra entrega',
            'contraentrega',
            'contra reembolso',
            'contra-entrega',
            'cash on delivery',
            'pago contra entrega',
        );

        foreach ($keywords as $kw) {
            if (strpos($combined, $kw) !== false) {
                return true;
            }
        }

        if (preg_match('/\bcod\b/', $combined)) {
            return true;
        }

        return false;
    }

    /**
     * Obtiene la nota de entrega por defecto según el método de pago del pedido
     *
     * Si es manual / COD -> [Nombre del Método] - [Monto Total formateado]
     * Si es electrónico (tarjeta, paypal, stripe, etc.) -> vacío '' (o nota del cliente si existe)
     *
     * @param WC_Order $order
     * @return string
     */
    public static function get_default_delivery_note($order) {
        if (!$order) {
            return '';
        }

        if (self::is_manual_or_cod_payment($order)) {
            $method_title = trim((string) $order->get_payment_method_title());
            if (empty($method_title)) {
                $method_title = 'Pago contra entrega';
            }

            $currency = $order->get_currency() ?: 'DOP';
            $total_formatted = wc_price($order->get_total(), array('currency' => $currency));
            // Quitar tags html para texto plano limpio
            $total_clean = html_entity_decode(wp_strip_all_tags($total_formatted), ENT_QUOTES, 'UTF-8');

            return trim($method_title . ' - ' . $total_clean);
        }

        // Para pagos electrónicos (tarjetas, etc.), la nota se mantiene vacía por defecto
        return '';
    }

    /**
     * Despacha los ítems de un pedido agrupados por la sucursal asignada a cada uno
     * 
     * @param WC_Order $order
     * @param array $items_branch_map Array [ item_id => location_id ]
     * @param array $custom_weights Array [ item_id => custom_weight_in_lb ]
     * @param string $delivery_notes Notas de entrega opcionales
     * @return array Resumen de resultados por sucursal
     */
    public static function dispatch_items($order, $items_branch_map = array(), $custom_weights = array(), $delivery_notes = '') {
        $order_id = $order->get_id();
        $default_location = BMC_Locations::get_default_location_id();
        $sent_items = (array) $order->get_meta('_bmc_sent_items', true) ?: array();

        // Agrupar ítems por sucursal
        $groups_by_location = array();
        $weight_unit = get_option('woocommerce_weight_unit', 'kg');

        foreach ($order->get_items() as $item_id => $item) {
            $str_item_id = (string) $item_id;

            // Si ya fue enviado previamente, omitir
            if (in_array($str_item_id, $sent_items, true)) {
                continue;
            }

            // Si el ítem NO fue seleccionado por el usuario en el frontend, omitir
            if (!isset($items_branch_map[$str_item_id])) {
                continue;
            }

            // Sucursal elegida para este ítem
            $assigned_loc = $items_branch_map[$str_item_id] ?? '';

            // Si se marcó explícitamente como NO ENVIAR, saltar
            if ($assigned_loc === self::NO_ENVIAR_VALUE || empty($assigned_loc)) {
                continue;
            }

            $product = $item->get_product();

            // Determinar peso en libras
            $weight_lb = 0.0;
            if (isset($custom_weights[$str_item_id]) && $custom_weights[$str_item_id] !== '') {
                $weight_lb = floatval($custom_weights[$str_item_id]);
            } else {
                $raw_weight = $product ? floatval($product->get_weight()) : 0.0;
                if ($raw_weight > 0) {
                    if ($weight_unit === 'kg') {
                        $weight_lb = $raw_weight * 2.20462;
                    } elseif ($weight_unit === 'g') {
                        $weight_lb = ($raw_weight / 1000) * 2.20462;
                    } else {
                        $weight_lb = $raw_weight;
                    }
                }
            }

            // Validación estricta: NO permitir despachar si no tiene peso asignado (> 0)
            if ($weight_lb <= 0) {
                return array(
                    'success' => false,
                    'message' => sprintf(
                        __('El producto "%s" no tiene un peso asignado válido. Por favor, introduce el peso en libras antes de enviar.', 'bmc-ondemand'),
                        $item->get_name()
                    ),
                );
            }

            if (!isset($groups_by_location[$assigned_loc])) {
                $groups_by_location[$assigned_loc] = array();
            }

            $groups_by_location[$assigned_loc][] = array(
                'externalOrderItemId' => $str_item_id,
                'productName'         => $item->get_name(),
                'quantity'            => $item->get_quantity(),
                'weight'              => round($weight_lb, 2),
                'weightUnit'          => 'LB',
                'price'               => floatval($order->get_item_total($item, false)),
            );
        }

        if (empty($groups_by_location)) {
            return array(
                'success' => false,
                'message' => 'No hay ítems seleccionados para enviar o todos ya fueron despachados.',
            );
        }

        // Obtener datos del cliente y coordenadas
        $lat = floatval($order->get_meta('_shipping_latitude') ?: $order->get_meta('_billing_latitude'));
        $lng = floatval($order->get_meta('_shipping_longitude') ?: $order->get_meta('_billing_longitude'));

        // Si no tiene coordenadas GPS, asignar coordenadas por defecto (Distrito Nacional / Santo Domingo: 18.4861, -69.9312)
        if (!$lat || !$lng) {
            $lat = 18.4861;
            $lng = -69.9312;
            $order->update_meta_data('_shipping_latitude', $lat);
            $order->update_meta_data('_shipping_longitude', $lng);
            $order->save();
        }

        $address_line = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
        if (empty($address_line)) {
            $address_line = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
        }

        $customer_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if (empty($customer_name)) {
            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) ?: 'Cliente WooCommerce';
        }

        $customer_email = $order->get_billing_email() ?: '';
        $phone = $order->get_billing_phone() ?: '+0000000000';
        $city = $order->get_shipping_city() ?: $order->get_billing_city() ?: 'Santo Domingo';
        $country = $order->get_shipping_country() ?: $order->get_billing_country() ?: 'DO';

        // Si no se proporcionaron notas explícitas desde el panel, usar la nota por defecto según el método de pago
        if (empty($delivery_notes)) {
            $delivery_notes = self::get_default_delivery_note($order);
            if (empty($delivery_notes)) {
                $delivery_notes = trim((string) $order->get_customer_note());
            }
        }

        $api = BMC_API_Client::get_instance();
        $dispatched_results = array();
        $newly_sent_items = array();
        $existing_shipments = (array) $order->get_meta('_bmc_shipments', true) ?: array();
        $locations_list = BMC_Locations::get_all();
        $locations_by_id = array();
        foreach ($locations_list as $loc_item) {
            $locations_by_id[$loc_item['locationId']] = $loc_item['name'] ?? $loc_item['locationId'];
        }

        foreach ($groups_by_location as $loc_id => $items_payload) {
            $payload = array(
                'locationId' => $loc_id,
                'order'      => array(
                    'externalOrderId' => (string) $order_id . '-' . substr(md5($loc_id . time()), 0, 4),
                    'notes'           => (string) $delivery_notes,
                    'items'           => $items_payload,
                ),
                'customer'   => array(
                    'externalCustomerId' => (string) $order->get_customer_id() ?: (string) $order_id,
                    'fullName'           => $customer_name,
                    'phone'              => $phone,
                    'email'              => $customer_email,
                    'address'            => array(
                        'addressLine' => $address_line,
                        'city'        => $city,
                        'country'     => $country,
                        'phone'       => $phone,
                        'latitude'    => $lat,
                        'longitude'   => $lng,
                    ),
                ),
            );

            $response = $api->submit_order($payload, $country);

            if (is_wp_error($response)) {
                $dispatched_results[$loc_id] = array('success' => false, 'error' => $response->get_error_message());
                continue;
            }

            $status = $response['status'] ?? 0;
            $data = $response['data'] ?? array();

            if (in_array($status, array(200, 201, 202))) {
                $msg_id = $data['messageId'] ?? '';
                $tracking = (string) ($data['tracking'] ?? $data['payload']['tracking'] ?? $data['order']['tracking'] ?? '');
                $order_id_remote = (string) ($data['orderId'] ?? $data['payload']['orderId'] ?? '');

                $dispatched_results[$loc_id] = array(
                    'success'   => true,
                    'messageId' => $msg_id,
                    'tracking'  => $tracking,
                    'orderId'   => $order_id_remote,
                );

                if (!empty($tracking)) {
                    $order->update_meta_data('_bmc_tracking', $tracking);
                }
                if (!empty($order_id_remote)) {
                    $order->update_meta_data('_bmc_order_id', $order_id_remote);
                }

                // Guardar registro estructurado del envío/sucursal
                $existing_shipments[] = array(
                    'locationId'   => $loc_id,
                    'locationName' => $locations_by_id[$loc_id] ?? ('Sucursal ' . $loc_id),
                    'tracking'     => $tracking,
                    'orderId'      => $order_id_remote,
                    'itemCount'    => count($items_payload),
                    'timestamp'    => time(),
                );

                // Marcar ítems de este grupo como enviados
                foreach ($items_payload as $sent_pkg) {
                    $newly_sent_items[] = $sent_pkg['externalOrderItemId'];
                }
            } else {
                $err_details = $data['message'] ?? $data['error'] ?? (isset($data['details']) ? $data['details'] : "HTTP {$status}");
                $dispatched_results[$loc_id] = array('success' => false, 'error' => $err_details);
                BMC_Logger::error("Fallo al enviar orden a BMC OnDemand: {$err_details}", array(
                    'status'   => $status,
                    'response' => $data,
                    'payload'  => $payload,
                ));
            }
        }

        // Actualizar ítems enviados en metadatos del pedido
        if (!empty($newly_sent_items)) {
            $updated_sent = array_unique(array_merge($sent_items, $newly_sent_items));
            $order->update_meta_data('_bmc_sent_items', $updated_sent);
            $order->update_meta_data('_bmc_shipments', $existing_shipments);
            $order->update_meta_data('_bmc_status', 'pending');
            $order->add_order_note('<strong>BMC OnDemand:</strong> Se despacharon ' . count($newly_sent_items) . ' ítems satisfactoriamente.');
            $order->save();
        }

        return array(
            'success'   => !empty($newly_sent_items),
            'results'   => $dispatched_results,
            'tracking'  => (string) $order->get_meta('_bmc_tracking'),
            'print_url' => admin_url('admin-ajax.php?action=bmc_print_label&order_id=' . $order_id . '&tracking=' . rawurlencode((string) $order->get_meta('_bmc_tracking'))),
        );
    }
}
