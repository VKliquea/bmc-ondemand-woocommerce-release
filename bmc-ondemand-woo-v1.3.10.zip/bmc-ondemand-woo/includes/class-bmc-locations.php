<?php
/**
 * Gestión de Ubicaciones / Sucursales para BMC OnDemand
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Locations {
    const OPTION_DEFAULT_LOCATION = 'bmc_ondemand_default_location';
    const OPTION_LOCATIONS_CACHE = 'bmc_ondemand_locations_cache';

    public static function get_all($refresh = false) {
        $cached = get_option(self::OPTION_LOCATIONS_CACHE);
        if (!$refresh && !empty($cached) && is_array($cached)) {
            return $cached;
        }

        $api = BMC_API_Client::get_instance();
        $response = $api->get_locations();

        if (is_wp_error($response)) {
            return array();
        }

        if (isset($response['status']) && $response['status'] === 200 && !empty($response['data']['locations'])) {
            $locations = $response['data']['locations'];
            update_option(self::OPTION_LOCATIONS_CACHE, $locations);
            return $locations;
        }

        return array();
    }

    public static function get_default_location_id() {
        return get_option(self::OPTION_DEFAULT_LOCATION, '');
    }

    public static function get_location_by_id($location_id) {
        $locations = self::get_all();
        foreach ($locations as $loc) {
            if (isset($loc['locationId']) && $loc['locationId'] === $location_id) {
                return $loc;
            }
        }
        return null;
    }

    public static function create_location($name, $address_data) {
        $api = BMC_API_Client::get_instance();
        $payload = array(
            'name'    => sanitize_text_field($name),
            'address' => array(
                'addressLine' => sanitize_text_field($address_data['addressLine'] ?? ''),
                'city'        => sanitize_text_field($address_data['city'] ?? ''),
                'state'       => sanitize_text_field($address_data['state'] ?? ''),
                'postalCode'  => sanitize_text_field($address_data['postalCode'] ?? ''),
                'country'     => sanitize_text_field($address_data['country'] ?? 'DO'),
                'latitude'    => floatval($address_data['latitude'] ?? 0),
                'longitude'   => floatval($address_data['longitude'] ?? 0),
            ),
        );

        $res = $api->create_location($payload);
        if (!is_wp_error($res) && isset($res['status']) && in_array($res['status'], array(200, 201))) {
            self::get_all(true);
        }
        return $res;
    }

    public static function update_location($location_id, $name, $address_data) {
        $api = BMC_API_Client::get_instance();
        $payload = array(
            'name'    => sanitize_text_field($name),
            'address' => array(
                'addressLine' => sanitize_text_field($address_data['addressLine'] ?? ''),
                'city'        => sanitize_text_field($address_data['city'] ?? ''),
                'state'       => sanitize_text_field($address_data['state'] ?? ''),
                'postalCode'  => sanitize_text_field($address_data['postalCode'] ?? ''),
                'country'     => sanitize_text_field($address_data['country'] ?? 'DO'),
                'latitude'    => floatval($address_data['latitude'] ?? 0),
                'longitude'   => floatval($address_data['longitude'] ?? 0),
            ),
        );

        $res = $api->update_location($location_id, $payload);
        if (!is_wp_error($res) && isset($res['status']) && $res['status'] === 200) {
            self::get_all(true);
        }
        return $res;
    }

    public static function delete_location($location_id) {
        $api = BMC_API_Client::get_instance();
        $res = $api->delete_location($location_id);
        if (!is_wp_error($res) && isset($res['status']) && $res['status'] === 200) {
            self::get_all(true);
        }
        return $res;
    }
}
