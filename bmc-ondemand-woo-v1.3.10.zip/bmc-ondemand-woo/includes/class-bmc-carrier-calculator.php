<?php
/**
 * Motor de Cálculo y Reglas de Tarifas de Envío para BMC OnDemand
 * Portado desde carrierCalculator.js de la app de Shopify
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Carrier_Calculator {

    // Mapeo normalizado de provincias de República Dominicana
    const DO_PROVINCE_ALIASES = array(
        '01'                => 'Distrito Nacional',
        'DO-01'             => 'Distrito Nacional',
        'DN'                => 'Distrito Nacional',
        'DISTRITO NACIONAL' => 'Distrito Nacional',
        '02'                => 'Azua',
        'DO-02'             => 'Azua',
        '04'                => 'Barahona',
        'DO-04'             => 'Barahona',
        '06'                => 'Duarte',
        'DO-06'             => 'Duarte',
        '09'                => 'Espaillat',
        'DO-09'             => 'Espaillat',
        '11'                => 'La Altagracia',
        'DO-11'             => 'La Altagracia',
        '12'                => 'La Romana',
        'DO-12'             => 'La Romana',
        '13'                => 'La Vega',
        'DO-13'             => 'La Vega',
        '19'                => 'Hermanas Mirabal',
        'DO-19'             => 'Hermanas Mirabal',
        '17'                => 'Peravia',
        'DO-17'             => 'Peravia',
        '18'                => 'Puerto Plata',
        'DO-18'             => 'Puerto Plata',
        '21'                => 'San Cristóbal',
        'DO-21'             => 'San Cristóbal',
        '22'                => 'San Juan',
        'DO-22'             => 'San Juan',
        '23'                => 'San Pedro de Macorís',
        'DO-23'             => 'San Pedro de Macorís',
        '24'                => 'Sánchez Ramírez',
        'DO-24'             => 'Sánchez Ramírez',
        '25'                => 'Santiago',
        'DO-25'             => 'Santiago',
        '28'                => 'Monseñor Nouel',
        'DO-28'             => 'Monseñor Nouel',
        '32'                => 'Santo Domingo',
        'DO-32'             => 'Santo Domingo',
        'SD'                => 'Santo Domingo',
        'SANTO DOMINGO'     => 'Santo Domingo',
    );

    /**
     * Normaliza un string eliminando acentos y mayúsculas
     */
    public static function normalize_str($val) {
        $str = (string) ($val ?? '');
        if (function_exists('transliterator_transliterate')) {
            $str = transliterator_transliterate('Any-Latin; Latin-ASCII;', $str);
        } elseif (function_exists('iconv')) {
            $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $str);
            if ($converted !== false) {
                $str = $converted;
            }
        }
        $str = preg_replace('/[^a-zA-Z0-9\s_-]/', '', $str);
        return strtoupper(trim((string)$str));
    }

    /**
     * Comprueba si el destino coincide con una zona política configurada
     */
    public static function check_political_zone($zone, $destination) {
        $countries = is_array($zone['countries'] ?? null) ? $zone['countries'] : array();
        $provinces = is_array($zone['provinces'] ?? null) ? $zone['provinces'] : array('*');

        if (empty($countries)) {
            return false;
        }

        $dest_country = self::normalize_str($destination['country'] ?? '');
        if (empty($dest_country)) {
            return false;
        }

        $is_country_match = in_array('*', $countries, true) || in_array($dest_country, array_map(array(__CLASS__, 'normalize_str'), $countries), true);

        if (!$is_country_match) {
            return false;
        }

        if (in_array('*', $provinces, true) || empty($provinces)) {
            return true;
        }

        $raw_province = $destination['state'] ?? $destination['province'] ?? '';
        $dest_province = self::normalize_str($raw_province);
        $dest_city = self::normalize_str($destination['city'] ?? '');
        $alias_province = self::normalize_str(self::DO_PROVINCE_ALIASES[$dest_province] ?? '');

        foreach ($provinces as $p) {
            $target = self::normalize_str($p);
            if (empty($target)) continue;

            if (
                $target === $dest_province ||
                (!empty($alias_province) && $target === $alias_province) ||
                (!empty($dest_province) && substr($dest_province, -strlen("-$target")) === "-$target") ||
                (empty($dest_province) && !empty($dest_city) && strpos($dest_city, $target) !== false)
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Evalúa si una regla aplica al pedido según peso y total
     */
    public static function rule_matches($rule, $order_value, $total_weight_lb) {
        $cond = $rule['conditions'] ?? array();
        if (isset($cond['minOrderValue']) && $order_value < floatval($cond['minOrderValue'])) return false;
        if (isset($cond['maxOrderValue']) && $order_value > floatval($cond['maxOrderValue'])) return false;
        if (isset($cond['minWeightLb']) && $total_weight_lb < floatval($cond['minWeightLb'])) return false;
        if (isset($cond['maxWeightLb']) && $total_weight_lb > floatval($cond['maxWeightLb'])) return false;
        return true;
    }

    /**
     * Calcula el precio final de una regla (fixed, percentage, per_pound, weight_based)
     */
    public static function calculate_rule_price($rule, $total_weight_lb, $order_value) {
        $price_type = $rule['priceType'] ?? 'fixed';

        if ($price_type === 'percentage') {
            $percentage = floatval($rule['price'] ?? 0);
            return round($order_value * ($percentage / 100), 2);
        }

        if ($price_type === 'per_pound') {
            $unit_price = floatval($rule['price'] ?? 0);
            return round($total_weight_lb * $unit_price, 2);
        }

        if ($price_type === 'weight_based') {
            $base_price = floatval($rule['basePrice'] ?? 0);
            $base_weight = floatval($rule['baseWeightLb'] ?? 0);
            $price_extra_lb = floatval($rule['pricePerExtraLb'] ?? 0);

            $extra_weight = max(0, $total_weight_lb - $base_weight);
            if ($extra_weight > 0) {
                $base_price += ceil($extra_weight) * $price_extra_lb;
            }
            return round($base_price, 2);
        }

        // Tipo fijo por defecto
        return round(floatval($rule['price'] ?? 0), 2);
    }

    /**
     * Calcula tarifas basadas en las reglas locales guardadas
     */
    public static function calculate_local_rates($destination, $package_items, $order_value) {
        $api = BMC_API_Client::get_instance();
        // Consultar en tiempo real a la API (force_refresh = true) para reflejar cambios inmediatos del admin
        $rules_config = $api->get_carrier_config(true);

        if (empty($rules_config) || empty($rules_config['active'])) {
            BMC_Logger::info("[BMC_Carrier_Calculator] Reglas no activas o configuración vacía", array('rules_config' => $rules_config));
            return array();
        }

        $total_weight_lb = 0;
        $total_volumetric_lb = 0;
        $weight_unit = get_option('woocommerce_weight_unit', 'kg');

        foreach ($package_items as $item) {
            $product = $item['data'] ?? null;
            if (!$product || !$product->needs_shipping()) continue;

            $qty = $item['quantity'] ?? 1;
            $raw_weight = floatval($product->get_weight());

            if ($weight_unit === 'kg') {
                $item_lb = round($raw_weight * 2.20462, 2);
            } elseif ($weight_unit === 'g') {
                $item_lb = round(($raw_weight / 1000) * 2.20462, 2);
            } else {
                $item_lb = $raw_weight > 0 ? round($raw_weight, 2) : 1.0;
            }

            if ($item_lb <= 0) $item_lb = 1.0;
            $total_weight_lb += $item_lb * $qty;

            // Dimensiones volumétricas
            $l = floatval($product->get_length());
            $w = floatval($product->get_width());
            $h = floatval($product->get_height());

            if ($l > 0 && $w > 0 && $h > 0) {
                $dim_unit = get_option('woocommerce_dimension_unit', 'cm');
                if ($dim_unit === 'in') {
                    $l *= 2.54; $w *= 2.54; $h *= 2.54;
                }
                $vol_lb = round((($l * $w * $h) / 5000) * 2.20462, 2);
                $total_volumetric_lb += $vol_lb * $qty;
            }
        }

        // Peso final a considerar: el mayor entre peso físico y peso volumétrico (redondeado a 2 decimales)
        $effective_weight_lb = round(max($total_weight_lb, $total_volumetric_lb), 2);
        if ($effective_weight_lb <= 0) {
            $effective_weight_lb = 1.0;
        }

        // 1. Identificar zonas que coinciden exactamente con el país/provincia del destino
        $matched_zone_ids = array();
        $zones = $rules_config['zones'] ?? array();

        foreach ($zones as $zone) {
            if (self::check_political_zone($zone, $destination)) {
                if (!empty($zone['id'])) {
                    $matched_zone_ids[] = $zone['id'];
                }
            }
        }

        // Si la zona específica no coincide con el país del cliente, NO agregar comodín global
        // para evitar mostrar servicios pertenecientes a otros países.
        if (!empty($matched_zone_ids)) {
            $matched_zone_ids[] = '*'; // Wildcard solo si la zona política del país es válida
        }

        BMC_Logger::info("[BMC_Carrier_Calculator] Zonas coincidentes:", array(
            'destination'         => $destination,
            'matched_zone_ids'    => $matched_zone_ids,
            'effective_weight_lb' => $effective_weight_lb,
            'order_value'         => $order_value,
        ));

        // Si el país seleccionado no tiene zonas que coincidan en la configuración, retornar vacío
        if (empty($matched_zone_ids)) {
            BMC_Logger::info("[BMC_Carrier_Calculator] Ninguna zona configurada coincide con el país del destino", array(
                'destination_country' => $destination['country'] ?? '',
            ));
            return array();
        }

        $rates = array();
        $services = $rules_config['services'] ?? array();

        // 2. Iterar sobre servicios activos evaluando sus reglas por zoneId
        foreach ($services as $service) {
            if (empty($service['active'])) continue;

            $service_rules = $service['rules'] ?? array();
            foreach ($service_rules as $rule) {
                $rule_zone = $rule['zoneId'] ?? '*';
                // La regla DEBE coincidir con una de las zonas del país destino seleccionado
                if (!in_array($rule_zone, $matched_zone_ids, true)) {
                    continue;
                }

                // Evaluar si se cumplen las condiciones de peso y monto de la orden
                if (!self::rule_matches($rule, $order_value, $effective_weight_lb)) {
                    BMC_Logger::info("[BMC_Carrier_Calculator] Regla descartada por no cumplir condiciones", array(
                        'rule'                => $rule,
                        'order_value'         => $order_value,
                        'effective_weight_lb' => $effective_weight_lb,
                    ));
                    continue;
                }

                $price = self::calculate_rule_price($rule, $effective_weight_lb, $order_value);

                $rates[] = array(
                    'serviceId'   => $service['serviceCode'] ?? ('bmc_service_' . sanitize_title($service['serviceName'] ?? 'shipping')),
                    'displayName' => $service['serviceName'] ?? __('BM Cargo Envíos', 'bmc-ondemand'),
                    'price'       => round($price, 2),
                    'description' => $rule['description'] ?? '',
                );

                break; // Una sola regla ganadora por servicio aplicable
            }
        }

        // 3. Tarifa Contingencia (Fallback) SOLO si la zona del país seleccionado coincidió pero ninguna regla específica aplicó
        if (empty($rates) && !empty($matched_zone_ids) && !empty($rules_config['fallbackRate']) && !empty($rules_config['fallbackRate']['price'])) {
            $fallback = $rules_config['fallbackRate'];
            $rates[] = array(
                'serviceId'   => 'bmc_fallback_rate',
                'displayName' => $fallback['serviceName'] ?? __('BM Cargo - Envío Estándar', 'bmc-ondemand'),
                'price'       => floatval($fallback['price']),
                'description' => $fallback['description'] ?? '',
            );
            BMC_Logger::info("[BMC_Carrier_Calculator] Aplicada tarifa Fallback para país con zona coincidente:", array('fallback' => $fallback));
        }

        BMC_Logger::info("[BMC_Carrier_Calculator] Tarifas finales calculadas:", array('rates' => $rates));
        return $rates;
    }
}
