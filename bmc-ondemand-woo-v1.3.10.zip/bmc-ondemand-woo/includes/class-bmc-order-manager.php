<?php
/**
 * Gestor de Despacho y Sincronización de Pedidos con BMC OnDemand
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Order_Manager {
    const META_BMC_ORDER_ID = '_bmc_order_id';
    const META_BMC_MESSAGE_ID = '_bmc_message_id';
    const META_BMC_STATUS = '_bmc_status';
    const META_BMC_TRACKING = '_bmc_tracking';
    const META_BMC_SYNC_ERROR = '_bmc_sync_error';

    public static function init() {
        // Disparar sincronización cuando el pedido pasa a procesando o completado
        add_action('woocommerce_order_status_processing', array(__CLASS__, 'maybe_auto_sync_order'), 20, 1);
        add_action('woocommerce_order_status_completed', array(__CLASS__, 'maybe_auto_sync_order'), 20, 1);

        // Metabox en la pantalla de edición de pedido de WooCommerce
        add_action('add_meta_boxes', array(__CLASS__, 'add_order_meta_box'));

        // Handler para reintento manual vía AJAX
        add_action('wp_ajax_bmc_sync_order_manual', array(__CLASS__, 'ajax_sync_order_manual'));
    }

    /**
     * Sincroniza automáticamente si está habilitado en las opciones
     */
    public static function maybe_auto_sync_order($order_id) {
        // Solo sincronizar si la tienda está aprobada y activa
        $api = BMC_API_Client::get_instance();
        if ($api->get_store_status() !== 'active') {
            return;
        }

        $auto_sync = get_option('bmc_ondemand_auto_sync_orders', 'no') === 'yes';
        if (!$auto_sync) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Si ya fue despachado previamente, no duplicar
        $existing_id = $order->get_meta(self::META_BMC_ORDER_ID);
        if (!empty($existing_id)) {
            return;
        }

        self::dispatch_order($order);
    }

    /**
     * Despacha el pedido a la API de BMCargo
     */
    public static function dispatch_order($order) {
        $order_id = $order->get_id();
        $location_id = BMC_Locations::get_default_location_id();

        if (empty($location_id)) {
            $order->update_meta_data(self::META_BMC_SYNC_ERROR, 'No hay sucursal de origen configurada.');
            $order->save();
            return false;
        }

        // Obtener ítems del pedido
        $items = array();
        $weight_unit = get_option('woocommerce_weight_unit', 'kg');

        foreach ($order->get_items() as $item_id => $item) {
            $product = $item->get_product();
            $raw_weight = $product ? floatval($product->get_weight()) : 1.0;

            if ($weight_unit === 'kg') {
                $weight_lb = $raw_weight * 2.20462;
            } else {
                $weight_lb = $raw_weight > 0 ? $raw_weight : 1.0;
            }

            $items[] = array(
                'externalOrderItemId' => (string) $item_id,
                'productName'         => $item->get_name(),
                'quantity'            => $item->get_quantity(),
                'weight'              => round($weight_lb, 2),
                'price'               => floatval($order->get_item_total($item, false)),
            );
        }

        // Coordenadas del cliente (de la metadata del pedido o fallback)
        $lat = floatval($order->get_meta('_shipping_latitude'));
        $lng = floatval($order->get_meta('_shipping_longitude'));

        if (!$lat || !$lng) {
            $lat = floatval($order->get_meta('_billing_latitude'));
            $lng = floatval($order->get_meta('_billing_longitude'));
        }

        // Si aún no hay coordenadas exactas, advertir y registrar error
        if (!$lat || !$lng) {
            $msg = 'No se encontraron coordenadas GPS de entrega (latitud/longitud) para este pedido.';
            $order->update_meta_data(self::META_BMC_SYNC_ERROR, $msg);
            $order->add_order_note('<strong>BMC OnDemand Error:</strong> ' . $msg);
            $order->save();
            BMC_Logger::error("Pedido #$order_id sin coordenadas para entrega BMC OnDemand.");
            return false;
        }

        $address_line = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
        if (empty($address_line)) {
            $address_line = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
        }

        $customer_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if (empty($customer_name)) {
            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        }

        $phone = $order->get_billing_phone();
        $city = $order->get_shipping_city() ?: $order->get_billing_city() ?: 'Santo Domingo';
        $country = $order->get_shipping_country() ?: $order->get_billing_country() ?: 'DO';

        $customer_note = trim((string) $order->get_customer_note());

        $payload = array(
            'locationId' => $location_id,
            'order'      => array(
                'externalOrderId' => (string) $order_id,
                'notes'           => $customer_note,
                'items'           => $items,
            ),
            'customer'   => array(
                'externalCustomerId' => (string) $order->get_customer_id(),
                'fullName'           => $customer_name,
                'phone'              => $phone,
                'address'            => array(
                    'addressLine' => $address_line,
                    'city'        => $city,
                    'country'     => $country,
                    'latitude'    => $lat,
                    'longitude'   => $lng,
                ),
            ),
        );

        $api = BMC_API_Client::get_instance();
        $response = $api->submit_order($payload);

        if (is_wp_error($response)) {
            $error_msg = $response->get_error_message();
            $order->update_meta_data(self::META_BMC_SYNC_ERROR, $error_msg);
            $order->add_order_note('<strong>BMC OnDemand Error:</strong> ' . $error_msg);
            $order->save();
            return false;
        }

        $status_code = $response['status'] ?? 0;
        $body = $response['data'] ?? array();

        if ($status_code === 202 || $status_code === 200 || $status_code === 201) {
            $message_id = $body['messageId'] ?? '';
            $order->update_meta_data(self::META_BMC_ORDER_ID, (string) $order_id);
            $order->update_meta_data(self::META_BMC_MESSAGE_ID, $message_id);
            $order->update_meta_data(self::META_BMC_STATUS, 'pending');
            $order->delete_meta_data(self::META_BMC_SYNC_ERROR);

            $order->add_order_note("<strong>BMC OnDemand:</strong> Pedido enviado a despacho exitosamente. MessageID: $message_id");
            $order->save();
            BMC_Logger::info("Pedido #$order_id enviado a BMC OnDemand exitosamente.");
            return true;
        } else {
            $error_detail = $body['message'] ?? 'Error desconocido al enviar pedido';
            $order->update_meta_data(self::META_BMC_SYNC_ERROR, $error_detail);
            $order->add_order_note('<strong>BMC OnDemand Falló:</strong> ' . $error_detail);
            $order->save();
            BMC_Logger::error("Fallo al enviar pedido #$order_id a BMC OnDemand", array('res' => $body));
            return false;
        }
    }

    /**
     * Añade Metabox al panel lateral de edición del pedido
     */
    public static function add_order_meta_box() {
        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') &&
                  \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
                  ? wc_get_page_screen_id('shop-order')
                  : 'shop_order';

        add_meta_box(
            'bmc_ondemand_order_box',
            __('BMC OnDemand Delivery', 'bmc-ondemand'),
            array(__CLASS__, 'render_order_meta_box'),
            $screen,
            'side',
            'high'
        );
    }

    public static function render_order_meta_box($post_or_order) {
        $order = ($post_or_order instanceof \WC_Order) ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order) return;

        $order_id   = $order->get_id();
        $bmc_status = $order->get_meta(self::META_BMC_STATUS);
        $tracking   = $order->get_meta(self::META_BMC_TRACKING);
        $error      = $order->get_meta(self::META_BMC_SYNC_ERROR);
        $msg_id     = $order->get_meta(self::META_BMC_MESSAGE_ID);
        ?>
        <div class="bmc-order-box" style="padding: 6px 0;">
            <p><strong>Estado BMC:</strong> 
                <?php if ($bmc_status): ?>
                    <span class="badge" style="background:#e0f2fe;color:#0369a1;padding:2px 8px;border-radius:4px;"><?php echo esc_html(strtoupper($bmc_status)); ?></span>
                <?php else: ?>
                    <span style="color:#666;">No enviado aún</span>
                <?php endif; ?>
            </p>

            <?php if (!empty($tracking)): ?>
                <p><strong>Tracking:</strong> <code><?php echo esc_html($tracking); ?></code></p>
            <?php endif; ?>

            <?php if (!empty($msg_id)): ?>
                <p><small>Msg ID: <?php echo esc_html($msg_id); ?></small></p>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div style="background:#fee2e2;color:#991b1b;padding:8px;border-radius:4px;margin-bottom:10px;font-size:12px;">
                    <strong>Error:</strong> <?php echo esc_html($error); ?>
                </div>
            <?php endif; ?>

            <button type="button" class="button button-primary bmc-sync-btn" data-order-id="<?php echo esc_attr($order_id); ?>" style="width:100%;margin-top:8px;">
                <?php echo $bmc_status ? __('Reenviar a BMC OnDemand', 'bmc-ondemand') : __('Despachar con BMC OnDemand', 'bmc-ondemand'); ?>
            </button>
        </div>
        <script>
        jQuery(document).ready(function($) {
            $('.bmc-sync-btn').on('click', function(e) {
                e.preventDefault();
                var btn = $(this);
                btn.prop('disabled', true).text('Enviando...');
                $.post(ajaxurl, {
                    action: 'bmc_sync_order_manual',
                    order_id: btn.data('order-id'),
                    _wpnonce: '<?php echo wp_create_nonce('bmc_manual_sync'); ?>'
                }, function(res) {
                    if (res.success) {
                        alert('Pedido enviado correctamente a BMC OnDemand.');
                        location.reload();
                    } else {
                        alert('Error: ' + (res.data || 'No se pudo sincronizar'));
                        btn.prop('disabled', false).text('Reintentar');
                    }
                });
            });
        });
        </script>
        <?php
    }

    public static function ajax_sync_order_manual() {
        check_ajax_referer('bmc_manual_sync');
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error('No autorizado');
        }

        $order_id = intval($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error('Pedido inválido');
        }

        $result = self::dispatch_order($order);
        if ($result) {
            wp_send_json_success();
        } else {
            $err = $order->get_meta(self::META_BMC_SYNC_ERROR) ?: 'Fallo al procesar el despacho';
            wp_send_json_error($err);
        }
    }
}

BMC_Order_Manager::init();
