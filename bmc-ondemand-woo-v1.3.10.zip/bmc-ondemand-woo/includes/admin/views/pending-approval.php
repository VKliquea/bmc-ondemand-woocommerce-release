<?php
/**
 * Vista de Tienda en Revisión (Aprobación Pendiente)
 * Se muestra cuando la tienda tiene status 'pending'
 */

if (!defined('ABSPATH')) {
    exit;
}

$logo_url = BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-logo-card.webp';
$api = BMC_API_Client::get_instance();
$status_message = '';

// Si el usuario hace clic en "Comprobar estado"
if (isset($_POST['bmc_check_status_nonce']) && wp_verify_nonce($_POST['bmc_check_status_nonce'], 'bmc_check_status_action')) {
    $latest_status = $api->get_store_status(true);
    if ($latest_status === 'active') {
        // Redirigir para cargar el dashboard o la página actual
        wp_safe_redirect(remove_query_arg('refreshed'));
        exit;
    } else {
        $status_message = __('Tu tienda continúa en revisión por el equipo de BM Cargo. Te notificaremos en cuanto sea aprobada.', 'bmc-ondemand');
    }
}
?>

<div class="bmc-pending-wrapper">
    <div class="bmc-pending-card">
        
        <!-- Encabezado con Logo y Título -->
        <div class="bmc-pending-header">
            <div class="bmc-pending-logo-wrap">
                <img src="<?php echo esc_url($logo_url); ?>" alt="BMCargo" class="bmc-pending-logo">
            </div>
            <div class="bmc-pending-title-wrap">
                <h1 class="bmc-pending-title"><?php esc_html_e('Tu tienda está en revisión', 'bmc-ondemand'); ?></h1>
            </div>
            <div class="bmc-pending-header-spacer"></div>
        </div>

        <p class="bmc-pending-subtitle">
            <?php esc_html_e('Hemos recibido tu solicitud correctamente. Nuestro equipo está verificando tu información para habilitar tu acceso a BM onDemand.', 'bmc-ondemand'); ?>
        </p>

        <?php if (!empty($status_message)): ?>
            <div class="notice notice-info is-dismissible" style="margin: 15px 0;">
                <p><?php echo esc_html($status_message); ?></p>
            </div>
        <?php endif; ?>

        <!-- Banner Azul Informativo -->
        <div class="bmc-pending-banner">
            <div class="bmc-pending-banner-icon">
                <span class="dashicons dashicons-info-outline"></span>
            </div>
            <div class="bmc-pending-banner-content">
                <strong class="bmc-pending-banner-title"><?php esc_html_e('Proceso de Aprobación en curso', 'bmc-ondemand'); ?></strong>
                <p class="bmc-pending-banner-text">
                    <?php echo wp_kses_post(__('Estamos validando tu información. Este proceso suele tardar entre <strong>2 y 12 horas</strong>. Te enviaremos un correo electrónico en cuanto tu cuenta esté activa y lista para usar.', 'bmc-ondemand')); ?>
                </p>
            </div>
        </div>

        <!-- Tarjeta de Próximos Pasos -->
        <div class="bmc-pending-steps-card">
            <h3 class="bmc-pending-steps-title"><?php esc_html_e('Próximos pasos:', 'bmc-ondemand'); ?></h3>
            <ol class="bmc-pending-steps-list">
                <li><?php esc_html_e('Revisión de datos de registro', 'bmc-ondemand'); ?></li>
                <li><?php esc_html_e('Verificación de elegibilidad', 'bmc-ondemand'); ?></li>
                <li><?php esc_html_e('Activación de credenciales', 'bmc-ondemand'); ?></li>
                <li><?php esc_html_e('Acceso completo al Dashboard', 'bmc-ondemand'); ?></li>
            </ol>
        </div>

        <!-- Botones de Acción -->
        <div class="bmc-pending-actions">
            <form method="post" action="" style="display:inline-block;">
                <?php wp_nonce_field('bmc_check_status_action', 'bmc_check_status_nonce'); ?>
                <button type="submit" class="button button-primary bmc-btn-refresh-status">
                    <span class="dashicons dashicons-update"></span>
                    <?php esc_html_e('Comprobar estado', 'bmc-ondemand'); ?>
                </button>
            </form>
            <a href="mailto:rsanchez@bmcargo.com?subject=Consulta%20Aprobaci%C3%B3n%20BMC%20OnDemand%20WooCommerce" class="bmc-pending-support-link" target="_blank">
                <?php esc_html_e('Contactar soporte', 'bmc-ondemand'); ?>
            </a>
        </div>

        <!-- Pie sutil -->
        <p class="bmc-pending-footer-text">
            <?php esc_html_e('Si crees que esto es un error, por favor contacta a soporte.', 'bmc-ondemand'); ?>
        </p>

    </div>
</div>
