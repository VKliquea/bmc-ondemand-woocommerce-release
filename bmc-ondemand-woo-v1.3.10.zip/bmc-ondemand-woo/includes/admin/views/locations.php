<?php
/**
 * Vista de Gestión y Edición de Sucursales / Pickup Locations
 * Con Selector de Coordenadas en Modal Interactivo Leaflet (Estilo Google Maps)
 */

if (!defined('ABSPATH')) {
    exit;
}

$notice = '';
$notice_type = 'success';
$edit_location = null;
$edit_id = isset($_GET['edit_id']) ? sanitize_text_field($_GET['edit_id']) : '';

// 1. Procesar Actualización de Sucursal
if (isset($_POST['bmc_update_location_nonce']) && wp_verify_nonce($_POST['bmc_update_location_nonce'], 'bmc_update_location_action')) {
    $loc_id = sanitize_text_field($_POST['loc_id'] ?? '');
    $name   = sanitize_text_field($_POST['loc_name'] ?? '');
    $address = array(
        'addressLine' => sanitize_text_field($_POST['loc_address'] ?? ''),
        'city'        => sanitize_text_field($_POST['loc_city'] ?? ''),
        'state'       => sanitize_text_field($_POST['loc_state'] ?? ''),
        'postalCode'  => sanitize_text_field($_POST['loc_postal_code'] ?? ''),
        'country'     => sanitize_text_field($_POST['loc_country'] ?? 'DO'),
        'latitude'    => floatval($_POST['loc_lat'] ?? 0),
        'longitude'   => floatval($_POST['loc_lng'] ?? 0),
    );

    $res = BMC_Locations::update_location($loc_id, $name, $address);
    if (is_wp_error($res)) {
        $notice = 'Error al actualizar sucursal: ' . $res->get_error_message();
        $notice_type = 'error';
    } elseif (isset($res['status']) && $res['status'] === 200) {
        $notice = 'Sucursal actualizada exitosamente en BMC OnDemand.';
        $edit_id = '';
    } else {
        $notice = 'Fallo al actualizar: ' . ($res['data']['message'] ?? 'Error desconocido');
        $notice_type = 'error';
    }
}

// 2. Procesar Creación de Sucursal
if (isset($_POST['bmc_create_location_nonce']) && wp_verify_nonce($_POST['bmc_create_location_nonce'], 'bmc_create_location_action')) {
    $name = sanitize_text_field($_POST['loc_name'] ?? '');
    $address = array(
        'addressLine' => sanitize_text_field($_POST['loc_address'] ?? ''),
        'city'        => sanitize_text_field($_POST['loc_city'] ?? ''),
        'state'       => sanitize_text_field($_POST['loc_state'] ?? ''),
        'postalCode'  => sanitize_text_field($_POST['loc_postal_code'] ?? ''),
        'country'     => sanitize_text_field($_POST['loc_country'] ?? 'DO'),
        'latitude'    => floatval($_POST['loc_lat'] ?? 0),
        'longitude'   => floatval($_POST['loc_lng'] ?? 0),
    );

    if (empty($name) || empty($address['addressLine']) || empty($address['latitude']) || empty($address['longitude'])) {
        $notice = 'Nombre, dirección, latitud y longitud son obligatorios.';
        $notice_type = 'error';
    } else {
        $res = BMC_Locations::create_location($name, $address);
        if (is_wp_error($res)) {
            $notice = 'Error al crear sucursal: ' . $res->get_error_message();
            $notice_type = 'error';
        } elseif (isset($res['status']) && in_array($res['status'], array(200, 201))) {
            $notice = 'Sucursal registrada exitosamente en BMC OnDemand.';
        } else {
            $notice = 'Fallo en la API: ' . ($res['data']['message'] ?? 'Error desconocido');
            $notice_type = 'error';
        }
    }
}

// 3. Procesar Eliminación
if (isset($_GET['action']) && $_GET['action'] === 'delete' && !empty($_GET['location_id']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'bmc_delete_loc_' . $_GET['location_id'])) {
    $del_res = BMC_Locations::delete_location($_GET['location_id']);
    if (is_wp_error($del_res)) {
        $notice = 'Error al eliminar sucursal: ' . $del_res->get_error_message();
        $notice_type = 'error';
    } else {
        $notice = 'Sucursal eliminada exitosamente.';
    }
}

$locations = BMC_Locations::get_all(true);

if (!empty($edit_id)) {
    $edit_location = BMC_Locations::get_location_by_id($edit_id);
}
?>

<!-- Leaflet CSS y JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>

<div class="wrap bmc-admin-container">
    <div class="bmc-admin-header">
        <h1 class="bmc-admin-title">Sucursales y Puntos de Retiro BMC OnDemand</h1>
    </div>

    <?php if (!empty($notice)): ?>
        <div class="notice notice-<?php echo esc_attr($notice_type); ?> is-dismissible" style="margin-bottom:20px;">
            <p><?php echo esc_html($notice); ?></p>
        </div>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1.8fr 1.2fr;gap:24px;align-items:start;">
        
        <!-- Tabla de Sucursales -->
        <div class="bmc-card" style="padding:0;overflow:hidden;">
            <div style="padding:16px 20px;border-bottom:1px solid #e2e8f0;">
                <h2 style="margin:0;font-size:16px;font-weight:700;">Sucursales Registradas (<?php echo count($locations); ?>)</h2>
            </div>
            <table class="wp-list-table widefat fixed striped" style="border:none;">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Dirección / Ciudad</th>
                        <th>Coordenadas GPS</th>
                        <th style="width:110px;text-align:right;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($locations)): ?>
                        <tr>
                            <td colspan="4" style="text-align:center;padding:24px;color:#64748b;">
                                No hay sucursales registradas. Completa el formulario para registrar la primera.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($locations as $loc): 
                            $id = $loc['locationId'] ?? '';
                            $edit_url = add_query_arg(array('edit_id' => $id));
                            $del_url  = wp_nonce_url(add_query_arg(array('action' => 'delete', 'location_id' => $id)), 'bmc_delete_loc_' . $id);
                        ?>
                            <tr class="<?php echo ($edit_id === $id) ? 'active' : ''; ?>">
                                <td>
                                    <strong><?php echo esc_html($loc['name'] ?? 'Sin nombre'); ?></strong><br>
                                    <code style="font-size:11px;"><?php echo esc_html($id); ?></code>
                                </td>
                                <td>
                                    <?php echo esc_html($loc['address']['addressLine'] ?? ''); ?><br>
                                    <small style="color:#64748b;"><?php echo esc_html(($loc['address']['city'] ?? '') . ', ' . ($loc['address']['country'] ?? '')); ?></small>
                                </td>
                                <td>
                                    <code style="font-size:11px;"><?php echo esc_html($loc['address']['latitude'] ?? '-'); ?>, <?php echo esc_html($loc['address']['longitude'] ?? '-'); ?></code>
                                </td>
                                <td style="text-align:right;">
                                    <a href="<?php echo esc_url($edit_url); ?>" class="button button-small">Editar</a>
                                    <a href="<?php echo esc_url($del_url); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('¿Seguro que deseas eliminar esta sucursal?');">&#215;</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Formulario (Crear o Editar) -->
        <div class="bmc-card">
            <h2 class="bmc-card-title">
                <?php echo $edit_location ? 'Editar Sucursal: ' . esc_html($edit_location['name']) : 'Registrar Nueva Sucursal'; ?>
            </h2>

            <form method="post" action="<?php echo esc_url(remove_query_arg('edit_id')); ?>" id="bmc-location-form">
                <?php if ($edit_location): ?>
                    <?php wp_nonce_field('bmc_update_location_action', 'bmc_update_location_nonce'); ?>
                    <input type="hidden" name="loc_id" value="<?php echo esc_attr($edit_location['locationId']); ?>">
                <?php else: ?>
                    <?php wp_nonce_field('bmc_create_location_action', 'bmc_create_location_nonce'); ?>
                <?php endif; ?>

                <div class="bmc-form-group">
                    <label for="loc_name">Nombre de la Sucursal</label>
                    <input type="text" name="loc_name" id="loc_name" class="bmc-input" required 
                           value="<?php echo esc_attr($edit_location['name'] ?? ''); ?>" 
                           placeholder="Ej: Sucursal Central Naco">
                </div>

                <div class="bmc-form-group">
                    <label for="loc_address">Dirección Física (Calle / Avenida)</label>
                    <input type="text" name="loc_address" id="loc_address" class="bmc-input" required 
                           value="<?php echo esc_attr($edit_location['address']['addressLine'] ?? ''); ?>" 
                           placeholder="Calle Presidente González #12">
                </div>

                <div class="bmc-grid-2col bmc-form-group">
                    <div>
                        <label for="loc_city">Ciudad</label>
                        <input type="text" name="loc_city" id="loc_city" class="bmc-input" required 
                               value="<?php echo esc_attr($edit_location['address']['city'] ?? 'Santo Domingo'); ?>">
                    </div>
                    <div>
                        <label for="loc_country">País (Código ISO)</label>
                        <input type="text" name="loc_country" id="loc_country" class="bmc-input" required 
                               value="<?php echo esc_attr($edit_location['address']['country'] ?? 'DO'); ?>">
                    </div>
                </div>

                <!-- Botón de apertura de Mapa -->
                <div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
                    <span style="font-size:13px;font-weight:600;color:#334155;">Coordenadas de Ubicación</span>
                    <button type="button" id="bmc-open-map-modal" class="button" style="display:inline-flex;align-items:center;gap:5px;color:#2563eb;border-color:#bfdbfe;font-weight:600;">
                        <span class="dashicons dashicons-location-alt" style="margin-top:2px;"></span> Buscar en Mapa
                    </button>
                </div>

                <div class="bmc-grid-2col bmc-form-group">
                    <div>
                        <label for="loc_lat">Latitud GPS</label>
                        <input type="number" step="any" name="loc_lat" id="loc_lat" class="bmc-input" required 
                               value="<?php echo esc_attr($edit_location['address']['latitude'] ?? ''); ?>" 
                               placeholder="18.4861">
                    </div>
                    <div>
                        <label for="loc_lng">Longitud GPS</label>
                        <input type="number" step="any" name="loc_lng" id="loc_lng" class="bmc-input" required 
                               value="<?php echo esc_attr($edit_location['address']['longitude'] ?? ''); ?>" 
                               placeholder="-69.9312">
                    </div>
                </div>

                <div style="margin-top:20px;display:flex;gap:10px;">
                    <button type="submit" class="bmc-btn-save" style="flex:1;">
                        <?php echo $edit_location ? 'Actualizar Sucursal' : 'Guardar Sucursal'; ?>
                    </button>
                    <?php if ($edit_location): ?>
                        <a href="<?php echo esc_url(remove_query_arg('edit_id')); ?>" class="button" style="padding:7px 14px;">Cancelar</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

    </div>
</div>

<!-- Modal de Mapa Leaflet con Estilo Google Maps -->
<div id="bmc-map-modal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(15,23,42,0.65);backdrop-filter:blur(3px);z-index:999999;align-items:center;justify-content:center;">
    <div style="background:#ffffff;border-radius:12px;width:90%;max-width:850px;box-shadow:0 20px 25px -5px rgba(0,0,0,0.3);overflow:hidden;display:flex;flex-direction:column;max-height:90vh;">
        <!-- Header del Modal -->
        <div style="padding:16px 22px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;">
            <div style="display:flex;align-items:center;gap:8px;">
                <span class="dashicons dashicons-location-alt" style="color:#2563eb;font-size:22px;"></span>
                <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">Seleccionar Coordenadas en el Mapa</h3>
            </div>
            <button type="button" id="bmc-close-map-modal" style="background:none;border:none;font-size:20px;cursor:pointer;color:#64748b;line-height:1;">&times;</button>
        </div>

        <!-- Barra de Búsqueda de Dirección en Mapa -->
        <div style="padding:12px 22px;background:#ffffff;border-bottom:1px solid #f1f5f9;display:flex;gap:10px;">
            <input type="text" id="bmc-map-search-input" placeholder="Buscar dirección o ciudad en el mapa..." style="flex:1;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;">
            <button type="button" id="bmc-map-search-btn" class="button" style="font-weight:600;">Buscar</button>
        </div>

        <!-- Contenedor del Mapa Leaflet -->
        <div id="bmc-leaflet-map" style="height:440px;width:100%;background:#e5e7eb;"></div>

        <!-- Footer con coordenadas seleccionadas y confirmación -->
        <div style="padding:14px 22px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;align-items:center;justify-content:space-between;">
            <div>
                <span style="font-size:12px;color:#64748b;">Coordenadas:</span>
                <strong id="bmc-map-coords-display" style="font-family:monospace;font-size:13px;color:#0f172a;margin-left:6px;">18.4861, -69.9312</strong>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="button" id="bmc-cancel-map-btn" class="button">Cancelar</button>
                <button type="button" id="bmc-apply-coords-btn" class="bmc-btn-save" style="padding:7px 18px !important;font-size:13px !important;">Aplicar Coordenadas</button>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    var map = null;
    var marker = null;
    var currentLat = 18.4861;
    var currentLng = -69.9312;

    function initMap() {
        if (map !== null) {
            map.invalidateSize();
            return;
        }

        var inputLat = parseFloat($('#loc_lat').val());
        var inputLng = parseFloat($('#loc_lng').val());

        if (!isNaN(inputLat) && !isNaN(inputLng) && inputLat !== 0) {
            currentLat = inputLat;
            currentLng = inputLng;
        }

        // Inicializar mapa centrado
        map = L.map('bmc-leaflet-map', {
            center: [currentLat, currentLng],
            zoom: 14
        });

        // Capa de mosaico estilo Google Maps (Google Maps Streets / CartoDB Voyager limpio)
        L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            attribution: '&copy; Google Maps'
        }).addTo(map);

        // Marcador arrastrable
        marker = L.marker([currentLat, currentLng], {
            draggable: true
        }).addTo(map);

        updateCoordsDisplay(currentLat, currentLng);

        // Evento al arrastrar marcador
        marker.on('dragend', function(e) {
            var position = marker.getLatLng();
            currentLat = position.lat;
            currentLng = position.lng;
            updateCoordsDisplay(currentLat, currentLng);
        });

        // Evento al hacer clic en cualquier parte del mapa
        map.on('click', function(e) {
            currentLat = e.latlng.lat;
            currentLng = e.latlng.lng;
            marker.setLatLng(e.latlng);
            updateCoordsDisplay(currentLat, currentLng);
        });
    }

    function updateCoordsDisplay(lat, lng) {
        $('#bmc-map-coords-display').text(lat.toFixed(6) + ', ' + lng.toFixed(6));
    }

    // Abrir Modal
    $('#bmc-open-map-modal').on('click', function(e) {
        e.preventDefault();
        $('#bmc-map-modal').css('display', 'flex');

        setTimeout(function() {
            initMap();
            // Si hay dirección en el formulario, precargarla en el buscador
            var addr = $('#loc_address').val();
            var city = $('#loc_city').val();
            if (addr || city) {
                $('#bmc-map-search-input').val((addr ? addr + ', ' : '') + city);
            }
        }, 200);
    });

    // Cerrar Modal
    $('#bmc-close-map-modal, #bmc-cancel-map-btn').on('click', function() {
        $('#bmc-map-modal').hide();
    });

    // Aplicar Coordenadas al Formulario
    $('#bmc-apply-coords-btn').on('click', function() {
        $('#loc_lat').val(currentLat.toFixed(6));
        $('#loc_lng').val(currentLng.toFixed(6));
        $('#bmc-map-modal').hide();
    });

    // Búsqueda de dirección con Nominatim
    function searchAddress() {
        var query = $('#bmc-map-search-input').val().trim();
        if (!query) return;

        $('#bmc-map-search-btn').prop('disabled', true).text('Buscando...');

        $.getJSON('https://nominatim.openstreetmap.org/search', {
            q: query,
            format: 'json',
            limit: 1
        }, function(data) {
            $('#bmc-map-search-btn').prop('disabled', false).text('Buscar');
            if (data && data.length > 0) {
                var lat = parseFloat(data[0].lat);
                var lon = parseFloat(data[0].lon);
                currentLat = lat;
                currentLng = lon;

                map.setView([lat, lon], 16);
                marker.setLatLng([lat, lon]);
                updateCoordsDisplay(lat, lon);
            } else {
                alert('No se encontraron resultados para la dirección buscada.');
            }
        }).fail(function() {
            $('#bmc-map-search-btn').prop('disabled', false).text('Buscar');
            alert('Error al consultar el servicio de geocodificación.');
        });
    }

    $('#bmc-map-search-btn').on('click', searchAddress);
    $('#bmc-map-search-input').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            searchAddress();
        }
    });
});
</script>
