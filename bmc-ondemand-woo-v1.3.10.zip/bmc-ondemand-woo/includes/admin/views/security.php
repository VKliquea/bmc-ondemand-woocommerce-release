<?php
/**
 * Vista de Política de Seguridad de BMC OnDemand
 */

if (!defined('ABSPATH')) {
    exit;
}

$api = BMC_API_Client::get_instance();
$response = $api->get_legal_document('security');
$document = 'No se pudo cargar la política de seguridad desde la API de BMCargo.';
$version = 'v1.0';

if (!empty($response['success']) && !empty($response['data']['document'])) {
    $document = $response['data']['document'];
    $version = $response['data']['version'] ?? 'v1.0';
}
?>

<div class="wrap bmc-admin-container">
    <div class="bmc-admin-header">
        <div>
            <h1 class="bmc-admin-title">Seguridad y Cumplimiento</h1>
            <p style="color:#64748b;margin:4px 0 0 0;">Versión oficial: <strong><?php echo esc_html($version); ?></strong></p>
        </div>
    </div>

    <div class="bmc-legal-document">
        <?php echo nl2br(esc_html($document)); ?>
    </div>
</div>
