<?php
/**
 * Vista de Configuración BMC OnDemand - Rediseño Fiel a la Imagen
 */

if (!defined('ABSPATH')) {
    exit;
}

$api = BMC_API_Client::get_instance();
$notice = '';
$notice_type = 'success';

// Guardar configuración cuando se envía el formulario
if (isset($_POST['bmc_save_config_nonce']) && wp_verify_nonce($_POST['bmc_save_config_nonce'], 'bmc_save_config_action')) {
    $shop_name = sanitize_text_field($_POST['shop_name'] ?? '');
    $owner_email = sanitize_email($_POST['owner_email'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $country = sanitize_text_field($_POST['country'] ?? 'DO');
    $currency = sanitize_text_field($_POST['currency'] ?? 'DOP');
    $carrier_enabled = isset($_POST['carrier_enabled']) ? 'yes' : 'no';
    $default_loc = sanitize_text_field($_POST['default_location'] ?? '');

    update_option('bmc_ondemand_store_name', $shop_name);
    update_option('bmc_ondemand_store_email', $owner_email);
    update_option('bmc_ondemand_store_phone', $phone);
    update_option('bmc_ondemand_store_country', $country);
    update_option('bmc_ondemand_store_currency', $currency);
    update_option('bmc_ondemand_carrier_enabled', $carrier_enabled);
    update_option('bmc_ondemand_default_location', $default_loc);

    // Conectar / sincronizar con BMCargo
    $connect_res = $api->register_and_connect_store(array(
        'shopName' => $shop_name,
        'ownerEmail' => $owner_email,
        'phone' => $phone,
        'country' => $country,
        'currency' => $currency,
    ));

    // Verificar en DynamoDB si la tienda ya tiene onfleetClientId o si está vacío
    $store_record = $api->get_store_record(true);
    $existing_onfleet_id = !empty($store_record['onfleetClientId']) ? trim($store_record['onfleetClientId']) : '';
    $onfleet_res = null;

    if (empty($existing_onfleet_id)) {
        // No tiene el campo o está vacío en DynamoDB -> sincronizar con Onfleet
        BMC_Logger::info("La tienda no tiene onfleetClientId en DynamoDB. Invocando sincronización con Onfleet...");
        $onfleet_res = $api->sync_onfleet_client($owner_email);
    } else {
        BMC_Logger::info("La tienda ya posee onfleetClientId en DynamoDB ({$existing_onfleet_id}). Omitiendo llamada a Onfleet.");
        update_option('bmc_ondemand_onfleet_client_id', $existing_onfleet_id);
    }

    if (is_wp_error($connect_res)) {
        $notice = 'Configuración guardada localmente, pero hubo un error conectando con BMCargo: ' . $connect_res->get_error_message();
        $notice_type = 'warning';
    } else {
        // Marcar que la tienda ya fue configurada al menos una vez
        update_option('bmc_ondemand_configured_once', 'yes');

        // Si la tienda aún no está activa, redirigir a la pantalla de espera de aprobación
        $status = $api->get_store_status(true);
        if ($status !== 'active') {
            wp_safe_redirect(admin_url('admin.php?page=bmc-ondemand'));
            exit;
        }

        $notice = 'Configuración guardada y tienda sincronizada exitosamente con BMC OnDemand.';
        if (!is_wp_error($onfleet_res) && !empty($onfleet_res['data']['onfleetClientId'])) {
            $notice .= ' (Onfleet vinculado: ' . esc_html($onfleet_res['data']['onfleetClientId']) . ')';
        }
    }
}

// Cargar valores actuales
$shop_name = get_option('bmc_ondemand_store_name', '');
$owner_email = get_option('bmc_ondemand_store_email', '');
$phone = get_option('bmc_ondemand_store_phone', '');
$country = get_option('bmc_ondemand_store_country', 'DO');
$currency = get_option('bmc_ondemand_store_currency', 'DOP');
$carrier_on = get_option('bmc_ondemand_carrier_enabled', 'yes') === 'yes';
$default_loc = get_option('bmc_ondemand_default_location', '');

$countries = array(
    'US' => 'Estados Unidos',
    'DO' => 'República Dominicana',
    'CO' => 'Colombia',
    'ES' => 'España',
    'MX' => 'México',
);

$currencies = array(
    'USD' => 'USD - US Dollar',
    'DOP' => 'DOP - Peso Dominicano',
    'COP' => 'COP - Peso Colombiano',
    'EUR' => 'EUR - Euro',
    'MXN' => 'MXN - Peso Mexicano',
);

$locations = BMC_Locations::get_all();
$logo_url = BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png';
?>

<div class="wrap bmc-admin-container">
    <form method="post" action="">
        <?php wp_nonce_field('bmc_save_config_action', 'bmc_save_config_nonce'); ?>

        <!-- Encabezado con Botón Guardar -->
        <div class="bmc-admin-header">
            <h1 class="bmc-admin-title">BMC Ondemand Configuración</h1>
            <button type="submit" class="bmc-btn-save">Guardar Configuración</button>
        </div>

        <?php if (!empty($notice)): ?>
            <div class="notice notice-<?php echo esc_attr($notice_type); ?> is-dismissible" style="margin-bottom:20px;">
                <p><?php echo esc_html($notice); ?></p>
            </div>
        <?php endif; ?>

        <!-- Grid Principal de 2 Columnas -->
        <div class="bmc-layout-grid">

            <!-- Columna Izquierda: Formulario -->
            <div class="bmc-card">
                <h2 class="bmc-card-title">Información de la Tienda</h2>

                <div class="bmc-form-group">
                    <label for="shop_name">Nombre de la tienda</label>
                    <input type="text" name="shop_name" id="shop_name" class="bmc-input"
                        value="<?php echo esc_attr($shop_name); ?>" required>
                </div>

                <div class="bmc-form-group">
                    <label for="owner_email">Contacto de e-mail</label>
                    <input type="email" name="owner_email" id="owner_email" class="bmc-input"
                        value="<?php echo esc_attr($owner_email); ?>" required>
                    <p class="bmc-field-help">Correo electrónico del propietario de la tienda</p>
                </div>

                <div class="bmc-form-group">
                    <label for="phone">Teléfono</label>
                    <input type="text" name="phone" id="phone" class="bmc-input" value="<?php echo esc_attr($phone); ?>"
                        required>
                    <p class="bmc-field-help">Número de teléfono de contacto</p>
                </div>

                <div class="bmc-grid-2col bmc-form-group">
                    <div>
                        <label for="country">País</label>
                        <select name="country" id="country" class="bmc-input">
                            <?php foreach ($countries as $code => $label): ?>
                                <option value="<?php echo esc_attr($code); ?>" <?php selected($country, $code); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="currency">Moneda</label>
                        <select name="currency" id="currency" class="bmc-input">
                            <?php foreach ($currencies as $code => $label): ?>
                                <option value="<?php echo esc_attr($code); ?>" <?php selected($currency, $code); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <?php if (!empty($locations)): ?>
                    <div class="bmc-form-group" style="margin-top:16px;">
                        <label for="default_location">Sucursal de Despacho Predeterminada</label>
                        <select name="default_location" id="default_location" class="bmc-input">
                            <option value="">-- Seleccionar Sucursal --</option>
                            <?php foreach ($locations as $loc): ?>
                                <option value="<?php echo esc_attr($loc['locationId']); ?>" <?php selected($default_loc, $loc['locationId']); ?>>
                                    <?php echo esc_html($loc['name'] ?? $loc['locationId']); ?>
                                    (<?php echo esc_html($loc['address']['city'] ?? ''); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="bmc-checkbox-card">
                    <input type="checkbox" name="carrier_enabled" id="carrier_enabled" value="1" <?php checked($carrier_on); ?>>
                    <div>
                        <label for="carrier_enabled" class="bmc-checkbox-title">Activar cálculo de tarifas en tiempo
                            real (Carrier Service)</label>
                        <p class="bmc-checkbox-desc">Permite que BMC OnDemand calcule las tarifas de envío
                            automáticamente en el carrito de compras.</p>
                    </div>
                </div>
            </div>

            <!-- Columna Derecha: Sidebar Informativo -->
            <div class="bmc-sidebar">

                <!-- Card Recomendaciones con Logo -->
                <div class="bmc-sidebar-card">
                    <h2 class="bmc-card-title">Recomendaciones</h2>
                    <div class="bmc-logo-container">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="BMC OnDemand" class="bmc-logo-img">
                    </div>
                </div>

                <!-- Card Próximos Pasos -->
                <div class="bmc-sidebar-card">
                    <h2 class="bmc-card-title">Próximos pasos</h2>
                    <ul class="bmc-steps-list">
                        <li class="bmc-step-item">
                            <span class="bmc-step-badge">1</span>
                            <p class="bmc-step-text">Guarda la configuración para registrar tu tienda en BMC On Demand.
                            </p>
                        </li>
                        <li class="bmc-step-item">
                            <span class="bmc-step-badge">2</span>
                            <p class="bmc-step-text">Activa la autosincronización y selecciona una sucursal para que las
                                órdenes se envíen automáticamente al cambiar de estado.</p>
                        </li>
                        <li class="bmc-step-item">
                            <span class="bmc-step-badge">3</span>
                            <p class="bmc-step-text">Ve a la sección de Órdenes para enviar manualmente las que desees a
                                BMC On Demand.</p>
                        </li>
                    </ul>
                </div>
                <!-- Card Versión y Actualizaciones -->
                <div class="bmc-version-card">
                    <div><strong>Versión:</strong> <?php echo esc_html(BMC_ONDEMAND_VERSION); ?></div>
                </div>
            </div>
        </div>
    </form>
</div>