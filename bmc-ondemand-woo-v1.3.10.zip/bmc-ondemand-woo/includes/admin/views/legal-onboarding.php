<?php
/**
 * Vista de Onboarding Legal Obligatorio
 * Se muestra la primera vez que se accede al plugin si no se han aceptado los Términos y Condiciones
 */

if (!defined('ABSPATH')) {
    exit;
}

$logo_url = BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png';
$terms_url = admin_url('admin.php?page=bmc-ondemand-terms');
$privacy_url = admin_url('admin.php?page=bmc-ondemand-privacy');
$security_url = admin_url('admin.php?page=bmc-ondemand-security');

$error_msg = '';
$api = BMC_API_Client::get_instance();
$terms_data = $api->get_legal_document('terms');
$terms_text = $terms_data['data']['document'] ?? '';

if (empty($terms_text)) {
    // Texto formal de respaldo si no hay conexión temporal con la API
    $terms_text = "TÉRMINOS Y CONDICIONES DEL SERVICIO - BMC ONDEMAND\n\n"
        . "1. Objeto y Alcance del Servicio\n"
        . "BMC OnDemand (BM Drive) proporciona servicios de cotización logística en tiempo real, recolección (pickup) y entrega a domicilio (delivery) de paquetes a través de la infraestructura logística de Business Mail & Cargo (BM Cargo).\n\n"
        . "2. Integración y Tratamiento de Información\n"
        . "Al activar la integración con WooCommerce, el comercio consiente la transmisión de información estrictamente necesaria para la prestación del servicio: nombre de destinatario, dirección de entrega, número de contacto, dimensiones y peso del paquete, así como el número de pedido para propósitos de seguimiento (tracking).\n\n"
        . "3. Tarifas y Despacho\n"
        . "Las tarifas de entrega son calculadas según las reglas de zonas y servicios configurados, o cotizadas en tiempo real mediante coordenadas GPS. BM Cargo se compromete a realizar la entrega en los tiempos y condiciones estipuladas según el tipo de servicio seleccionado.\n\n"
        . "4. Responsabilidad y Cobertura\n"
        . "El comercio es responsable de garantizar el embalaje adecuado de los productos para su manipulación y transporte. BM Cargo responderá por la custodia de los paquetes desde su recolección hasta su entrega final conforme a las políticas generales de transporte de carga y paquetería.\n\n"
        . "5. Modificaciones y Actualizaciones\n"
        . "BM Cargo se reserva el derecho de actualizar los presentes términos y tarifas notificando oportunamente a través de la plataforma.";
}

if (isset($_POST['bmc_accept_legal_nonce']) && wp_verify_nonce($_POST['bmc_accept_legal_nonce'], 'bmc_accept_legal_action')) {
    if (!empty($_POST['bmc_terms_accepted'])) {
        update_option('bmc_ondemand_legal_accepted', 'yes');
        update_option('bmc_ondemand_legal_accepted_at', current_time('mysql'));
        update_option('bmc_ondemand_legal_accepted_ip', $_SERVER['REMOTE_ADDR'] ?? '');

        // Provisionar credenciales y registrar tienda en AWS Cognito y DynamoDB
        $shop_name   = get_option('bmc_ondemand_store_name', get_bloginfo('name') ?: 'Tienda WooCommerce');
        $owner_email = get_option('bmc_ondemand_store_email', get_option('admin_email'));
        $phone       = get_option('bmc_ondemand_store_phone', '+18090000000');
        $country     = get_option('bmc_ondemand_store_country', 'DO');
        $currency    = get_option('bmc_ondemand_store_currency', 'DOP');

        $connect_res = $api->register_and_connect_store(array(
            'shopName'   => $shop_name,
            'ownerEmail' => $owner_email,
            'phone'      => $phone,
            'country'    => $country,
            'currency'   => $currency,
        ));

        if (is_wp_error($connect_res)) {
            BMC_Logger::error('Error registrando tienda en Cognito tras aceptar términos: ' . $connect_res->get_error_message());
        }

        // Redirigir directamente a la página de Configuración
        wp_safe_redirect(admin_url('admin.php?page=bmc-ondemand-settings'));
        exit;
    } else {
        $error_msg = __('Debes marcar la casilla para confirmar que has leído y aceptas los términos y condiciones.', 'bmc-ondemand');
    }
}
?>

<div class="bmc-onboarding-wrapper">
    <div class="bmc-onboarding-card">
        
        <div class="bmc-onboarding-header">
            <img src="<?php echo esc_url($logo_url); ?>" alt="BMC OnDemand" class="bmc-onboarding-logo">
            <h1 class="bmc-onboarding-title"><?php esc_html_e('Bienvenido a BMC OnDemand', 'bmc-ondemand'); ?></h1>
            <p class="bmc-onboarding-subtitle">
                <?php esc_html_e('Para comenzar a disfrutar de los servicios de envíos locales y entregas bajo demanda, por favor revisa y acepta los términos de servicio.', 'bmc-ondemand'); ?>
            </p>
        </div>

        <?php if (!empty($error_msg)): ?>
            <div class="notice notice-error bmc-onboarding-notice">
                <p><?php echo esc_html($error_msg); ?></p>
            </div>
        <?php endif; ?>

        <!-- Contenedor con Scroll para Términos y Condiciones Directos -->
        <div class="bmc-terms-scroll-card">
            <div class="bmc-terms-scroll-header">
                <span class="dashicons dashicons-media-document"></span>
                <strong><?php esc_html_e('Términos y Condiciones de Servicio', 'bmc-ondemand'); ?></strong>
            </div>
            <div class="bmc-terms-scroll-body">
                <?php echo nl2br(esc_html($terms_text)); ?>
            </div>
        </div>

        <form method="post" action="" class="bmc-onboarding-form">
            <?php wp_nonce_field('bmc_accept_legal_action', 'bmc_accept_legal_nonce'); ?>

            <div class="bmc-checkbox-wrapper" style="margin-top: 18px;">
                <label class="bmc-checkbox-container">
                    <input type="checkbox" name="bmc_terms_accepted" id="bmc_terms_accepted" value="1" required>
                    <span class="bmc-checkbox-text">
                        <?php esc_html_e('He leído y acepto los Términos y Condiciones, la Política de Privacidad y las condiciones de servicio de BMC OnDemand.', 'bmc-ondemand'); ?>
                    </span>
                </label>
            </div>

            <div class="bmc-onboarding-actions">
                <button type="submit" class="button button-primary button-hero bmc-btn-accept">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php esc_html_e('Aceptar y Continuar a Configuración', 'bmc-ondemand'); ?>
                </button>
            </div>
        </form>

    </div>
</div>
