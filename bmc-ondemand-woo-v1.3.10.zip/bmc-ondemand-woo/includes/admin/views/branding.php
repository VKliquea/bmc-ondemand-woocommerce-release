<?php
/**
 * Vista de Administración: Configuración de Branding de Etiquetas
 */

if (!defined('ABSPATH')) {
    exit;
}

$branding = BMC_Label_Printer::get_branding_config();
$saved = isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true';
?>
<div class="wrap bmc-branding-wrap">
    <h1 style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <span class="dashicons dashicons-art" style="font-size:32px;width:32px;height:32px;color:#008060;"></span>
        <?php _e('Branding de Etiquetas (4x6)', 'bmc-ondemand'); ?>
    </h1>

    <?php if ($saved): ?>
        <div class="notice notice-success is-dismissible" style="border-left-color:#008060;">
            <p><strong><?php _e('¡Configuración de branding guardada exitosamente!', 'bmc-ondemand'); ?></strong></p>
        </div>
    <?php endif; ?>

    <p style="color:#64748b;font-size:14px;max-width:850px;margin-bottom:20px;">
        <?php _e('Personaliza la apariencia de las etiquetas de envío térmicas 4x6. Configura el logo de tu empresa, nombre comercial, dirección de despacho y datos de contacto que se imprimirán en cada paquete enviado.', 'bmc-ondemand'); ?>
    </p>

    <div style="display:flex;gap:30px;align-items:flex-start;flex-wrap:wrap;">
        <!-- Formulario de Configuración -->
        <div style="flex:1;min-width:320px;max-width:550px;background:#fff;padding:24px;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
            <form method="post" action="options.php">
                <?php
                settings_fields('bmc_ondemand_branding_group');
                do_settings_sections('bmc_ondemand_branding_group');
                ?>

                <div style="margin-bottom:20px;">
                    <label for="bmc_branding_logo" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Logo de la Empresa (URL o Imagen)', 'bmc-ondemand'); ?>
                    </label>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="bmc_branding_logo" name="bmc_ondemand_branding_logo"
                            value="<?php echo esc_attr($branding['logo_url']); ?>"
                            class="regular-text" style="flex:1;" placeholder="https://tudominio.com/logo.png" />
                        <button type="button" class="button" id="bmc_btn_upload_logo">
                            <?php _e('Subir Logo', 'bmc-ondemand'); ?>
                        </button>
                    </div>
                    <p class="description" style="margin-top:4px;color:#64748b;">
                        <?php _e('Recomendado: formato PNG o JPG con fondo transparente o blanco.', 'bmc-ondemand'); ?>
                    </p>
                </div>

                <div style="margin-bottom:20px;">
                    <label for="bmc_branding_business_name" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Nombre Comercial de la Empresa', 'bmc-ondemand'); ?>
                    </label>
                    <input type="text" id="bmc_branding_business_name" name="bmc_ondemand_branding_business_name"
                        value="<?php echo esc_attr($branding['business_name']); ?>"
                        class="regular-text" style="width:100%;" placeholder="Mi Empresa S.R.L." required />
                </div>

                <div style="margin-bottom:20px;">
                    <label for="bmc_branding_address" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Dirección de Despacho (Origen / Remitente)', 'bmc-ondemand'); ?>
                    </label>
                    <textarea id="bmc_branding_address" name="bmc_ondemand_branding_address"
                        rows="3" class="large-text" style="width:100%;" placeholder="Av. Principal #123, Almacén 4, Santo Domingo, D.N."><?php echo esc_textarea($branding['dispatch_address']); ?></textarea>
                </div>

                <div style="margin-bottom:20px;">
                    <label for="bmc_branding_phone" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Teléfono de Contacto de la Empresa', 'bmc-ondemand'); ?>
                    </label>
                    <input type="text" id="bmc_branding_phone" name="bmc_ondemand_branding_phone"
                        value="<?php echo esc_attr($branding['phone']); ?>"
                        class="regular-text" style="width:100%;" placeholder="809-555-0199" />
                </div>

                <div style="margin-bottom:20px;">
                    <label for="bmc_branding_subtitle" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Subtítulo o Lema en la Etiqueta', 'bmc-ondemand'); ?>
                    </label>
                    <input type="text" id="bmc_branding_subtitle" name="bmc_ondemand_branding_subtitle"
                        value="<?php echo esc_attr($branding['subtitle']); ?>"
                        class="regular-text" style="width:100%;" placeholder="Logística · Despacho a Domicilio" />
                </div>

                <div style="margin-bottom:24px;">
                    <label for="bmc_branding_footer" style="display:block;font-weight:600;margin-bottom:6px;color:#1e293b;">
                        <?php _e('Texto de Marca al Pie de Página', 'bmc-ondemand'); ?>
                    </label>
                    <input type="text" id="bmc_branding_footer" name="bmc_ondemand_branding_footer"
                        value="<?php echo esc_attr($branding['footer_brand']); ?>"
                        class="regular-text" style="width:100%;" placeholder="Kliquea · BMC OnDemand" />
                </div>

                <?php submit_button(__('Guardar Cambios de Branding', 'bmc-ondemand'), 'primary button-hero'); ?>
            </form>
        </div>

        <!-- Previsualización en Vivo de la Etiqueta 4x6 -->
        <div style="flex:1;min-width:320px;max-width:440px;">
            <div style="font-weight:700;margin-bottom:8px;color:#334155;display:flex;align-items:center;gap:6px;">
                <span class="dashicons dashicons-visibility"></span>
                <?php _e('Previsualización de la Etiqueta 4x6', 'bmc-ondemand'); ?>
            </div>
            <div id="bmc-preview-container" style="background:#fff;border:2px dashed #94a3b8;border-radius:6px;padding:16px;box-shadow:0 4px 12px rgba(0,0,0,0.06);font-family:Arial,sans-serif;">
                <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #000;padding-bottom:6px;margin-bottom:8px;">
                    <div>
                        <img id="preview-logo" src="<?php echo esc_url($branding['logo_url'] ?: BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png'); ?>"
                            style="height:36px;max-width:180px;object-fit:contain;display:block;" />
                        <div id="preview-subtitle" style="font-size:10px;font-weight:bold;color:#003366;margin-top:2px;">
                            <?php echo esc_html($branding['subtitle'] ?: 'LOGÍSTICA · DESPACHO A DOMICILIO'); ?>
                        </div>
                    </div>
                    <div style="font-size:11px;font-weight:bold;"><?php echo date('d/m/Y'); ?></div>
                </div>

                <div style="margin-bottom:10px;">
                    <div style="font-size:10px;font-weight:bold;color:#003366;display:flex;justify-content:space-between;">
                        <span>NO. DE PEDIDO EN <span id="preview-store-name-sub"><?php echo esc_html($branding['business_name']); ?></span></span>
                        <span>1 ÍTEM</span>
                    </div>
                    <div style="font-size:20px;font-weight:900;">#1142</div>
                </div>

                <div style="margin-bottom:10px;font-size:11px;line-height:1.35;">
                    <div style="font-size:10px;font-weight:bold;color:#003366;">REMITENTE (ORIGEN)</div>
                    <strong id="preview-business-name"><?php echo esc_html($branding['business_name'] ?: 'Mi Tienda'); ?></strong><br>
                    <span id="preview-address"><?php echo esc_html($branding['dispatch_address'] ?: 'Dirección de la empresa...'); ?></span>
                </div>

                <div style="margin-bottom:10px;font-size:11px;line-height:1.35;">
                    <div style="font-size:10px;font-weight:bold;color:#003366;">DESTINATARIO (CLIENTE)</div>
                    <strong>JAYZA ROSSO</strong><br>
                    <span>Residencial Luis Emilio, Av. Gustavo Mejía Ricart 154, Distrito Nacional, DO · Tel: 8296429849</span>
                </div>

                <div style="border-top:2px solid #000;padding-top:8px;margin-top:16px;display:flex;justify-content:space-between;align-items:flex-end;">
                    <div>
                        <div style="font-size:10px;color:#333;">
                            <strong id="preview-footer"><?php echo esc_html($branding['footer_brand'] ?: 'Kliquea · BMC OnDemand'); ?></strong> &bull; Pedido #1142
                        </div>
                    </div>
                    <div style="display:flex;flex-direction:column;align-items:center;">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&margin=2&data=ad1f59f1" style="width:65px;height:65px;display:block;" alt="QR" />
                        <span style="font-size:9px;font-weight:700;color:#000;margin-top:2px;">ad1f59f1</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Media Uploader de WordPress para el Logo
    $('#bmc_btn_upload_logo').on('click', function(e) {
        e.preventDefault();
        var customUploader = wp.media({
            title: '<?php _e('Seleccionar Logo para Etiquetas', 'bmc-ondemand'); ?>',
            button: {
                text: '<?php _e('Usar este Logo', 'bmc-ondemand'); ?>'
            },
            multiple: false
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').first().toJSON();
            $('#bmc_branding_logo').val(attachment.url).trigger('input');
        });

        customUploader.open();
    });

    // Actualización reactiva del Live Preview
    $('#bmc_branding_logo').on('input change', function() {
        var url = $(this).val().trim();
        $('#preview-logo').attr('src', url || '<?php echo esc_js(BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png'); ?>');
    });

    $('#bmc_branding_business_name').on('input change', function() {
        var name = $(this).val().trim() || 'Mi Tienda';
        $('#preview-business-name').text(name);
        $('#preview-store-name-sub').text(name);
    });

    $('#bmc_branding_address, #bmc_branding_phone').on('input change', function() {
        var addr = $('#bmc_branding_address').val().trim();
        var phone = $('#bmc_branding_phone').val().trim();
        var full = addr;
        if (phone) {
            full += (full ? ' · Tel: ' : 'Tel: ') + phone;
        }
        $('#preview-address').text(full || 'Dirección de la empresa...');
    });

    $('#bmc_branding_subtitle').on('input change', function() {
        var sub = $(this).val().trim() || 'LOGÍSTICA · DESPACHO A DOMICILIO';
        $('#preview-subtitle').text(sub.toUpperCase());
    });

    $('#bmc_branding_footer').on('input change', function() {
        var ftr = $(this).val().trim() || 'Kliquea · BMC OnDemand';
        $('#preview-footer').text(ftr);
    });
});
</script>
