<?php
/**
 * Inicializador Core de BMC OnDemand para WooCommerce
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Core {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        // Encolar scripts en el checkout para geocodificación / lat-lng
        add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_scripts'));

        // Endpoint AJAX para guardar las coordenadas en sesión de WooCommerce
        add_action('wp_ajax_bmc_save_checkout_coords', array($this, 'ajax_save_checkout_coords'));
        add_action('wp_ajax_nopriv_bmc_save_checkout_coords', array($this, 'ajax_save_checkout_coords'));

        // Guardar coordenadas en metadata del pedido durante el checkout
        add_action('woocommerce_checkout_update_order_meta', array($this, 'save_order_coordinates'), 10, 2);

        // Enlace de configuración en la lista de plugins de WP
        add_filter('plugin_action_links_' . BMC_ONDEMAND_PLUGIN_BASENAME, array($this, 'add_plugin_action_links'));
    }

    public function enqueue_checkout_scripts() {
        if (is_checkout() && !is_order_received_page()) {
            wp_enqueue_script(
                'bmc-checkout-geo',
                BMC_ONDEMAND_PLUGIN_URL . 'assets/js/checkout-geolocation.js',
                array('jquery'),
                BMC_ONDEMAND_VERSION,
                true
            );

            wp_localize_script('bmc-checkout-geo', 'bmc_geo_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('bmc_geo_nonce'),
            ));
        }
    }

    public function ajax_save_checkout_coords() {
        check_ajax_referer('bmc_geo_nonce', 'security');

        $lat = floatval($_POST['lat'] ?? 0);
        $lng = floatval($_POST['lng'] ?? 0);

        if ($lat && $lng && WC()->session) {
            WC()->session->set('bmc_destination_lat', $lat);
            WC()->session->set('bmc_destination_lng', $lng);
            wp_send_json_success(array('lat' => $lat, 'lng' => $lng));
        }

        wp_send_json_error('Coordenadas inválidas');
    }

    public function save_order_coordinates($order_id, $data) {
        if (WC()->session) {
            $lat = WC()->session->get('bmc_destination_lat');
            $lng = WC()->session->get('bmc_destination_lng');

            if ($lat && $lng) {
                update_post_meta($order_id, '_shipping_latitude', $lat);
                update_post_meta($order_id, '_shipping_longitude', $lng);
                update_post_meta($order_id, '_billing_latitude', $lat);
                update_post_meta($order_id, '_billing_longitude', $lng);
            }
        }
    }

    public function add_plugin_action_links($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=bmc-ondemand') . '">' . __('Configuración', 'bmc-ondemand') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}
