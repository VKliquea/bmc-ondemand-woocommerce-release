<?php
/**
 * Servicio de métricas y datos de órdenes para el Dashboard de BMC OnDemand
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Dashboard_Service {

    /**
     * Obtiene las métricas y la lista de órdenes para el Dashboard
     *
     * @param array $filters Filtros de búsqueda (status, from_date, to_date, limit, page)
     * @return array
     */
    public static function get_dashboard_data($filters = array()) {
        $status_filter = sanitize_text_field($filters['status'] ?? 'all');
        $from_date     = sanitize_text_field($filters['from_date'] ?? '');
        $to_date       = sanitize_text_field($filters['to_date'] ?? '');
        $per_page      = max(1, intval($filters['limit'] ?? 10));
        $current_page  = max(1, intval($filters['page'] ?? 1));

        $all_orders = self::fetch_all_orders();

        // 1. Calcular métricas globales (antes de filtrar la tabla)
        $total_deliveries    = count($all_orders);
        $packages_delivered  = 0;
        $deliveries_failed   = 0;
        $ongoing_orders      = 0;

        foreach ($all_orders as $ord) {
            $st = strtolower($ord['raw_status'] ?? '');
            if (in_array($st, array('delivered', 'dropoff_completed', 'completed', 'entregado'), true)) {
                $packages_delivered++;
            } elseif (in_array($st, array('failed', 'pickup_failed', 'dropoff_failed', 'fallido', 'cancelled'), true)) {
                $deliveries_failed++;
            } else {
                // created, pending, pickup_started, dropoff_started, en_curso
                $ongoing_orders++;
            }
        }

        $efficiency = $total_deliveries > 0
            ? round(($packages_delivered / ($packages_delivered + $deliveries_failed ?: 1)) * 100, 1)
            : 0;

        $return_rate = $total_deliveries > 0
            ? round(($deliveries_failed / $total_deliveries) * 100, 1)
            : 0;

        // 2. Aplicar filtros para la tabla
        $filtered_orders = array_filter($all_orders, function ($o) use ($status_filter, $from_date, $to_date) {
            // Filtro por Estado
            if (!empty($status_filter) && $status_filter !== 'all') {
                $order_code = strtolower($o['status_code'] ?? '');
                $order_raw  = strtolower($o['raw_status'] ?? '');
                $target_st  = strtolower($status_filter);

                if ($target_st === 'ongoing') {
                    if (!in_array($order_code, array('ongoing'), true) && !in_array($order_raw, array('pickup_started', 'dropoff_started', 'pickup_completed', 'en_curso', 'transito'), true)) {
                        return false;
                    }
                } elseif ($target_st === 'delivered') {
                    if ($order_code !== 'delivered' && !in_array($order_raw, array('delivered', 'dropoff_completed', 'completed', 'entregado'), true)) {
                        return false;
                    }
                } elseif ($target_st === 'failed') {
                    if ($order_code !== 'failed' && !in_array($order_raw, array('failed', 'pickup_failed', 'dropoff_failed', 'fallido', 'cancelled'), true)) {
                        return false;
                    }
                } elseif ($target_st === 'pending') {
                    if ($order_code !== 'pending' && $order_raw !== 'pending') {
                        return false;
                    }
                } elseif ($target_st === 'created') {
                    if ($order_code !== 'created' && $order_raw !== 'created') {
                        return false;
                    }
                } elseif ($order_code !== $target_st && $order_raw !== $target_st) {
                    return false;
                }
            }

            // Filtro por Rango de Fechas
            $order_date = trim($o['date'] ?? '');
            if (!empty($order_date) && strlen($order_date) >= 10) {
                $order_day = substr($order_date, 0, 10); // 'YYYY-MM-DD'

                if (!empty($from_date)) {
                    $clean_from = substr(trim($from_date), 0, 10);
                    if ($order_day < $clean_from) {
                        return false;
                    }
                }
                if (!empty($to_date)) {
                    $clean_to = substr(trim($to_date), 0, 10);
                    if ($order_day > $clean_to) {
                        return false;
                    }
                }
            }

            return true;
        });

        // Reindexar array
        $filtered_orders = array_values($filtered_orders);
        $total_filtered  = count($filtered_orders);
        $total_pages     = max(1, ceil($total_filtered / $per_page));

        // Paginación
        $offset = ($current_page - 1) * $per_page;
        $paginated_orders = array_slice($filtered_orders, $offset, $per_page);

        return array(
            'metrics' => array(
                'total_deliveries'   => $total_deliveries,
                'growth_rate'        => '+0.0%',
                'packages_delivered' => $packages_delivered,
                'efficiency'         => $efficiency . '%',
                'return_rate'        => $return_rate . '%',
                'ongoing_orders'     => $ongoing_orders,
            ),
            'orders'       => $paginated_orders,
            'total_orders' => $total_filtered,
            'total_pages'  => $total_pages,
            'current_page' => $current_page,
            'per_page'     => $per_page,
        );
    }

    /**
     * Normaliza el código de país (ej. 'DOMINICAN REPUBLIC' -> 'DO', 'UNITED STATES' -> 'US')
     */
    private static function normalize_country($country) {
        $c = strtoupper(trim((string) $country));
        $aliases = array(
            'DOMINICAN REPUBLIC'       => 'DO',
            'REPUBLICA DOMINICANA'     => 'DO',
            'REPÚBLICA DOMINICANA'     => 'DO',
            'COLOMBIA'                 => 'CO',
            'ESPAÑA'                   => 'ES',
            'SPAIN'                    => 'ES',
            'MÉXICO'                   => 'MX',
            'MEXICO'                   => 'MX',
            'UNITED STATES'            => 'US',
            'UNITED STATES OF AMERICA' => 'US',
            'ESTADOS UNIDOS'           => 'US',
            'BOLIVIA'                  => 'BO',
        );
        return $aliases[$c] ?? $c;
    }

    /**
     * Consulta las órdenes retornadas por la API de BMC OnDemand (BM Drive + DynamoDB Internacional)
     */
    private static function fetch_all_orders() {
        $orders_data = array();
        $seen_order_keys = array();

        $api = BMC_API_Client::get_instance();
        $configured_country = get_option(BMC_API_Client::OPTION_STORE_COUNTRY, '');
        $store_country = !empty($configured_country) ? self::normalize_country($configured_country) : '';

        // 1. Consultar órdenes nacionales desde BM Drive API (solo si el país configurado es DO o no está configurado)
        $raw_orders = array();
        if ($store_country === 'DO' || empty($store_country)) {
            $api_res = $api->get_orders();
            if (!is_wp_error($api_res) && !empty($api_res['data'])) {
                $drive_orders = $api_res['data']['orders'] ?? $api_res['data']['data'] ?? (is_array($api_res['data']) ? $api_res['data'] : array());
                if (is_array($drive_orders)) {
                    $raw_orders = array_merge($raw_orders, $drive_orders);
                }
            }
        }

        // 2. Consultar órdenes registradas en DynamoDB para esta tienda
        $international_orders = $api->get_international_orders();
        if (!empty($international_orders) && is_array($international_orders)) {
            $raw_orders = array_merge($raw_orders, $international_orders);
        }

        if (is_array($raw_orders)) {
            foreach ($raw_orders as $remote_order) {
                // Si la tienda tiene un país configurado explícitamente, filtrar por ese país
                if (!empty($store_country)) {
                    $order_country_raw = $remote_order['order']['country'] ?? $remote_order['customer']['address']['country'] ?? '';
                    $order_country = self::normalize_country($order_country_raw);

                    if (!empty($order_country) && $order_country !== $store_country) {
                        continue;
                    }
                }

                $ext_order_id = (string) ($remote_order['order']['externalOrderId'] ?? '');
                $bmc_order_id = (string) ($remote_order['orderId'] ?? '');
                $tracking     = (string) ($remote_order['tracking'] ?? '');
                $raw_status   = (string) ($remote_order['status'] ?? 'created');

                // Evitar duplicados por orderId o externalOrderId
                $dedup_key = $bmc_order_id ?: $ext_order_id;
                if (!empty($dedup_key)) {
                    if (isset($seen_order_keys[$dedup_key])) {
                        continue;
                    }
                    $seen_order_keys[$dedup_key] = true;
                }

                // Si viene como "44-7ad5" o "gid://shopify/Order/7654722076844-...", extraer ID limpio
                $wc_order_id = 0;
                $clean_id = $ext_order_id;
                if (!empty($ext_order_id)) {
                    // Si viene como URI de Shopify, tomar el último segmento
                    $clean_id = basename(str_replace('\\', '/', $ext_order_id));
                    $parts = explode('-', $clean_id);
                    $clean_id = reset($parts); // Tomar solo la primera parte ("44" o "58")
                    $wc_order_id = intval($clean_id);
                }

                $display_id = !empty($clean_id) ? ('#' . ltrim($clean_id, '#')) : ('#' . substr($bmc_order_id, 0, 8));

                // Datos del cliente
                $customer_name = $remote_order['customer']['fullName'] ?? 'Cliente';
                $addr_obj = $remote_order['customer']['address'] ?? array();
                $address = $addr_obj['addressLine'] ?? '';
                if (!empty($addr_obj['city'])) {
                    $address = ($address ? $address . ', ' : '') . $addr_obj['city'];
                }

                // Fecha formateada (Unix timestamp en segundos o ISO string)
                $created_at = $remote_order['createdAt'] ?? null;
                $date_str = date('Y-m-d');
                if (is_numeric($created_at)) {
                    $date_str = date('Y-m-d', intval($created_at));
                } elseif (!empty($created_at) && is_string($created_at)) {
                    $date_str = substr($created_at, 0, 10);
                }

                $orders_data[] = self::normalize_order_item(array(
                    'id'            => $display_id,
                    'wc_order_id'   => $wc_order_id,
                    'bmc_order_id'  => $bmc_order_id,
                    'tracking'      => $tracking,
                    'customer_name' => $customer_name,
                    'address'       => $address ?: 'Dirección no especificada',
                    'raw_status'    => $raw_status,
                    'date'          => $date_str,
                ));
            }
        }

        return $orders_data;
    }

    /**
     * Normaliza un item de orden con textos y badges de estado
     */
    private static function normalize_order_item($item) {
        $st = strtolower($item['raw_status'] ?? 'created');

        $status_map = array(
            'created'           => array('code' => 'created', 'label' => 'Creado', 'class' => 'bmc-badge-created', 'icon' => 'dashicons-info'),
            'pending'           => array('code' => 'pending', 'label' => 'Pendiente', 'class' => 'bmc-badge-pending', 'icon' => 'dashicons-clock'),
            'pickup_started'    => array('code' => 'ongoing', 'label' => 'Pickup en curso', 'class' => 'bmc-badge-ongoing', 'icon' => 'dashicons-update'),
            'dropoff_started'   => array('code' => 'ongoing', 'label' => 'En tránsito', 'class' => 'bmc-badge-ongoing', 'icon' => 'dashicons-car'),
            'pickup_completed'  => array('code' => 'ongoing', 'label' => 'Recolectado', 'class' => 'bmc-badge-ongoing', 'icon' => 'dashicons-yes'),
            'dropoff_completed' => array('code' => 'delivered', 'label' => 'Entregado', 'class' => 'bmc-badge-delivered', 'icon' => 'dashicons-yes-alt'),
            'delivered'         => array('code' => 'delivered', 'label' => 'Entregado', 'class' => 'bmc-badge-delivered', 'icon' => 'dashicons-yes-alt'),
            'failed'            => array('code' => 'failed', 'label' => 'Fallido', 'class' => 'bmc-badge-failed', 'icon' => 'dashicons-warning'),
            'dropoff_failed'    => array('code' => 'failed', 'label' => 'Entrega fallida', 'class' => 'bmc-badge-failed', 'icon' => 'dashicons-warning'),
        );

        $badge_info = $status_map[$st] ?? array(
            'code'  => $st,
            'label' => ucfirst($st),
            'class' => 'bmc-badge-created',
            'icon'  => 'dashicons-info',
        );

        // Si es pending pero no estaba mapeado
        if ($st === 'pending') {
            $badge_info['class'] = 'bmc-badge-pending';
            $badge_info['icon'] = 'dashicons-clock';
        }

        $item['status_label'] = $badge_info['label'];
        $item['status_code']  = $badge_info['code'];
        $item['status_class'] = $badge_info['class'];
        $item['status_icon']  = $badge_info['icon'];

        return $item;
    }
}
