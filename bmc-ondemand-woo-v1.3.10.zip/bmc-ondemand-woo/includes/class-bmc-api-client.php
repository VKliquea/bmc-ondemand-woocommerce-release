<?php
/**
 * Cliente API para BMCargo On-Demand (BM Drive)
 * Con Onboarding Automático, Edición de Sucursales y Consulta de Documentos Legales
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_API_Client {
    private static $instance = null;

    const DEV_BASE_URL  = 'https://4qaz9vprx3.execute-api.us-east-1.amazonaws.com/prod';
    const PROD_BASE_URL = 'https://4qaz9vprx3.execute-api.us-east-1.amazonaws.com/prod';
    const COGNITO_TOKEN_URL = 'https://prod-on-demand.auth.us-east-1.amazoncognito.com/oauth2/token';

    // Endpoint de autenticación y credenciales para WooCommerce
    const WOOCOMMERCE_AUTH_URL = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/auth/woocommerce';

    // Endpoints Legales
    const LEGAL_PRIVACY_URL  = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/legal/privacy';
    const LEGAL_TERMS_URL    = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/legal/terms';
    const LEGAL_SECURITY_URL = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/legal/security';

    // Endpoint de Tiendas y Estado
    const STORES_API_URL     = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/stores';
    const ONFLEET_SYNC_URL   = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/stores/sync-onfleet';

    // Endpoint de Configuración de Transportista (Carrier Config)
    const CARRIER_CONFIG_URL = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/carrier-config';

    // Endpoint internacional alternativo
    const ALTERNATE_ORDER_ENDPOINT = 'https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/order';
    const COUNTRIES_WITH_ALTERNATE_ORDER_ENDPOINT = array('CO', 'ES', 'MX', 'US');

    // Nombres de opciones en wp_options
    const OPTION_ENV            = 'bmc_ondemand_environment';
    const OPTION_STORE_STATUS   = 'bmc_ondemand_store_status';
    const OPTION_STORE_NAME     = 'bmc_ondemand_store_name';
    const OPTION_STORE_EMAIL    = 'bmc_ondemand_store_email';
    const OPTION_STORE_PHONE    = 'bmc_ondemand_store_phone';
    const OPTION_STORE_COUNTRY  = 'bmc_ondemand_store_country';
    const OPTION_STORE_CURRENCY = 'bmc_ondemand_store_currency';
    const OPTION_CLIENT_ID      = 'bmc_ondemand_client_id';
    const OPTION_CLIENT_SECRET  = 'bmc_ondemand_client_secret';
    const OPTION_ACCESS_TOKEN   = 'bmc_ondemand_access_token';
    const OPTION_TOKEN_EXPIRES  = 'bmc_ondemand_token_expires';
    const DEFAULT_ORDER_TOKEN_SECRET = 'f502b45-1c31-45b8-bbf3-4463-a1cc-6a581';

    const OPTION_WC_KEY_ID      = 'bmc_ondemand_wc_key_id';
    const OPTION_WC_CONSUMER_KEY = 'bmc_ondemand_wc_consumer_key';
    const OPTION_WC_CONSUMER_SECRET = 'bmc_ondemand_wc_consumer_secret';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function get_environment() {
        return get_option(self::OPTION_ENV, 'prod');
    }

    public function get_base_url() {
        return $this->get_environment() === 'dev' ? self::DEV_BASE_URL : self::PROD_BASE_URL;
    }

    public function get_shop_identifier() {
        $site_url = get_site_url();
        $domain = preg_replace('#^https?://#', '', $site_url);
        return strtolower(rtrim($domain, '/'));
    }

    public function get_or_create_wc_api_keys() {
        $key = get_option(self::OPTION_WC_CONSUMER_KEY);
        $secret = get_option(self::OPTION_WC_CONSUMER_SECRET);

        if (!empty($key) && !empty($secret)) {
            return array(
                'consumer_key'    => $key,
                'consumer_secret' => $secret,
            );
        }

        global $wpdb;
        $user_id = get_current_user_id();
        if (!$user_id) {
            $admin_user = get_users(array('role' => 'administrator', 'number' => 1));
            $user_id = !empty($admin_user) ? $admin_user[0]->ID : 1;
        }

        $description     = 'BMC OnDemand Integration Key';
        $permissions     = 'read_write';
        $consumer_key    = 'ck_' . wc_rand_hash();
        $consumer_secret = 'cs_' . wc_rand_hash();

        $table = $wpdb->prefix . 'woocommerce_api_keys';

        $result = $wpdb->insert(
            $table,
            array(
                'user_id'         => $user_id,
                'description'     => $description,
                'permissions'     => $permissions,
                'consumer_key'    => wc_api_hash($consumer_key),
                'consumer_secret' => $consumer_secret,
                'truncated_key'   => substr($consumer_key, -7),
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result === false || 0 === $wpdb->insert_id) {
            BMC_Logger::error('Fallo al generar API Keys de WooCommerce: ' . $wpdb->last_error);
            return new WP_Error('wc_key_gen_failed', 'No se pudieron generar las claves API de WooCommerce.');
        }

        $key_id = $wpdb->insert_id;
        update_option(self::OPTION_WC_KEY_ID, $key_id);
        update_option(self::OPTION_WC_CONSUMER_KEY, $consumer_key);
        update_option(self::OPTION_WC_CONSUMER_SECRET, $consumer_secret);

        return array(
            'consumer_key'    => $consumer_key,
            'consumer_secret' => $consumer_secret,
        );
    }

    public function register_and_connect_store($params = array()) {
        $shop_id     = $this->get_shop_identifier();
        $shop_name   = !empty($params['shopName']) ? sanitize_text_field($params['shopName']) : get_option(self::OPTION_STORE_NAME, get_bloginfo('name') ?: 'Tienda WooCommerce');
        $owner_email = !empty($params['ownerEmail']) ? sanitize_email($params['ownerEmail']) : get_option(self::OPTION_STORE_EMAIL, get_option('admin_email'));
        $phone       = !empty($params['phone']) ? sanitize_text_field($params['phone']) : get_option(self::OPTION_STORE_PHONE, '+18090000000');
        $country     = !empty($params['country']) ? sanitize_text_field($params['country']) : get_option(self::OPTION_STORE_COUNTRY, wc_get_base_location()['country'] ?? 'DO');
        $currency    = !empty($params['currency']) ? sanitize_text_field($params['currency']) : get_option(self::OPTION_STORE_CURRENCY, get_woocommerce_currency() ?: 'DOP');
        $site_url    = get_site_url();

        // Actualizar opciones
        update_option(self::OPTION_STORE_NAME, $shop_name);
        update_option(self::OPTION_STORE_EMAIL, $owner_email);
        update_option(self::OPTION_STORE_PHONE, $phone);
        update_option(self::OPTION_STORE_COUNTRY, $country);
        update_option(self::OPTION_STORE_CURRENCY, $currency);

        // 1. Asegurar registro en Stores
        $register_payload = array(
            'shopId'     => $shop_id,
            'shopName'   => $shop_name,
            'shopDomain' => $shop_id,
            'ownerEmail' => $owner_email,
            'phone'      => $phone,
            'country'    => $country,
            'currency'   => $currency,
        );

        $url_register = rtrim($this->get_base_url(), '/') . '/api/stores/register';
        wp_remote_post($url_register, array(
            'timeout' => 25,
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($register_payload),
        ));

        // 2. Obtener / Generar claves WooCommerce
        $wc_keys = $this->get_or_create_wc_api_keys();
        if (is_wp_error($wc_keys)) {
            return $wc_keys;
        }

        $consumer_key    = $wc_keys['consumer_key'];
        $consumer_secret = $wc_keys['consumer_secret'];

        // 3. Conectar al endpoint WooCommerce
        $auth_payload = array(
            'shopId'         => $shop_id,
            'shopName'       => $shop_name,
            'siteUrl'        => $site_url,
            'consumerKey'    => $consumer_key,
            'consumerSecret' => $consumer_secret,
            'ownerEmail'     => $owner_email,
            'phone'          => $phone,
            'country'        => $country,
            'currency'       => $currency,
            'platform'       => 'woocommerce',
        );

        BMC_Logger::info('Autenticando tienda en BMCargo /api/auth/woocommerce...');

        $response = wp_remote_post(self::WOOCOMMERCE_AUTH_URL, array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type'         => 'application/json',
                'X-WC-Consumer-Key'    => $consumer_key,
                'X-WC-Consumer-Secret' => $consumer_secret,
                'X-Shop-Domain'        => $shop_id,
            ),
            'body' => wp_json_encode($auth_payload),
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error('Fallo conectando con WooCommerce Auth: ' . $response->get_error_message());
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $data        = json_decode(wp_remote_retrieve_body($response), true);

        if (in_array($status_code, array(200, 201))) {
            $client_id     = $data['clientId'] ?? $data['client_id'] ?? '';
            $client_secret = $data['clientSecret'] ?? $data['client_secret'] ?? '';
            $access_token  = $data['accessToken'] ?? $data['access_token'] ?? '';
            $token_secret  = $data['orderTokenSecret'] ?? $data['order_token_secret'] ?? '';

            if (!empty($client_id)) update_option(self::OPTION_CLIENT_ID, $client_id);
            if (!empty($client_secret)) update_option(self::OPTION_CLIENT_SECRET, $client_secret);
            if (!empty($token_secret)) update_option(self::OPTION_ORDER_TOKEN_SECRET, $token_secret);
            if (!empty($access_token)) {
                update_option(self::OPTION_ACCESS_TOKEN, $access_token);
                update_option(self::OPTION_TOKEN_EXPIRES, intval($data['expiresAt'] ?? (time() + 3600)));
            }
            update_option(self::OPTION_STORE_STATUS, $data['status'] ?? 'active');

            BMC_Logger::info('Autenticación y registro completados con éxito.');
            return array('success' => true, 'data' => $data);
        }

        $error_msg = $data['error'] ?? $data['message'] ?? "Error HTTP $status_code en autenticación";
        BMC_Logger::error('Fallo en autenticación: ' . $error_msg);
        return new WP_Error('auth_error', $error_msg);
    }

    public function get_access_token($force_refresh = false) {
        $token   = get_option(self::OPTION_ACCESS_TOKEN);
        $expires = get_option(self::OPTION_TOKEN_EXPIRES, 0);

        if (!$force_refresh && !empty($token) && ($expires - 60) > time()) {
            return $token;
        }

        $client_id     = get_option(self::OPTION_CLIENT_ID);
        $client_secret = get_option(self::OPTION_CLIENT_SECRET);

        if (empty($client_id) || empty($client_secret)) {
            $auto_connect = $this->register_and_connect_store();
            if (is_wp_error($auto_connect) || empty($auto_connect['success'])) {
                return new WP_Error('missing_credentials', 'No se pudieron aprovisionar credenciales automáticamente.');
            }
            $client_id     = get_option(self::OPTION_CLIENT_ID);
            $client_secret = get_option(self::OPTION_CLIENT_SECRET);
            $token         = get_option(self::OPTION_ACCESS_TOKEN);
            if (!empty($token)) {
                return $token;
            }
        }

        $response = wp_remote_post(self::COGNITO_TOKEN_URL, array(
            'timeout' => 20,
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
            'body'    => http_build_query(array(
                'grant_type'    => 'client_credentials',
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
                'scope'         => 'api/write api/read',
            )),
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200 || empty($body['access_token'])) {
            return new WP_Error('auth_failed', $body['message'] ?? 'Falló la autenticación con BMCargo');
        }

        $new_token = $body['access_token'];
        $expires_at = time() + intval($body['expires_in'] ?? 3600);

        update_option(self::OPTION_ACCESS_TOKEN, $new_token);
        update_option(self::OPTION_TOKEN_EXPIRES, $expires_at);

        return $new_token;
    }

    public function request($endpoint, $method = 'GET', $body = null, $is_retry = false) {
        $token = $this->get_access_token($is_retry);
        if (is_wp_error($token)) {
            return $token;
        }

        $url = rtrim($this->get_base_url(), '/') . '/' . ltrim($endpoint, '/');
        $args = array(
            'method'  => $method,
            'timeout' => 25,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
                'X-Shop-Domain' => $this->get_shop_identifier(),
            ),
        );

        if ($body !== null && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = is_array($body) ? wp_json_encode($body) : $body;
        }

        BMC_Logger::info("API Request [{$method}] {$endpoint}", array(
            'url'     => $url,
            'headers' => array_keys($args['headers']),
            'body'    => $body,
        ));

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            BMC_Logger::error("API Request Error [{$method}] {$endpoint}: " . $response->get_error_message());
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $data = json_decode($raw_body, true);

        BMC_Logger::info("API Response [{$code}] {$endpoint}", array(
            'status'   => $code,
            'response' => $data ?: substr($raw_body, 0, 500),
        ));

        if ($code === 401 && !$is_retry) {
            return $this->request($endpoint, $method, $body, true);
        }

        return array('status' => $code, 'data' => $data);
    }

    public function get_locations($next_token = null) {
        $endpoint = 'api/stores/locations';
        if ($next_token) {
            $endpoint .= '?nextToken=' . urlencode($next_token);
        }
        return $this->request($endpoint, 'GET');
    }

    public function create_location($location_data) {
        return $this->request('api/stores/locations', 'POST', $location_data);
    }

    public function update_location($location_id, $location_data) {
        return $this->request('api/stores/locations/' . urlencode($location_id), 'PUT', $location_data);
    }

    public function delete_location($location_id) {
        return $this->request('api/stores/locations/' . urlencode($location_id), 'DELETE');
    }

    public function get_quote($quote_payload) {
        return $this->request('api/orders/quote', 'POST', $quote_payload);
    }

    /**
     * Consulta el listado de órdenes registradas en BM Drive / BMC OnDemand
     */
    public function get_orders() {
        return $this->request('api/orders', 'GET');
    }

    /**
     * Consulta las órdenes internacionales guardadas para esta tienda
     */
    public function get_international_orders() {
        $shop = $this->get_shop_identifier();
        $client_id = get_option(self::OPTION_CLIENT_ID, '');
        $query_args = array('shop' => $shop);
        if (!empty($client_id) && $client_id !== $shop) {
            $query_args['clientId'] = $client_id;
        }

        $url = add_query_arg(
            $query_args,
            rtrim(self::ALTERNATE_ORDER_ENDPOINT, '/') . 's' // https://pnjmua7td3.execute-api.us-east-1.amazonaws.com/api/orders
        );

        BMC_Logger::info("Consultando órdenes internacionales", array('url' => $url, 'shop' => $shop));

        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'headers' => array(
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-cache',
            ),
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error('Error al obtener órdenes internacionales: ' . $response->get_error_message());
            return array();
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        BMC_Logger::info("Respuesta de órdenes internacionales [{$code}]", array(
            'count' => is_array($data) ? count($data['orders'] ?? $data['data'] ?? array()) : 0,
        ));

        if ($code === 200 && is_array($data)) {
            $orders = $data['orders'] ?? $data['data'] ?? array();
            return is_array($orders) ? $orders : array();
        }

        return array();
    }

    public function submit_order($order_payload, $destination_country = null) {
        $store_country = get_option(self::OPTION_STORE_COUNTRY, wc_get_base_location()['country'] ?? 'DO');
        $effective_country = $store_country;

        if ($this->uses_alternate_order_endpoint($effective_country)) {
            return $this->submit_international_order($order_payload, $effective_country);
        }
        return $this->request('api/orders', 'POST', $order_payload);
    }

    public function uses_alternate_order_endpoint($country) {
        $c = strtoupper(trim($country ?? ''));
        $aliases = array(
            'COLOMBIA'                 => 'CO',
            'ESPAÑA'                   => 'ES',
            'SPAIN'                    => 'ES',
            'MÉXICO'                   => 'MX',
            'MEXICO'                   => 'MX',
            'UNITED STATES'            => 'US',
            'UNITED STATES OF AMERICA' => 'US',
            'ESTADOS UNIDOS'           => 'US',
        );
        $norm = $aliases[$c] ?? $c;
        return in_array($norm, self::COUNTRIES_WITH_ALTERNATE_ORDER_ENDPOINT, true) || ($norm !== 'DO' && !empty($norm));
    }

    public function submit_international_order($order_payload, $country = 'US') {
        $secret = self::DEFAULT_ORDER_TOKEN_SECRET;

        // Construir el objeto seller y datos internacionales tal como en la app de Shopify
        $shop_id     = $this->get_shop_identifier();
        $shop_name   = get_option(self::OPTION_STORE_NAME, get_bloginfo('name') ?: 'Tienda WooCommerce');
        $client_id   = get_option(self::OPTION_CLIENT_ID, '');
        $owner_email = get_option(self::OPTION_STORE_EMAIL, get_option('admin_email'));
        $phone       = get_option(self::OPTION_STORE_PHONE, '+18090000000');
        $currency    = get_option(self::OPTION_STORE_CURRENCY, get_woocommerce_currency() ?: 'USD');

        $alternate_payload = $order_payload;
        $alternate_payload['seller'] = array(
            'sellerId'              => $shop_id,
            'sellerName'            => $shop_name,
            'id'                    => $shop_id,
            'shop'                  => $shop_id,
            'clientId'              => $client_id,
            'email'                 => $owner_email,
            'phone'                 => $phone,
            'shopName'              => $shop_name,
            'shopDomain'            => $shop_id,
            'country'               => strtoupper($country),
            'currency'              => strtoupper($currency),
            'autoSyncOrdersEnabled' => true,
            'status'                => 'active',
        );

        if (!isset($alternate_payload['order'])) {
            $alternate_payload['order'] = array();
        }
        $alternate_payload['order']['country']  = strtoupper($country);
        $alternate_payload['order']['currency'] = strtoupper($currency);

        $json_body = wp_json_encode($alternate_payload);
        $timestamp = (string) time();
        $body_hash = hash('sha256', $json_body);
        $signature = hash_hmac('sha256', "{$timestamp}.{$body_hash}", $secret);

        BMC_Logger::info("Enviando orden internacional a {$country} (Endpoint alternativo)", array(
            'url'     => self::ALTERNATE_ORDER_ENDPOINT,
            'payload' => $alternate_payload,
        ));

        $response = wp_remote_post(self::ALTERNATE_ORDER_ENDPOINT, array(
            'timeout' => 25,
            'headers' => array(
                'Content-Type'  => 'application/json',
                'x-order-token' => "{$timestamp}.{$signature}",
            ),
            'body' => $json_body,
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error("Error en orden internacional: " . $response->get_error_message());
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $data = json_decode($raw_body, true);

        BMC_Logger::info("Respuesta de orden internacional [{$code}]", array(
            'status'   => $code,
            'response' => $data ?: substr($raw_body, 0, 500),
        ));

        return array(
            'status' => $code,
            'data'   => $data,
        );
    }

    /**
     * Consulta documentos legales dinámicos desde la API de BMCargo
     */
    public function get_legal_document($type = 'privacy') {
        $urls = array(
            'privacy'  => self::LEGAL_PRIVACY_URL,
            'terms'    => self::LEGAL_TERMS_URL,
            'security' => self::LEGAL_SECURITY_URL,
        );

        $url = $urls[$type] ?? self::LEGAL_PRIVACY_URL;
        $response = wp_remote_get($url, array('timeout' => 15));

        if (is_wp_error($response)) {
            return array('success' => false, 'error' => $response->get_error_message());
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        return array('success' => true, 'data' => $data);
    }

    /**
     * Obtiene la configuración remota de tarifas y zonas del carrier desde la API en tiempo real
     *
     * @param bool $force_refresh Si es true, ignora el cache local
     * @return array|null Configuración normalizada de carrierConfig
     */
    public function get_carrier_config($force_refresh = true) {
        $cache_key = 'bmc_carrier_config_cache';
        if (!$force_refresh) {
            $cached = get_transient($cache_key);
            if (!empty($cached) && is_array($cached)) {
                return $cached;
            }
        }

        $shop = $this->get_shop_identifier();
        $url = add_query_arg(array('shop' => $shop), self::CARRIER_CONFIG_URL);

        BMC_Logger::info("Solicitando carrier config a la API en tiempo real", array('url' => $url, 'shop' => $shop));

        $response = wp_remote_get($url, array(
            'timeout' => 8,
            'headers' => array(
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma'        => 'no-cache',
            ),
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error("Error al obtener carrier config: " . $response->get_error_message());
            return get_option('bmc_ondemand_shipping_rules', null);
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        BMC_Logger::info("Respuesta de carrier config en tiempo real [{$code}]", array('data' => $data));

        if ($code === 200 && is_array($data)) {
            $carrier_config = $data['carrierConfig'] ?? $data['config'] ?? null;
            if (is_array($carrier_config)) {
                // Actualizar siempre la opción de respaldo
                update_option('bmc_ondemand_shipping_rules', $carrier_config);
                return $carrier_config;
            }
        }

        return get_option('bmc_ondemand_shipping_rules', null);
    }

    /**
     * Obtiene el registro completo de la tienda desde DynamoDB (STORES_TABLE)
     *
     * @param bool $force_refresh
     * @return array|null Datos de la tienda en DynamoDB o null si no se encuentra
     */
    public function get_store_record($force_refresh = false) {
        $shop = $this->get_shop_identifier();
        $cache_key = 'bmc_store_record_' . md5($shop);

        if (!$force_refresh) {
            $cached = get_transient($cache_key);
            if ($cached !== false && is_array($cached)) {
                return $cached;
            }
        }

        $url = add_query_arg(array('shopId' => $shop), self::STORES_API_URL);

        $response = wp_remote_get($url, array(
            'timeout' => 12,
            'headers' => array(
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
            ),
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error("Error consultando registro de tienda en DynamoDB: " . $response->get_error_message());
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && is_array($data)) {
            $record = null;
            if (isset($data['store']) && is_array($data['store'])) {
                $record = $data['store'];
            } elseif (isset($data['stores']) && is_array($data['stores'])) {
                foreach ($data['stores'] as $item) {
                    if (isset($item['shopId']) && $item['shopId'] === $shop) {
                        $record = $item;
                        break;
                    }
                }
            }

            if ($record) {
                set_transient($cache_key, $record, 60);
                if (!empty($record['status'])) {
                    update_option(self::OPTION_STORE_STATUS, $record['status']);
                }
                if (!empty($record['onfleetClientId'])) {
                    update_option('bmc_ondemand_onfleet_client_id', $record['onfleetClientId']);
                }
                return $record;
            }
        }

        return null;
    }

    /**
     * Consulta el estado de la tienda en DynamoDB/API
     *
     * @param bool $force_refresh Si es true, omite la caché temporal
     * @return string 'active' | 'pending' | 'not_found' | 'error'
     */
    public function get_store_status($force_refresh = false) {
        $shop = $this->get_shop_identifier();
        $cache_key = 'bmc_store_status_' . md5($shop);

        if (!$force_refresh) {
            $cached = get_transient($cache_key);
            if ($cached !== false) {
                return $cached;
            }
        }

        $url = add_query_arg(array('shopId' => $shop), self::STORES_API_URL);

        $response = wp_remote_get($url, array(
            'timeout' => 10,
            'headers' => array(
                'Accept'        => 'application/json',
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
            ),
        ));

        if (is_wp_error($response)) {
            BMC_Logger::error("Error consultando estado de tienda: " . $response->get_error_message());
            return get_option(self::OPTION_STORE_STATUS, 'active');
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($code === 200 && is_array($data)) {
            if (isset($data['store']['status'])) {
                $status = $data['store']['status'];
            } elseif (isset($data['status'])) {
                $status = $data['status'];
            } elseif (isset($data['stores']) && is_array($data['stores'])) {
                // Fallback por si la respuesta contiene el listado de tiendas
                $found = null;
                foreach ($data['stores'] as $item) {
                    if (isset($item['shopId']) && $item['shopId'] === $shop) {
                        $found = $item;
                        break;
                    }
                }
                $status = $found['status'] ?? 'pending';
            } else {
                $status = 'pending';
            }

            update_option(self::OPTION_STORE_STATUS, $status);
            set_transient($cache_key, $status, 60); // 1 minuto de cache
            return $status;
        }

        return get_option(self::OPTION_STORE_STATUS, 'pending');
    }

    /**
     * Sincroniza la tienda con su organización delegatee en Onfleet
     *
     * @param string|null $email Correo de la tienda opcional (usa el configurado por defecto)
     * @return array|WP_Error Resultado de la sincronización
     */
    public function sync_onfleet_client($email = null) {
        $shop = $this->get_shop_identifier();
        $owner_email = !empty($email) ? sanitize_email($email) : get_option(self::OPTION_STORE_EMAIL, get_option('admin_email'));

        $payload = array(
            'shopId' => $shop,
            'email'  => $owner_email,
        );

        BMC_Logger::info("Sincronizando tienda con Onfleet...", $payload);

        // 1. Probar ruta vía GET /api/stores?shopId=...&syncOnfleet=true
        $url_get = add_query_arg(array(
            'shopId'      => $shop,
            'email'       => $owner_email,
            'syncOnfleet' => 'true',
        ), self::STORES_API_URL);

        $response = wp_remote_get($url_get, array(
            'timeout' => 20,
            'headers' => array('Accept' => 'application/json'),
        ));

        // 2. Si dio error o 404, fallback a POST /api/stores/sync-onfleet
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            $response = wp_remote_post(self::ONFLEET_SYNC_URL, array(
                'timeout' => 20,
                'headers' => array('Content-Type' => 'application/json'),
                'body'    => wp_json_encode($payload),
            ));
        }

        if (is_wp_error($response)) {
            BMC_Logger::error("Error llamando a sync-onfleet: " . $response->get_error_message());
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        BMC_Logger::info("Respuesta de sync-onfleet [{$code}]", array('data' => $data));

        if ($code === 200 && !empty($data['success'])) {
            if (!empty($data['onfleetClientId'])) {
                update_option('bmc_ondemand_onfleet_client_id', $data['onfleetClientId']);
            }
            return array('success' => true, 'data' => $data);
        }

        $msg = $data['message'] ?? $data['error'] ?? "Error {$code} sincronizando con Onfleet";
        return new WP_Error('onfleet_sync_error', $msg);
    }
}
