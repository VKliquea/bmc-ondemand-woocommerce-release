<?php
/**
 * Método de Envío para WooCommerce - BMC OnDemand
 * Soporta Cotización en Tiempo Real de la API y Motor de Reglas Locales
 */

if (!defined('ABSPATH')) {
    exit;
}

function bmc_ondemand_shipping_method_init() {
    if (!class_exists('WC_Shipping_Method')) {
        return;
    }

    class WC_Shipping_BMC_OnDemand extends WC_Shipping_Method {
        public function __construct($instance_id = 0) {
            $this->id                 = 'bmc_ondemand_shipping';
            $this->instance_id        = absint($instance_id);
            $this->method_title       = __('BMC OnDemand', 'bmc-ondemand');
            $this->method_description = __('Calcula tarifas en tiempo real usando el servicio BMC OnDemand / BM Drive o el motor de reglas.', 'bmc-ondemand');
            $this->supports           = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );

            $this->init();
        }

        public function init() {
            $this->init_form_fields();
            $this->init_settings();

            $this->title   = $this->get_option('title', __('BMC OnDemand Delivery', 'bmc-ondemand'));
            $this->enabled = $this->get_option('enabled', 'yes');

            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields() {
            $this->instance_form_fields = array(
                'title' => array(
                    'title'       => __('Título del Método', 'bmc-ondemand'),
                    'type'        => 'text',
                    'description' => __('Título que ve el cliente en el checkout.', 'bmc-ondemand'),
                    'default'     => __('BMC OnDemand Delivery', 'bmc-ondemand'),
                    'desc_tip'    => true,
                ),
                'cost' => array(
                    'title'       => __('Costo de Envío / Tarifa Base', 'bmc-ondemand'),
                    'type'        => 'text',
                    'description' => __('Costo fijo que se aplica al país configurado en esta zona de envío. Si la API en tiempo real responde, se utiliza la tarifa calculada; de lo contrario se usa este costo.', 'bmc-ondemand'),
                    'default'     => '0',
                    'desc_tip'    => true,
                ),
                'fallback_rate' => array(
                    'title'       => __('Tarifa fija de respaldo', 'bmc-ondemand'),
                    'type'        => 'price',
                    'description' => __('Tarifa a aplicar si la API de cotización no responde o no encuentra coordenadas.', 'bmc-ondemand'),
                    'default'     => '0',
                    'desc_tip'    => true,
                ),
            );
        }

        /**
         * Evalúa la disponibilidad del método según el país de la zona de WooCommerce
         */
        public function is_available($package) {
            // Si la tienda no está aprobada (status 'active'), el método de envío no debe calcularse ni mostrarse
            $api = BMC_API_Client::get_instance();
            if ($api->get_store_status() !== 'active') {
                return false;
            }

            $carrier_enabled = get_option('bmc_ondemand_carrier_enabled', 'yes') === 'yes';
            if (!$carrier_enabled) {
                return false;
            }

            $destination = $package['destination'] ?? array();
            $dest_country = !empty($destination['country']) ? strtoupper(trim($destination['country'])) : '';

            // Si hay reglas remotas activas de carrierConfig, verificar si este método pertenece a una zona compatible
            $carrier_rules = get_option('bmc_ondemand_shipping_rules');
            if (!empty($carrier_rules) && !empty($carrier_rules['active'])) {
                // Obtener la zona de WooCommerce a la que pertenece esta instancia
                if ($this->instance_id > 0 && class_exists('WC_Shipping_Zones')) {
                    $zone = WC_Shipping_Zones::get_zone_by('instance_id', $this->instance_id);
                    if ($zone) {
                        $zone_id = $zone->get_id(); // 0 = "Locations not covered by your other zones"
                        
                        // Si la zona es "Locations not covered..." (zona 0) y el cliente ya cayó en una zona específica (como DO),
                        // no activar esta instancia para evitar métodos duplicados.
                        if ($zone_id === 0) {
                            $customer_zone = WC_Shipping_Zones::get_zone_matching_package($package);
                            if ($customer_zone && $customer_zone->get_id() !== 0) {
                                return false;
                            }
                        }
                    }
                }
            }

            $available = parent::is_available($package);

            BMC_Logger::info("Shipping Method is_available Check", array(
                'carrier_enabled' => $carrier_enabled,
                'instance_id'     => $this->instance_id,
                'is_available'    => $available,
                'destination'     => $destination,
            ));

            return $available;
        }

        public function calculate_shipping($package = array()) {
            $carrier_enabled = get_option('bmc_ondemand_carrier_enabled', 'yes') === 'yes';
            if (!$carrier_enabled) {
                BMC_Logger::info("calculate_shipping omitido: Carrier Service desactivado.");
                return;
            }

            $destination = $package['destination'] ?? array();
            $dest_country = !empty($destination['country']) ? strtoupper(trim($destination['country'])) : '';
            $cart_subtotal = floatval($package['contents_cost'] ?? 0);

            BMC_Logger::info("Iniciando cálculo de tarifas de envío", array(
                'destination'   => $destination,
                'dest_country'  => $dest_country,
                'cart_subtotal' => $cart_subtotal,
                'items_count'   => count($package['contents'] ?? array()),
            ));

            // 1. Evaluar si existen reglas locales configuradas en BMC Carrier Calculator para el país seleccionado
            $local_rates = BMC_Carrier_Calculator::calculate_local_rates($destination, $package['contents'], $cart_subtotal);
            if (!empty($local_rates)) {
                BMC_Logger::info("Tarifas resueltas por Reglas del País Seleccionado", array('rates' => $local_rates));
                foreach ($local_rates as $r) {
                    $this->add_rate(array(
                        'id'        => $this->get_rate_id($r['serviceId']),
                        'label'     => $r['displayName'],
                        'cost'      => floatval($r['price']),
                        'calc_tax'  => 'per_order',
                    ));
                }
                return;
            }

            // Si las reglas remotas de carrierConfig están activas y ya evaluaron tarifas para este país:
            // Si el motor local no devolvió nada, significa que no cumplió condiciones o no pertenece a los servicios/zonas activas.
            if ($has_remote_rules) {
                BMC_Logger::info("No se añaden tarifas adicionales porque carrierConfig remoto está activo y no hubo tarifas que cumplieran las reglas para este país.");
                return;
            }

            // 2. Si NO hay reglas remotas o están inactivas y es país internacional:
            $api = BMC_API_Client::get_instance();
            if ($api->uses_alternate_order_endpoint($dest_country) || ($dest_country !== 'DO' && !empty($dest_country))) {
                $base_cost = floatval($this->get_option('cost', $this->get_option('fallback_rate', 0)));
                BMC_Logger::info("Tarifa Internacional Asignada (Sin carrierConfig remoto)", array(
                    'country'   => $dest_country,
                    'base_cost' => $base_cost,
                    'title'     => $this->title,
                ));
                $this->add_rate(array(
                    'id'       => $this->get_rate_id('intl_delivery'),
                    'label'    => $this->title,
                    'cost'     => $base_cost,
                    'calc_tax' => 'per_order',
                ));
                return;
            }

            // 3. Para República Dominicana: Si tiene cotización en tiempo real activa, intentar cotizar con coordenadas
            $location_id = BMC_Locations::get_default_location_id();
            $dest_city   = !empty($destination['city']) ? $destination['city'] : 'Santo Domingo';
            $lat = WC()->session ? WC()->session->get('bmc_destination_lat') : 18.4861;
            $lng = WC()->session ? WC()->session->get('bmc_destination_lng') : -69.9312;

            BMC_Logger::info("Cotizando tarifa en tiempo real con API BMCargo (RD)", array(
                'location_id' => $location_id,
                'city'        => $dest_city,
                'lat'         => $lat,
                'lng'         => $lng,
            ));

            if (!empty($location_id) && $lat && $lng) {
                $items_payload = array();
                $weight_unit = get_option('woocommerce_weight_unit', 'kg');

                foreach ($package['contents'] as $item) {
                    $product = $item['data'];
                    $quantity = $item['quantity'];
                    $price = floatval($product->get_price());

                    $raw_weight = floatval($product->get_weight());
                    if ($weight_unit === 'kg') {
                        $weight_lb = $raw_weight * 2.20462;
                    } elseif ($weight_unit === 'g') {
                        $weight_lb = ($raw_weight / 1000) * 2.20462;
                    } else {
                        $weight_lb = $raw_weight > 0 ? $raw_weight : 1.0;
                    }

                    if ($weight_lb <= 0) $weight_lb = 1.0;

                    $items_payload[] = array(
                        'quantity' => intval($quantity),
                        'weight'   => round($weight_lb, 2),
                        'price'    => $price,
                    );
                }

                $quote_payload = array(
                    'locationId' => $location_id,
                    'order' => array('items' => $items_payload),
                    'customer' => array(
                        'address' => array(
                            'city'      => $dest_city,
                            'country'   => $dest_country ?: 'DO',
                            'latitude'  => floatval($lat),
                            'longitude' => floatval($lng),
                        ),
                    ),
                );

                $quote_response = $api->get_quote($quote_payload);

                BMC_Logger::info("Respuesta de API Cotizador get_quote", array(
                    'payload'  => $quote_payload,
                    'response' => $quote_response,
                ));

                if (!is_wp_error($quote_response) && !empty($quote_response['data']) && is_array($quote_response['data'])) {
                    foreach ($quote_response['data'] as $rate) {
                        $cost = floatval($rate['price'] ?? 0);
                        $service_id = $rate['serviceId'] ?? 'bmc_standard';
                        $service_name = $rate['displayName'] ?? $this->title;

                        $this->add_rate(array(
                            'id'        => $this->get_rate_id($service_id),
                            'label'     => $service_name,
                            'cost'      => $cost,
                            'calc_tax'  => 'per_order',
                        ));
                    }
                    return;
                }
            }

            // 4. Si la cotización en tiempo real no arroja resultados, aplicar tarifa base configurada en la zona
            $base_cost = floatval($this->get_option('cost', $this->get_option('fallback_rate', 0)));
            BMC_Logger::info("Aplicando Tarifa Base de la Zona (Fallback)", array(
                'base_cost' => $base_cost,
                'title'     => $this->title,
            ));

            $this->add_rate(array(
                'id'       => $this->get_rate_id('standard'),
                'label'    => $this->title,
                'cost'     => $base_cost,
                'calc_tax' => 'per_order',
            ));
        }

        private function add_fallback_rate() {
            $fallback = floatval($this->get_option('fallback_rate', 0));
            if ($fallback > 0) {
                $this->add_rate(array(
                    'id'    => $this->get_rate_id('fallback'),
                    'label' => $this->title,
                    'cost'  => $fallback,
                ));
            }
        }
    }
}

add_action('woocommerce_shipping_init', 'bmc_ondemand_shipping_method_init');

function bmc_ondemand_add_shipping_method($methods) {
    $methods['bmc_ondemand_shipping'] = 'WC_Shipping_BMC_OnDemand';
    return $methods;
}
add_filter('woocommerce_shipping_methods', 'bmc_ondemand_add_shipping_method');
