<?php
/**
 * Desinstalador de BMC OnDemand para WooCommerce
 * Ejecutado automáticamente por WordPress cuando el plugin es eliminado definitivamente.
 *
 * Elimina todos los datos creados por el plugin en la base de datos:
 * - Tabla de logs personalizada (wp_bmc_ondemand_logs)
 * - Llaves API de WooCommerce asociadas
 * - Opciones de configuración y transitorios (wp_options)
 * - Métodos de envío en zonas de WooCommerce (wp_woocommerce_shipping_zone_methods)
 * - Metadatos de órdenes tanto en postmeta tradicional como en HPOS (wc_orders_meta)
 *
 * @package BMC_OnDemand
 */

// Si no es invocado por WordPress durante la desinstalación, abortar.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Función que realiza la limpieza completa de los datos de BMC OnDemand
 */
function bmc_ondemand_uninstall_cleanup() {
    global $wpdb;

    // 1. Eliminar llaves API de WooCommerce creadas para la sincronización con BMCargo
    // IMPORTANTE: Obtener el ID de la opción ANTES de borrar las opciones de wp_options
    $wc_key_id = get_option('bmc_ondemand_wc_key_id');
    $keys_table = $wpdb->prefix . 'woocommerce_api_keys';

    if ($wpdb->get_var("SHOW TABLES LIKE '{$keys_table}'") === $keys_table) {
        if (!empty($wc_key_id)) {
            $wpdb->delete($keys_table, array('key_id' => intval($wc_key_id)), array('%d'));
        }
        // Limpiar cualquier otra llave generada con la descripción del plugin
        $wpdb->query("DELETE FROM {$keys_table} WHERE description LIKE '%BMC OnDemand%'");
    }

    // 2. Eliminar tabla personalizada de logs
    $table_logs = $wpdb->prefix . 'bmc_ondemand_logs';
    $wpdb->query("DROP TABLE IF EXISTS {$table_logs}");

    // 3. Eliminar opciones explícitas de configuración y estado
    $options_to_delete = array(
        'bmc_ondemand_store_name',
        'bmc_ondemand_store_email',
        'bmc_ondemand_store_phone',
        'bmc_ondemand_store_country',
        'bmc_ondemand_store_currency',
        'bmc_ondemand_carrier_enabled',
        'bmc_ondemand_default_location',
        'bmc_ondemand_store_status',
        'bmc_ondemand_access_token',
        'bmc_ondemand_token_expires',
        'bmc_ondemand_client_id',
        'bmc_ondemand_client_secret',
        'bmc_ondemand_order_token_secret',
        'bmc_ondemand_wc_key_id',
        'bmc_ondemand_wc_consumer_key',
        'bmc_ondemand_wc_consumer_secret',
        'bmc_ondemand_locations_cache',
        'bmc_ondemand_debug_enabled',
        'bmc_ondemand_environment',
        'bmc_ondemand_legal_accepted',
        'bmc_ondemand_legal_accepted_at',
        'bmc_ondemand_legal_accepted_ip',
        'bmc_ondemand_auto_sync_orders',
        'bmc_ondemand_shipping_rules',
    );

    foreach ($options_to_delete as $option) {
        delete_option($option);
    }

    // Limpiar transitorios específicos
    delete_transient('bmc_ondemand_update_info');

    // Limpieza exhaustiva en wp_options (opciones, configuraciones de envío y transitorios del plugin)
    $wpdb->query(
        "DELETE FROM {$wpdb->options} 
         WHERE option_name LIKE 'bmc_ondemand_%' 
            OR option_name LIKE 'woocommerce_bmc_ondemand%' 
            OR option_name LIKE '%_transient_bmc_%' 
            OR option_name LIKE '%_transient_timeout_bmc_%'"
    );

    // 4. Eliminar el método de envío de las zonas de WooCommerce
    $shipping_methods_table = $wpdb->prefix . 'woocommerce_shipping_zone_methods';
    if ($wpdb->get_var("SHOW TABLES LIKE '{$shipping_methods_table}'") === $shipping_methods_table) {
        $wpdb->delete($shipping_methods_table, array('method_id' => 'bmc_ondemand'), array('%s'));
    }

    // 5. Eliminar metadatos asociados a pedidos (en postmeta tradicional)
    $meta_keys = array(
        '_bmc_order_id',
        '_bmc_message_id',
        '_bmc_status',
        '_bmc_tracking',
        '_bmc_sync_error',
        '_bmc_sent_items',
    );
    $meta_keys_sql = "'" . implode("','", array_map('esc_sql', $meta_keys)) . "'";

    $wpdb->query(
        "DELETE FROM {$wpdb->postmeta} 
         WHERE meta_key IN ({$meta_keys_sql}) 
            OR meta_key LIKE '_bmc_%'"
    );

    // 6. Eliminar metadatos en WooCommerce HPOS (High-Performance Order Storage: wp_wc_orders_meta)
    $hpos_table = $wpdb->prefix . 'wc_orders_meta';
    if ($wpdb->get_var("SHOW TABLES LIKE '{$hpos_table}'") === $hpos_table) {
        $wpdb->query(
            "DELETE FROM {$hpos_table} 
             WHERE meta_key IN ({$meta_keys_sql}) 
                OR meta_key LIKE '_bmc_%'"
        );
    }

    // 7. Limpiar caché en memoria si está disponible
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
}

// Ejecución para WordPress Multisite o Instalación estándar
if (is_multisite()) {
    $site_ids = get_sites(array('fields' => 'ids'));
    foreach ($site_ids as $site_id) {
        switch_to_blog($site_id);
        bmc_ondemand_uninstall_cleanup();
        restore_current_blog();
    }
} else {
    bmc_ondemand_uninstall_cleanup();
}
