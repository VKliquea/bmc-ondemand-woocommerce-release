=== BMC OnDemand for WooCommerce ===
Contributors: bmcargo
Tags: woocommerce, delivery, bmcargo, ondemand, shipping, logistics, courier
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
WC requires at least: 5.0
WC tested up to: 9.4
Stable tag: 1.1.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integración oficial de entrega y delivery con BMC OnDemand / BM Drive para tiendas WooCommerce en República Dominicana e Internacional.

== Description ==

**BMC OnDemand for WooCommerce** conecta tu tienda online directamente con la plataforma logística y de entrega **BMC OnDemand** (BM Drive de BMCargo).

Automatiza la cotización de tarifas de envío en tiempo real, el cálculo de rutas urbanas por motoristas en República Dominicana, la asignación de sucursales de origen y el despacho de paquetes locales e internacionales.

### ✨ Características Principales

* **Onboarding Automático**: Registro de la tienda y vinculación sin necesidad de copiar y pegar claves manualmente.
* **Cálculo de Tarifas en Tiempo Real (Carrier Service)**: Cálculo dinámico de costos de envío según distancia, peso volumétrico y reglas zonales.
* **Gestión de Sucursales de Recogida**: Soporte para múltiples puntos de recogida con buscador de direcciones y mapa interactivo (Leaflet).
* **Despacho Split-Order por Sucursal**: Envía cada ítem de la orden desde su sucursal de origen correspondiente o márcalo como "No Enviar".
* **Soporte Internacional y Local**: Enrutamiento automático entre entrega inmediata local (República Dominicana) y despacho de encomiendas internacionales (Estados Unidos, Colombia, España, México).
* **Visor de Auditoría y Logs**: Registro detallado de peticiones para monitorear el estado de cada envío.
* **Cumplimiento Legal Integrado**: Acceso directo y sincronizado a los Términos y Condiciones, Política de Privacidad y Seguridad oficiales de BMCargo.

== Installation ==

1. Sube la carpeta `bmc-ondemand-woo` al directorio `/wp-content/plugins/`, o sube directamente el archivo ZIP a través de **Plugins > Añadir nuevo > Subir plugin**.
2. Activa el plugin en el menú **Plugins** de WordPress.
3. Ve a **BMC OnDemand > Configuración** para ingresar el nombre de tu tienda, contacto y seleccionar tu país y moneda.
4. En **BMC OnDemand > Sucursales**, agrega o selecciona tu sucursal de recogida predeterminada usando el mapa GPS.
5. (Opcional) Activa la casilla de **Cálculo de tarifas en tiempo real** para que se ofrezcan tarifas dinámicas en el carrito y checkout de WooCommerce.

== Frequently Asked Questions ==

= ¿Requiere WooCommerce activo? =
Sí, este plugin es una extensión diseñada exclusivamente para WooCommerce versión 5.0 o superior.

= ¿Cómo se calculan las coordenadas de entrega? =
El plugin incluye coordenadas predeterminadas inteligentes de fallback y resolución automática para que nunca se bloquee un despacho. Además, permite seleccionar ubicaciones exactas mediante mapa interactivo en la gestión de sucursales.

= ¿Funciona fuera de República Dominicana? =
Sí. Si la tienda opera en países como Estados Unidos, Colombia, México o España, el plugin conmuta automáticamente al canal de logística internacional firmado con HMAC.

== Screenshots ==

1. Pantalla de Configuración principal con datos de la tienda y recomendaciones.
2. Gestión de Sucursales de Origen con mapa interactivo Leaflet y búsqueda de coordenadas.
3. Panel de despacho por ítem dentro del detalle de pedidos de WooCommerce.
4. Registro de auditoría y logs de sincronización.

== Changelog ==

= 1.1.7 =
* Soporte para envíos internacionales con firma criptográfica HMAC y datos completos de vendedor.
* Fallback inteligente de coordenadas GPS.
* Integración de mapa interactivo Leaflet para selección de puntos de recogida.
* Visor de logs y cumplimiento legal integrado.
