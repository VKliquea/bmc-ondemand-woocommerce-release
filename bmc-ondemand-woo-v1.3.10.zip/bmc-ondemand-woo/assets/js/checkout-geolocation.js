/**
 * Script de Geocodificación y captura de coordenadas para Checkout de WooCommerce
 */
(function($) {
    'use strict';

    var geoTimeout = null;

    function attemptGeocode() {
        var address = $('#shipping_address_1').val() || $('#billing_address_1').val() || '';
        var city = $('#shipping_city').val() || $('#billing_city').val() || '';
        var country = $('#shipping_country').val() || $('#billing_country').val() || 'DO';

        if (!address || !city) {
            return;
        }

        var fullQuery = address + ', ' + city + ', ' + country;

        // Geocodificación liviana mediante Nominatim / OpenStreetMap
        $.getJSON('https://nominatim.openstreetmap.org/search', {
            q: fullQuery,
            format: 'json',
            limit: 1
        }, function(data) {
            if (data && data.length > 0) {
                var lat = data[0].lat;
                var lon = data[0].lon;

                // Guardar en la sesión de WooCommerce vía AJAX
                $.post(bmc_geo_params.ajax_url, {
                    action: 'bmc_save_checkout_coords',
                    security: bmc_geo_params.nonce,
                    lat: lat,
                    lng: lon
                }, function(res) {
                    if (res && res.success) {
                        // Forzar refresco de las tarifas de envío de WooCommerce
                        $('body').trigger('update_checkout');
                    }
                });
            }
        });
    }

    $(document).on('change', '#shipping_address_1, #shipping_city, #billing_address_1, #billing_city', function() {
        clearTimeout(geoTimeout);
        geoTimeout = setTimeout(attemptGeocode, 800);
    });

})(jQuery);
