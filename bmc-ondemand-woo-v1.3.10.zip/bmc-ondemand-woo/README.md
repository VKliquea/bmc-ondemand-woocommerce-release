# BMC OnDemand for WooCommerce

Plugin oficial para la integración logística entre tiendas **WooCommerce** y el servicio **BMC OnDemand** (BM Drive / Onfleet de BMCargo).

## ✨ Características

- **Autenticación OAuth2**: Conexión con flujo `client_credentials` y renovación automática de tokens.
- **Soporte para Entornos**: Entorno de desarrollo / sandbox y entorno de producción.
- **Gestión de Sucursales (Pickup Locations)**: Registro y selección de la sucursal de origen con geolocalización.
- **Cotizador de Fletes en Checkout (`WC_Shipping_Method`)**: Consulta dinámica a `/api/orders/quote` para calcular el costo real de envío según peso y distancia.
- **Geocodificación Automática**: Captura de coordenadas GPS en el checkout para satisfacer el requisito de latitud y longitud.
- **Despacho Automático de Pedidos**: Envío inmediato de pedidos pagados a `/api/orders` con registro del `messageId` y estado.
- **Metabox en Administración de Pedidos**: Consulta de estado, número de tracking y botón de reintento/despacho manual.

## 🚀 Instalación y Empaquetado

```bash
cd d:\SELLERHUB\plugin\woocommerce\bmc-ondemand-woo
npm install
npm run zip
```
El archivo ZIP resultante se generará en `dist/bmc-ondemand-woo.zip`, listo para subirse en **WordPress Admin > Plugins > Añadir nuevo > Subir plugin**.
