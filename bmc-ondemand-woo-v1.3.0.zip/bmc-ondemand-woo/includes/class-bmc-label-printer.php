<?php
/**
 * Generador de Etiquetas Térmicas 4x6 para BMC OnDemand
 * Soporte de Código QR nativo (SVG/Data-URL), layout térmico e integración con Branding.
 */

if (!defined('ABSPATH')) {
    exit;
}

class BMC_Label_Printer {

    public static function init() {
        add_action('wp_ajax_bmc_print_label', array(__CLASS__, 'handle_print_request'));
    }

    /**
     * Procesa la petición AJAX/GET para imprimir la etiqueta
     */
    public static function handle_print_request() {
        if (!current_user_can('edit_shop_orders')) {
            wp_die(__('No tienes permisos para ver esta etiqueta.', 'bmc-ondemand'), 403);
        }

        $order_id = intval($_GET['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die(__('Pedido no encontrado.', 'bmc-ondemand'), 404);
        }

        $tracking = sanitize_text_field($_GET['tracking'] ?? $order->get_meta('_bmc_tracking') ?: '');
        $note = sanitize_textarea_field($_GET['note'] ?? '');
        if (empty($note)) {
            $note = BMC_Order_Dispatcher::get_default_delivery_note($order);
            if (empty($note)) {
                $note = trim((string) $order->get_customer_note());
            }
        }

        self::render_label_page($order, $tracking, $note);
        exit;
    }

    /**
     * Renderiza el HTML de la etiqueta 4x6
     *
     * @param WC_Order $order
     * @param string $tracking
     * @param string $note
     */
    public static function render_label_page($order, $tracking, $note = '') {
        $branding = self::get_branding_config();

        // Datos del cliente / Destinatario
        $customer_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if (empty($customer_name)) {
            $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) ?: 'Cliente WooCommerce';
        }

        $address_line = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
        if (empty($address_line)) {
            $address_line = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
        }

        $city = $order->get_shipping_city() ?: $order->get_billing_city() ?: 'Santo Domingo';
        $country = $order->get_shipping_country() ?: $order->get_billing_country() ?: 'DO';
        $phone = $order->get_billing_phone() ?: $order->get_shipping_phone() ?: '';

        $reception_address = $address_line;
        if (!empty($city)) {
            $reception_address .= ', ' . $city;
        }
        if (!empty($country)) {
            $reception_address .= ' (' . $country . ')';
        }
        if (!empty($phone)) {
            $reception_address .= ' · Tel: ' . $phone;
        }

        $order_number = '#' . ltrim((string) $order->get_order_number(), '#');
        $date_formatted = date_i18n('d/m/Y', $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time());

        // Conteo total de ítems
        $total_items = 0;
        foreach ($order->get_items() as $item) {
            $total_items += intval($item->get_quantity());
        }
        $item_count_display = $total_items . ($total_items === 1 ? ' ÍTEM' : ' ÍTEMS');

        // Tracking y QR
        $tracking_clean = trim($tracking);
        $qr_target_value = !empty($tracking_clean) ? $tracking_clean : $order_number;
        $qr_image_url = 'https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=4&data=' . rawurlencode($qr_target_value);

        // Logo
        $logo_url = !empty($branding['logo_url']) ? $branding['logo_url'] : BMC_ONDEMAND_PLUGIN_URL . 'assets/images/bmc-ondemand-large.png';
        $business_name = !empty($branding['business_name']) ? $branding['business_name'] : get_bloginfo('name');
        $dispatch_address = !empty($branding['dispatch_address']) ? $branding['dispatch_address'] : 'Almacén Principal';
        if (!empty($branding['phone'])) {
            $dispatch_address .= ' · Tel: ' . $branding['phone'];
        }
        $subtitle = !empty($branding['subtitle']) ? $branding['subtitle'] : 'Logística · Despacho a Domicilio';
        $footer_brand = !empty($branding['footer_brand']) ? $branding['footer_brand'] : 'Kliquea · BMC OnDemand';

        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Etiqueta 4x6 - Pedido <?php echo esc_html($order_number); ?></title>
            <style>
                @page {
                    size: 4in 6in;
                    margin: 0;
                }
                * {
                    box-sizing: border-box;
                    text-transform: uppercase;
                }
                html, body {
                    margin: 0;
                    padding: 0;
                    width: 4in;
                    background-color: #fff;
                    font-family: Arial, Helvetica, sans-serif;
                    color: #000;
                }
                .label-page {
                    width: 4in;
                    height: 6in;
                    padding: 0.18in 0.20in;
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                    position: relative;
                    background: white;
                    border: 1px dashed #bbb;
                }
                .top {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    border-bottom: 2px solid #000;
                    padding-bottom: 6px;
                }
                .brand-row {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    width: 100%;
                    flex-direction: column;
                }
                .logo-container {
                    display: flex;
                    align-items: center;
                    width: 100%;
                    flex-direction: row;
                    justify-content: space-between;
                }
                .logo-sub {
                    font-size: 8pt;
                    color: #003366;
                    font-weight: 700;
                    letter-spacing: .6px;
                }
                .section {
                    margin-top: 10px;
                }
                .small {
                    font-size: 8.5pt;
                    font-weight: bold;
                    color: #003366;
                }
                .tracking-row {
                    display: flex;
                    justify-content: space-between;
                    align-items: baseline;
                }
                .order-number {
                    font-size: 22pt;
                    font-weight: 900;
                    letter-spacing: 1px;
                    line-height: 1.1;
                    margin-top: 2px;
                }
                .address-block {
                    font-size: 10.5pt;
                    line-height: 1.35;
                    margin-top: 3px;
                }
                .note-banner {
                    margin-top: 8px;
                    padding: 6px 8px;
                    background: #f8fafc;
                    border: 1.5px solid #000;
                    border-radius: 4px;
                    font-size: 9.5pt;
                    font-weight: 700;
                }
                .bottom {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-end;
                    border-top: 2px solid #000;
                    margin-top: auto;
                    padding-top: 8px;
                    gap: 8px;
                }
                .bottom-left {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    justify-content: flex-end;
                    gap: 4px;
                    min-width: 0;
                }
                .tracking-badge {
                    font-size: 13pt;
                    font-weight: 900;
                    letter-spacing: 0.8px;
                    background: #000;
                    color: #fff;
                    padding: 4px 8px;
                    border-radius: 3px;
                    display: inline-block;
                    margin-bottom: 4px;
                }
                .footer-text {
                    font-size: 8pt;
                    line-height: 1.3;
                    color: #333;
                }
                .qr-container {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    flex-shrink: 0;
                }
                .qr-image {
                    width: 1.15in;
                    height: 1.15in;
                    display: block;
                }
                @media screen {
                    body {
                        background: #e2e8f0;
                        padding: 24px;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                    }
                    .label-page {
                        box-shadow: 0 4px 14px rgba(0,0,0,0.15);
                    }
                    .print-bar {
                        margin-bottom: 16px;
                        display: flex;
                        gap: 10px;
                    }
                    .btn-print {
                        background: #008060;
                        color: #fff;
                        border: none;
                        padding: 8px 18px;
                        font-weight: bold;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 13px;
                    }
                }
                @media print {
                    .print-bar {
                        display: none !important;
                    }
                    body {
                        background: #fff;
                        padding: 0;
                        margin: 0;
                    }
                    .label-page {
                        border: none;
                        box-shadow: none;
                    }
                }
            </style>
        </head>
        <body>
            <div class="print-bar">
                <button type="button" class="btn-print" onclick="window.print()">🖨️ Imprimir Etiqueta (4x6)</button>
            </div>

            <div class="label-page">
                <div class="top">
                    <div class="brand-row">
                        <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
                            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($business_name); ?>"
                                style="height: 0.44in; width: auto; max-width: 2.2in; object-fit: contain; display: block; margin-bottom: 3px;" />
                            <div style="font-size: 11pt; font-weight: bold;"><?php echo esc_html($date_formatted); ?></div>
                        </div>
                        <div class="logo-container">
                            <div class="logo-sub"><?php echo esc_html($subtitle); ?></div>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="tracking-row">
                        <div class="small">No. De Pedido en <?php echo esc_html($business_name); ?></div>
                        <div class="small" style="font-weight: 900; font-size: 9pt;">
                            <?php echo esc_html($item_count_display); ?>
                        </div>
                    </div>
                    <div class="order-number"><?php echo esc_html($order_number); ?></div>
                </div>

                <div class="section">
                    <div class="small">Remitente (Origen)</div>
                    <div class="address-block">
                        <strong><?php echo esc_html($business_name); ?></strong><br>
                        <?php echo esc_html($dispatch_address); ?>
                    </div>
                </div>

                <div class="section">
                    <div class="small">Destinatario (Cliente)</div>
                    <div class="address-block">
                        <strong><?php echo esc_html($customer_name); ?></strong><br>
                        <?php echo esc_html($reception_address); ?>
                    </div>
                </div>

                <?php if (!empty($note)): ?>
                    <div class="note-banner">
                        <div class="small" style="color:#000;margin-bottom:2px;">Instrucciones / Entrega:</div>
                        <div><?php echo esc_html($note); ?></div>
                    </div>
                <?php endif; ?>

                <div class="bottom">
                    <div class="bottom-left">
                        <?php if (!empty($tracking_clean)): ?>
                            <div>
                                <span class="tracking-badge">TRACKING: <?php echo esc_html($tracking_clean); ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="footer-text">
                            <strong><?php echo esc_html($footer_brand); ?></strong> &bull; Pedido <?php echo esc_html($order_number); ?>
                        </div>
                    </div>

                    <div class="qr-container">
                        <img class="qr-image" src="<?php echo esc_url($qr_image_url); ?>" alt="Código QR Tracking" />
                    </div>
                </div>
            </div>

            <script>
                window.addEventListener('load', function() {
                    var images = Array.prototype.slice.call(document.images);
                    var pending = images.filter(function(img) { return !img.complete; });
                    if (pending.length === 0) {
                        setTimeout(function() { window.print(); }, 400);
                    } else {
                        var loaded = 0;
                        var check = function() {
                            loaded++;
                            if (loaded >= pending.length) {
                                setTimeout(function() { window.print(); }, 400);
                            }
                        };
                        pending.forEach(function(img) {
                            img.addEventListener('load', check);
                            img.addEventListener('error', check);
                        });
                    }
                });
            </script>
        </body>
        </html>
        <?php
    }

    /**
     * Devuelve la configuración de branding guardada en opciones
     *
     * @return array
     */
    public static function get_branding_config() {
        return array(
            'logo_url'         => get_option('bmc_ondemand_branding_logo', ''),
            'business_name'    => get_option('bmc_ondemand_branding_business_name', get_option('bmc_ondemand_store_name', get_bloginfo('name'))),
            'dispatch_address' => get_option('bmc_ondemand_branding_address', ''),
            'phone'            => get_option('bmc_ondemand_branding_phone', get_option('bmc_ondemand_store_phone', '')),
            'subtitle'         => get_option('bmc_ondemand_branding_subtitle', 'Logística · Despacho a Domicilio'),
            'footer_brand'     => get_option('bmc_ondemand_branding_footer', 'Kliquea · BMC OnDemand'),
        );
    }
}
